"""Read frozen graphs and archived records; no solver/evaluator imports or calls."""
import argparse
from collections import Counter, defaultdict, deque
import csv
from datetime import datetime, timezone
from fractions import Fraction
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import zipfile


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def dump(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False, allow_nan=False) + "\n", encoding="utf-8")


def graph_bound(graph):
    ops = {o["id"]: o for o in graph["ops"]}
    compute = {u: o for u, o in ops.items() if o["op"] not in {"COPY_IN", "COPY_OUT"}}
    tensors = {t["id"] for t in graph["tensors"]}
    assert len(ops) == len(graph["ops"]) and not tensors.intersection(ops)
    assert all(type(o["cycles"]) is int and o["cycles"] >= 0 for o in compute.values())
    assert all(o["pipe"] in {"PIPE_M", "PIPE_V", "PIPE_MTE2", "PIPE_MTE3"} for o in compute.values())
    durations = {u: max(1, o["cycles"]) for u, o in compute.items()}
    work = Counter()
    for u, o in compute.items():
        work[o["pipe"]] += durations[u]
    producers, consumers = defaultdict(set), defaultdict(set)
    full = {u: set() for u in ops}
    direct = set()
    for edge in graph["edges"]:
        u, v = edge["source"], edge["target"]
        assert u in ops or u in tensors
        assert v in ops or v in tensors
        if u in ops and v in ops:
            if u != v:
                full[u].add(v)
                if u in compute and v in compute:
                    direct.add((u, v))
        elif u in ops:
            producers[v].add(u)
        elif v in ops:
            consumers[u].add(v)
        else:
            raise ValueError("tensor-to-tensor edge has no proved P3 interpretation")
    tensor_edges = set()
    for tid, sources in producers.items():
        for u in sources:
            for v in consumers[tid]:
                if u != v:
                    full[u].add(v)
                    if u in compute and v in compute:
                        tensor_edges.add((u, v))
    original = direct | tensor_edges
    # Audit excluded-COPY contraction separately. Never use its additional edges
    # as official dependencies just because a plan validator would see them.
    extra = set()
    for u in compute:
        stack, visited = list(full[u]), set()
        while stack:
            v = stack.pop()
            if v in compute:
                if u != v and (u, v) not in original:
                    extra.add((u, v))
            elif v not in visited:
                visited.add(v)
                stack.extend(full[v])
    succ = {u: set() for u in compute}
    degree = dict.fromkeys(compute, 0)
    neighbors = {u: set() for u in compute}
    for u, v in original:
        succ[u].add(v)
        degree[v] += 1
        neighbors[u].add(v)
        neighbors[v].add(u)
    initial_degree = dict(degree)
    remaining, component_sizes = set(compute), []
    while remaining:
        component_root = min(remaining)
        remaining.remove(component_root)
        stack, size = [component_root], 0
        while stack:
            u = stack.pop()
            size += 1
            for v in neighbors[u]:
                if v in remaining:
                    remaining.remove(v)
                    stack.append(v)
        component_sizes.append(size)
    ready = deque(sorted(u for u in compute if degree[u] == 0))
    finish, previous, visited = {}, {}, 0
    start = dict.fromkeys(compute, 0)
    while ready:
        u = ready.popleft()
        visited += 1
        finish[u] = start[u] + durations[u]
        for v in sorted(succ[u]):
            if finish[u] > start[v]:
                start[v], previous[v] = finish[u], u
            degree[v] -= 1
            if degree[v] == 0:
                ready.append(v)
    assert visited == len(compute), "original compute tensor/direct graph must be acyclic"
    last = max(compute, key=lambda u: (finish[u], -u))
    path = [last]
    while path[-1] in previous:
        path.append(previous[path[-1]])
    path.reverse()
    assert all((u, v) in original for u, v in zip(path, path[1:]))
    assert sum(durations[u] for u in path) == finish[last]
    return {"compute_ops": len(compute), "copy_ops": len(ops) - len(compute),
            "raw_tensors": len(tensors), "raw_edges": len(graph["edges"]),
            "compute_direct_edges": len(direct), "compute_tensor_edges": len(tensor_edges),
            "compute_edges_union": len(original), "pipe_work_cycles": dict(sorted(work.items())),
            "max_op_cycles": max(durations.values()), "critical_path_cycles": finish[last],
            "critical_path_ops": path, "critical_path_duration_sum": sum(durations[u] for u in path),
            "extra_copy_contracted_edges": sorted(extra),
            "cp_scope": "original compute tensor/direct edges only; no excluded-COPY contraction edges",
            "compute_cycles_zero_count": sum(o["cycles"] == 0 for o in compute.values()),
            "multiple_original_producer_tensors": sum(len(x) > 1 for x in producers.values()),
            "weak_components": len(component_sizes), "largest_component_ops": max(component_sizes),
            "largest_component_fraction": max(component_sizes) / len(compute),
            "source_ops": sum(n == 0 for n in initial_degree.values()),
            "sink_ops": sum(not targets for targets in succ.values()),
            "max_fanin": max(initial_degree.values()), "max_fanout": max(map(len, succ.values())),
            "join_ops": sum(n > 1 for n in initial_degree.values()),
            "fork_ops": sum(len(targets) > 1 for targets in succ.values()),
            "M_work_fraction": work["PIPE_M"] / sum(work.values()),
            "V_work_fraction": work["PIPE_V"] / sum(work.values()),
            "cp_over_max_pipe_work": finish[last] / max(work.values()),
            "op_type_counts": dict(sorted(Counter(o["op"] for o in compute.values()).items()))}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root, out = args.repo.resolve(), args.output.resolve()
    out.mkdir(parents=True, exist_ok=True)
    official = root / "data/raw/a/official"
    manifest_raw = (root / "docs/a/source-manifest.json").read_bytes()
    manifest = json.loads(manifest_raw)
    frozen = {x["path"]: x for x in manifest["files"]}
    code_records = sorted((r for r in manifest["files"] if r["path"].startswith("code/")), key=lambda r: r["path"])
    for r in code_records:
        raw = (official / r["path"]).read_bytes()
        assert len(raw) == r["bytes"] and sha(raw) == r["sha256"]
        target = out / "evidence/official" / r["path"]
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)
    code_hash = sha("".join(r["path"] + "\t" + r["sha256"] + "\n" for r in code_records).encode())
    assert code_hash == manifest["official_code_hash"]
    config_raw = (official / "data/config.txt").read_bytes()
    config_hash = sha(config_raw)
    assert config_hash == frozen["data/config.txt"]["sha256"]
    archive = root / manifest["case_archive"]["path"]
    assert sha(archive.read_bytes()) == manifest["case_archive"]["sha256"]
    (out / "evidence/source-manifest.json").write_bytes(manifest_raw)
    (out / "evidence/config.txt").write_bytes(config_raw)
    snapshot_path = root / "results/a/q3-nikolastarx/gap-audit-20260925/source-snapshot.zip"
    snapshot_raw = snapshot_path.read_bytes()
    (out / "evidence/source-snapshot.zip").write_bytes(snapshot_raw)
    with zipfile.ZipFile(snapshot_path) as z:
        cells_raw, records_raw = z.read("p3-cells.json"), z.read("p3-records-all.json")
        snapshot, records = json.loads(cells_raw), json.loads(records_raw)
        original_manifest = json.loads(z.read("manifest.json"))
        hashes = {f["path"]: f["sha256"] for f in original_manifest["files"]}
        assert sha(cells_raw) == hashes["p3-cells.json"]
        assert sha(records_raw) == hashes["p3-records-all.json"]
    archived_snapshot = snapshot
    live_path = out / "evidence/live-p3-cells.json"
    uses_live_snapshot = live_path.exists()
    if uses_live_snapshot:
        cells_raw = live_path.read_bytes()
        snapshot = json.loads(cells_raw)
        filtered_raw = (out / "evidence/live-single-solver-cells.json").read_bytes()
        filtered = json.loads(filtered_raw)
        assert snapshot["cursor"] == filtered["cursor"], "both readbacks must share a ledger cursor"
        live_algo_records = [c["best"] for c in filtered["cells"]]
        assert all(r["algorithm_id"] == "q3-structure-selected-online" for r in live_algo_records)
    assert len(snapshot["cells"]) == 500
    cells = {(c["case_id"], c["cores"]): c["best"] for c in snapshot["cells"]}
    one_algo = ([r for r in live_algo_records if r.get("eligible")] if uses_live_snapshot else
                [r for r in records if r.get("eligible") and r["algorithm_id"] == "q3-structure-selected-online"])
    assert len(one_algo) == 500 and len({(r["case_id"], r["cores"]) for r in one_algo}) == 500
    assert len({r["solver_commit"] for r in one_algo}) == 1
    one_algo = {(r["case_id"], r["cores"]): r for r in one_algo}
    git = lambda *a: subprocess.check_output(["git", "-C", str(root), *a])
    source_commit = git("rev-parse", "HEAD").decode().strip()
    rows, structures, baseline_info, skipped = [], {}, {}, []
    baseline_dir = "results/benchmark-board/official-singlecore-20260924"
    with zipfile.ZipFile(archive) as graph_archive:
        for n in range(1, 101):
            case = f"{n:03d}"
            rel = f"data/case_{case}.json"
            raw = (official / rel).read_bytes()
            graph_hash = sha(raw)
            assert graph_hash == frozen[rel]["sha256"] and raw == graph_archive.read(rel)
            graph = json.loads(raw)
            structure = graph_bound(graph)
            structure.update(graph_sha256=graph_hash, graph_bytes=len(raw), graph_path=str((official / rel).relative_to(root)))
            structures[case] = structure
            b_record = one_algo[case, 1]
            try:
                identity = {"graph_sha256": graph_hash, "config_sha256": config_hash, "official_sha256": code_hash}
                b = b_record["baseline"]
                assert b_record["baseline_verified"] and b["route"] == "E0"
                assert b["entrypoint"] == "singlecore_evaluate.evaluate_singlecore"
                assert all(b.get(k) == v for k, v in identity.items())
                commit = b_record["source"]["commit"]
                result_raw = git("show", commit + ":" + b["result"]["path"])
                assert sha(result_raw) == b["result"]["sha256"]
                result = json.loads(gzip.decompress(result_raw))
                assert result["scene"] == "A" and result["num_cores"] == 1
                assert result["execution_mode"] == "singlecore" and result["input_graph"] == f"case_{case}.json"
                base = result["makespan"]
                assert type(base) in (int, float) and base > 0
                run_path = f"{baseline_dir}/{case}/run.json"
                run_raw = git("show", commit + ":" + run_path)
                run = json.loads(run_raw)
                assert run["status"] == "ok" and run["returncode"] == 0 and run["case_id"] == case
                assert run["graph_sha256"] == graph_hash and run["config_sha256"] == config_hash
                assert run["official_code_hash"] == code_hash and run["entrypoint"] == b["entrypoint"]
                assert run["makespan_cycles"] == base
                assert run["artifacts"]["result.json"]["sha256"] == sha(result_raw)
                assert run["artifacts"]["result.json"]["raw_sha256"] == sha(gzip.decompress(result_raw))
                local = out / "evidence/baselines" / case
                local.mkdir(parents=True, exist_ok=True)
                (local / "result.json.gz").write_bytes(result_raw)
                (local / "run.json").write_bytes(run_raw)
                baseline_info[case] = {**b, "makespan_cycles": base, "source_commit": commit,
                    "source_feed": b_record["source"], "source_record_id": b_record["id"],
                    "run_path": run_path, "run_sha256": sha(run_raw), "result_number_type": type(base).__name__,
                    "local_result": str((local / "result.json.gz").relative_to(out)),
                    "identity_and_original_bytes_verified": True}
            except (AssertionError, KeyError, FileNotFoundError, subprocess.CalledProcessError) as error:
                skipped.append({"case_id": case, "reason": repr(error)})
                continue
            for k in range(1, 6):
                best, single = cells[case, k], one_algo[case, k]
                for record in (best, single):
                    assert record["eligible"] and record["baseline_verified"]
                    assert record["evaluator"]["route"] == "E0"
                    assert all(record["identity"].get(key) == v for key, v in identity.items())
                    assert abs(record["metrics"]["baseline_speedup"] - base / record["metrics"]["makespan_cycles"]) < 1e-12
                cp, max_op = structure["critical_path_cycles"], structure["max_op_cycles"]
                pipe_lb = max((w + k - 1) // k for w in structure["pipe_work_cycles"].values())
                lower = max(cp, max_op, pipe_lb)
                observed = best["metrics"]["makespan_cycles"]
                single_time = single["metrics"]["makespan_cycles"]
                assert lower <= observed and lower <= single_time
                upper = Fraction(base) / lower
                speed = Fraction(base) / Fraction(observed)
                single_speed = Fraction(base) / Fraction(single_time)
                rows.append({"case_id": case, "cores": k, "graph_sha256": graph_hash,
                    "compute_ops": structure["compute_ops"], "critical_path_cycles": cp,
                    "max_op_cycles": max_op, "pipe_work_lower_cycles": pipe_lb,
                    "M_work_cycles": structure["pipe_work_cycles"].get("PIPE_M", 0),
                    "V_work_cycles": structure["pipe_work_cycles"].get("PIPE_V", 0),
                    "lower_bound_cycles": lower, "official_baseline_cycles": base,
                    "speedup_upper": float(upper), "speedup_upper_exact": str(upper),
                    "snapshot_best_cycles": observed, "snapshot_best_speedup": float(speed),
                    "single_solver_cycles": single_time, "single_solver_speedup": float(single_speed),
                    "relaxed_headroom_speedup": float(upper - speed),
                    "relaxed_mean_contribution_div100": float((upper - speed) / 100),
                    "best_algorithm": best["algorithm_id"], "best_solver_commit": best["solver_commit"],
                    "best_record_id": best["id"], "best_result_sha256": best["artifacts"]["result"]["sha256"],
                    "single_solver_record_id": single["id"],
                    "baseline_result_sha256": b["result"]["sha256"]})
    dump(out / "structures.json", structures)
    dump(out / "baselines.json", baseline_info)
    with (out / "bounds.csv").open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)
    targets = {2: 2.28, 3: 3.23, 4: 4.09, 5: 4.76}
    aggregate, top = {}, {}
    for k in range(1, 6):
        subset = [r for r in rows if r["cores"] == k]
        def exact_speed(row, column):
            return Fraction(row["official_baseline_cycles"]) / Fraction(row[column])
        def exact_contribution(row):
            return (Fraction(row["speedup_upper_exact"]) - exact_speed(row, "snapshot_best_cycles")) / 100
        def mean(column):
            return sum(exact_speed(r, column) for r in subset) / len(subset)
        ordered = sorted(subset, key=lambda r: (-r["relaxed_mean_contribution_div100"], r["case_id"]))
        top[k] = ordered[:20]
        goal = targets.get(k)
        best_mean = mean("snapshot_best_cycles")
        gap = None if goal is None else max(Fraction(str(goal)) - best_mean, 0)
        prefix, min_cases = Fraction(0), None
        for i, row in enumerate(ordered, 1):
            prefix += exact_contribution(row)
            if gap is not None and prefix >= gap and min_cases is None:
                min_cases = i
        upper_mean = sum(Fraction(r["speedup_upper_exact"]) for r in subset) / len(subset)
        aggregate[k] = {"n": len(subset), "population": 100, "is_full_population": len(subset) == 100,
            "mean_speedup_upper": float(upper_mean), "mean_speedup_upper_exact": str(upper_mean),
            "history_best_mean": float(best_mean), "single_solver_mean": float(mean("single_solver_cycles")),
            "target": goal, "target_not_excluded_by_bound": None if goal is None else goal <= upper_mean,
            "target_gap_from_snapshot": None if gap is None else float(gap),
            "relaxed_remaining_mean_space": float(upper_mean - best_mean),
            "top5_relaxed_mean_space": float(sum(exact_contribution(r) for r in ordered[:5])),
            "minimum_cases_needed_if_each_reaches_bound": min_cases,
            "last_quantity_scope": "optimistic necessary count for improving this archived historical combination; not sufficient for a single solver"}
    dump(out / "top-contributors.json", top)
    summary = {"snapshot_as_of": snapshot["as_of"], "snapshot_cursor": snapshot["cursor"],
        "snapshot_record_count": snapshot["record_count"], "archived_p3_records": len(records),
        "archived_snapshot_as_of": archived_snapshot["as_of"],
        "single_solver_snapshot_as_of": filtered["as_of"] if uses_live_snapshot else snapshot["as_of"],
        "uses_live_api_readback": uses_live_snapshot, "new_calls": {"solver": 0, "E0": 0, "E1": 0, "E2": 0},
        "graphs": len(structures), "matched_baselines": len(baseline_info), "skipped": skipped,
        "copy_contraction_extra_edge_cases": [c for c, s in structures.items() if s["extra_copy_contracted_edges"]],
        "total_compute_ops": sum(s["compute_ops"] for s in structures.values()),
        "multiple_producer_cases": [c for c, s in structures.items() if s["multiple_original_producer_tensors"]],
        "zero_cycle_compute_ops": sum(s["compute_cycles_zero_count"] for s in structures.values()),
        "pipe_set": sorted({p for s in structures.values() for p in s["pipe_work_cycles"]}),
        "full_solver": {"algorithm_id": "q3-structure-selected-online",
            "solver_commits": sorted({r["solver_commit"] for r in one_algo.values()}),
            "run_ids": sorted({r["run_id"] for r in one_algo.values()}), "n": 500},
        "by_cores": aggregate,
        "warning": "Relaxed upper limits are not achievable performance promises. Targets were supplied as numbers; screenshot's P3/config/baseline identity is not authenticated."}
    dump(out / "summary.json", summary)
    identity = {"generated_at": datetime.now(timezone.utc).isoformat(), "read_repo_head": source_commit,
        "official_code_hash": code_hash, "official_code_hash_definition": manifest["official_code_hash_definition"],
        "source_manifest_sha256": sha(manifest_raw), "config_sha256": config_hash,
        "case_archive": manifest["case_archive"], "official_code_files": code_records,
        "snapshot_repo_path": str(snapshot_path.relative_to(root)), "snapshot_zip_sha256": sha(snapshot_raw),
        "snapshot_cells_sha256": sha(cells_raw), "archived_snapshot_records_sha256": sha(records_raw),
        "snapshot_cells_file": "evidence/live-p3-cells.json" if uses_live_snapshot else "source-snapshot.zip:p3-cells.json",
        "single_solver_cells_sha256": sha(filtered_raw) if uses_live_snapshot else None,
        "baseline_source_commits": sorted({b["source_commit"] for b in baseline_info.values()}),
        "scripts_import_official_code": False, "no_plan_construction": True,
        "new_evaluator_calls": 0, "writes_only": str(out)}
    dump(out / "identity.json", identity)
    print(json.dumps({"aggregate": aggregate, "top5_k5": [r["case_id"] for r in top[5]][:5],
                      "skipped": skipped, "extra_copy_cases": summary["copy_contraction_extra_edge_cases"]}, indent=2))


if __name__ == "__main__":
    main()
