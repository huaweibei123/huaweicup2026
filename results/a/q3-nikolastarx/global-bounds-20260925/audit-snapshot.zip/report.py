"""Format existing static audit outputs; no evaluation or plan construction."""
import csv
import hashlib
import json
from pathlib import Path
import platform

root = Path(__file__).resolve().parent
summary = json.loads((root / "summary.json").read_text())
structures = json.loads((root / "structures.json").read_text())
top = json.loads((root / "top-contributors.json").read_text())
identity = json.loads((root / "identity.json").read_text())
top_rows = []
for k in range(2, 6):
    for rank, row in enumerate(top[str(k)], 1):
        s = structures[row["case_id"]]
        top_rows.append({"cores": k, "rank": rank, "case_id": row["case_id"],
            "current_speedup": row["snapshot_best_speedup"], "upper_speedup": row["speedup_upper"],
            "relaxed_mean_contribution": row["relaxed_mean_contribution_div100"],
            **{key:s[key] for key in ("compute_ops", "M_work_fraction", "V_work_fraction",
                "weak_components", "largest_component_ops", "largest_component_fraction",
                "critical_path_cycles", "cp_over_max_pipe_work", "source_ops", "sink_ops",
                "max_fanin", "max_fanout", "join_ops", "fork_ops")}})
with (root / "top20-structure.csv").open("w", encoding="utf-8", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(top_rows[0])); w.writeheader(); w.writerows(top_rows)
k5 = [r for r in top_rows if r["cores"] == 5]
single = [r["case_id"] for r in k5 if r["weak_components"] == 1]
dominant = [r["case_id"] for r in k5 if r["weak_components"] > 1 and r["largest_component_fraction"] >= .75]
distributed = [r["case_id"] for r in k5 if r["weak_components"] > 1 and r["largest_component_fraction"] < .75]
families = {"classification_scope": "Descriptive only; 75% means fraction of compute nodes, not work or a proved algorithm family.",
    "k5_top20_single_component": single, "k5_top20_multiple_components_largest_at_least_75pct_nodes": dominant,
    "k5_top20_other_multicomponent": distributed,
    "k5_top20_both_M_and_V": sum(r["M_work_fraction"] > 0 and r["V_work_fraction"] > 0 for r in k5),
    "k5_top20_M_majority_work": sum(r["M_work_fraction"] > .5 for r in k5),
    "k5_top20_cp_below_max_pipe_work_div5": all(r["cp_over_max_pipe_work"] <= .2 for r in k5),
    "k5_top20_max_fanin_range": [min(r["max_fanin"] for r in k5), max(r["max_fanin"] for r in k5)],
    "k5_top20_max_fanout_range": [min(r["max_fanout"] for r in k5), max(r["max_fanout"] for r in k5)],
    "k5_top20_relaxed_mean_contribution_sum": sum(r["relaxed_mean_contribution"] for r in k5)}
(root / "top20-structure-summary.json").write_text(json.dumps(families, indent=2) + "\n")
table = ["| 核数 | 单一固定求解器均值 | 历史最优组合均值 | 用户目标 | 严格松弛上界 | 到目标差距 | 至少需改善图数* |",
         "|---|---:|---:|---:|---:|---:|---:|"]
for k in range(2, 6):
    a = summary["by_cores"][str(k)]
    table.append(f"| {k} | {a['single_solver_mean']:.6f} | {a['history_best_mean']:.6f} | {a['target']:.2f} | {a['mean_speedup_upper']:.6f} | {a['target_gap_from_snapshot']:.6f} | {a['minimum_cases_needed_if_each_reaches_bound']} |")
top_table = ["| 图 | 当前五核比 | 松弛上界 | 对全100均值最多增量 | M工作占比 | 弱组件数 | 最大组件/计算节点 | CP/max-pipe-work | 最大扇入/出 |",
             "|---|---:|---:|---:|---:|---:|---:|---:|---:|"]
for r in k5:
    top_table.append(f"| {r['case_id']} | {r['current_speedup']:.3f} | {r['upper_speedup']:.3f} | {r['relaxed_mean_contribution']:.6f} | {100*r['M_work_fraction']:.1f}% | {r['weak_components']} | {r['largest_component_ops']}/{r['compute_ops']} | {r['cp_over_max_pipe_work']:.3f} | {r['max_fanin']}/{r['max_fanout']} |")
text = f"""# P3 全100图结构下界与平均加速比上界（零评分）

**四个目标都没有被该下界排除，但这不证明可达。** 五核平均松弛上界为 **6.140526**；本次历史最优组合为 **3.771725**，到用户目标4.76差 **0.988275**。即使每次被改善的图都能达到本松弛界，至少也要改善18图；前五图全部达到界仍最多增加约 **{summary['by_cores']['5']['top5_relaxed_mean_space']:.6f}**，不足以补齐差距。因此需要覆盖较广结构族的构造，不能把少数样例成功直接外推全100平均。

## 固定范围与来源

- 输入：冻结官方100张原图，1～5核；全100图逐字节匹配 `source-manifest.json` 与原始 case ZIP，10份官方Python源码及配置也逐字节核对。总计算操作 {summary['total_compute_ops']}，不包含原 COPY。
- 分母：100份既有 `singlecore_evaluate.evaluate_singlecore` E0 原始gzip，均从固定 Git 提交 `{identity['baseline_source_commits'][0]}` 读取；逐例检查图/config/official hash、run收据、result SHA、解压后SHA、`execution_mode=singlecore`、scene A及num_cores=1。**100匹配，0缺失、0补造、0重跑。** 原件和run保存在 `evidence/baselines/`，身份索引 `baselines.json`。
- 真实P3成绩：只读中央已确认的 `GET /api/v1/cells?problem=P3`，as-of **{summary['snapshot_as_of']}**；单算法筛选 as-of **{summary['single_solver_snapshot_as_of']}**。两次读回cursor同为 **{summary['snapshot_cursor']}**、各500格；中央全问题记录数{summary['snapshot_record_count']}。原始JSON和HTTP读回元数据见 `evidence/live-*.json`。不是持续更新到你阅读此报告的时刻。
- 历史最优是不同算法/版本逐格赢家的组合，**不是一个已实现的单一求解器**。单一固定求解器为 `{summary['full_solver']['algorithm_id']}`，源 `{summary['full_solver']['solver_commits'][0]}`，同一run `{summary['full_solver']['run_ids'][0]}` 全500格。两列均使用本次验证的同一100分母，逐例比值取算术平均。
- P3 numerator采用中央已核原件的 eligible E0 记录，本任务核对冻结身份与分母比值；**未另行下载并逐条解压500份P3结果，未独立复跑**。分母原件则本任务全部实际读取并核SHA。
- 原15:57快照ZIP继续保留于 `evidence/source-snapshot.zip`；本报告数值使用更新的16:33读回，不混算两个快照。两份快照之间包括Fang等新增记录，旧排序可能变化。
- 用户图一给出的2.28/3.23/4.09/4.76仅作为数值目标；该截图对应的P3/config/固定代码/同一分母身份仍未取得，不能当作本问题已验收成绩。

## 下界推导与适用范围

令V为全部原非COPY操作，`d(v)=max(1, cycles[v])`。每个原操作完整执行一次，不能切开、替换或重复计工作。计算依赖D只取两类：原 direct compute op→op，和同一个原tensor的原compute producer→compute consumer。令CP为D上的最长节点权路径，`W_p=Σ_{{pipe(v)=p}}d(v)`，`Dmax=max_v d(v)`。对任一合法k核P3执行：

```
L(case,k) = max(CP, max_p ceil(W_p/k), Dmax)
Makespan(case,k) >= L(case,k)
S_upper(case,k) = official_singlecore_Makespan(case) / L(case,k)
mean_speedup(k) <= (1/100) * Σ_case S_upper(case,k)
```

1. **时长与覆盖**：冻结 `schedule_step3.py:74–83` 的 `_op_duration` 对非COPY返回 `max(1,cycles)`；`_uses_ddr_bandwidth`只作用于COPY，Cache也只作用于COPY_IN。P3 task建图在 `multicore_cut_evaluate_problem_3.py:93–94` 原样复制每个被分配的原compute op；Step2只插COPY并保持原op。这100图全为正整数cycles、只有M/V计算pipe，没有零时长或其他计算pipe歧义。
2. **管线资源**：`schedule_step3.py:29–30` 给 `PIPE_SLOTS=1`；P3 `:529–554` 用 `(core_id,pipe)` 执行器限制每核同pipe一条在飞。因此k个核在同一pipe有k个串行槽。至少一个核分得整数工作量≥ceil(W_p/k)，其完成时间至少如此。M与V可重叠，所以不能把M+V再直接除k充作这个下界。
3. **原依赖CP**：P3 `_build_scene_b_tasks` 对同核tensor/direct保留依赖，跨核用source COPY_OUT→target COPY_IN桥接，原计算先后关系仍在。这里所有COPY时长、跨核500、带宽、cache、spill和容量门控均从下界中删去，只保留原计算先后和时长。因此最长原计算链必须串行，其权和≤真实Makespan。Step2重命名tensor会改直接边，但通过COPY保留数据流，不会让原消费者早于其原计算producer。
4. **COPY收缩风险实查**：审计独立解析原tensor/direct边，再单独计算排除COPY后的收缩边作差；**100/100差集为空**，且原tensor无多producer。CP没有调用`Index.pred`或把收缩边自动算作P3约束。额外边若存在也只记录、不会加入本CP；需要研究更强边时必须另证。`structures.json`逐图保留计数、差集、CP节点证书及权和。
5. 本下界不依赖待选plan、子图是否singleton或具体分核；既有`pipe_bound.py`的singleton限制来自它另加的方案pipe-FIFO边，本报告完全不加这些边，因此这里不能借用其更强界。忽略约束得到的是**松弛下界**，不是调度器或可提交方案，也不保证能同时达到各管线的均衡与CP极限。

`Dmax`理论上已包含于CP，仍显式列出供检查；所有500格都通过 `L <= 当前E0 Makespan` 的算术一致性检查。这是对推导和数据的旁证，不能替代证明或新E0验收。平均上界大于k不构成错误：分母是固定官方基线而非最优单核下界，且P3语义不同；本报告不据此宣称真机超线性加速或某个Cache因果收益。

## 全100平均

{chr(10).join(table)}

*最后一列：将每图可贡献的最大均值增量 `Δ_i=(B_i/L_i-B_i/T_i)/100` 降序排列，最小m使前m项之和≥目标减当前均值。即使这些图全部达到松弛界，也至少要改变这么多图；真实需要数可能更多，甚至目标不可达。该数针对本次历史组合，而非单算法的已保证改进数。k1上界为{summary['by_cores']['1']['mean_speedup_upper']:.6f}，仅作附表，不是本轮目标。

## 五核贡献上界前20图

下表排序依据对全100算术平均的**绝对增量**，不是相对百分比或最快方案收益承诺；相同指标的2/3/4核前20见 `top20-structure.csv`、`top-contributors.json`。

{chr(10).join(top_table)}

这些前20图的松弛增量总和为 {families['k5_top20_relaxed_mean_contribution_sum']:.6f}。044、069、071已经存在Fang相关研发记录，本表只量化剩余松弛空间，**不重新认领这些任务**，也不把四核成果外推为五核成绩。

### 已观测的共同结构

- 全20图均同时有M/V计算工作，其中{families['k5_top20_M_majority_work']}图M工作占多数，其他图V占多数。M工作占比只是时长工作量比例，不是性能瓶颈或等待时间的实测归因。
- 单弱组件 {len(single)} 图：{', '.join(single)}。分量级整体放核会限制这些图利用核间并行；但本审计没有构造新切法。
- 多组件且最大组件至少占75%计算节点 {len(dominant)} 图：{', '.join(dominant)}。这只是按节点数量描述主导组件，不能自动替代按工作量判断。
- 其他多组件 {len(distributed)} 图：{', '.join(distributed)}。这些图不能一律归为“拆最大组件就够了”；原组件分配、M/V重叠和边界代价仍需单独解释。
- 前20最大扇入全为2，最大扇出为2～14，包含重聚与广播。全20的CP/max-pipe-work≤0.2，所以**五核这个最基础界都由pipe工作下界主导**；暂未被原计算长链卡到这个松弛极限。这不是证明通信/资源FIFO增强关键路也短，更不是attention结构识别证明。

## 文件、复现与验证边界

- `bounds.csv`：100×5=500行，含图hash、M/Vwork、CP、最大op、逐格L/B/比值/上界/均值贡献、当前record ID/算法/源/result SHA。
- `structures.json`：全100原图结构、原图hash、CP节点证书、COPY桥差集。
- `baselines.json`、`evidence/baselines/`：100份固定baseline原件和run；没有缺失项。
- `identity.json`、`evidence/source-manifest.json`、`evidence/official/code/`：源码/config/输入原ZIP和各文件hash；总代码hash `{identity['official_code_hash']}`，config `{identity['config_sha256']}`。
- `summary.json`、`top20-structure.csv`、`top20-structure-summary.json`：完整均值、目标差距与结构归类。`MANIFEST.json`对本目录逐文件记录大小/hash（不自包含）。
- 全部代码仅Python标准库，**没有导入或调用solver/E0/E1/E2，没有构造plan，没有修改仓库或中央服务，没有发GitHub消息**。读取现有完整baseline结果不算新评价。

复现（使用已保存的API原件，不会自动请求更新快照）：

```sh
python3 -B /tmp/q3-global-bound-audit/audit.py --repo /PATH/TO/q3-core-nikolastarx --output /tmp/q3-global-bound-audit
python3 -B /tmp/q3-global-bound-audit/report.py
```

读回当时本机Python `{platform.python_version()}`；这只是数学审计，不报告新算法求解时延，不构成跨平台或本机性能复评。
"""
(root / "README.md").write_text(text, encoding="utf-8")
files = []
for p in sorted(root.rglob("*")):
    if p.is_file() and p.name != "MANIFEST.json":
        raw = p.read_bytes()
        files.append({"path": str(p.relative_to(root)), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()})
(root / "MANIFEST.json").write_text(json.dumps({"files": files, "new_calls": summary["new_calls"],
    "self_excluded": "MANIFEST.json", "raw_graph_hashes": {case: s["graph_sha256"] for case,s in structures.items()}}, indent=2)+"\n", encoding="utf-8")
print(json.dumps({"files": len(files), "bytes": sum(f["bytes"] for f in files), "top20_structure": families}, indent=2))
