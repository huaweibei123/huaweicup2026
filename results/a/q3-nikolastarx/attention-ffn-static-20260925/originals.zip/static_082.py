"""One 082/k4 FFN static construction and strict bound; no solver CLI or E0."""
from collections import defaultdict
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/Users/nikolastar/Projects/huaweicup2026/.worktrees/q3-core-nikolastarx')
OUT = Path(__file__).resolve().parent
OLD = '80fabde1bd49faf28765d3caa8541780579d89d4'
EXPECTED = 'f48ad288c047cbdd61e168ba7d571431218b8115a6563088ed84a5725681682b'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
encoded = lambda value: (json.dumps(value,separators=(',',':'))+'\n').encode()
dump = lambda path,obj: path.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
git = lambda *a: subprocess.check_output(['git','-C',str(ROOT),*a])
sources = ('src/q3/attention_rows.py','src/q3/construct.py','src/q3/pipe_bound.py')
before = {p:sha((ROOT/p).read_bytes()) for p in sources}
assert before[sources[0]]==EXPECTED
manifest = json.loads((ROOT/'docs/a/source-manifest.json').read_bytes())
frozen = {f['path']:f['sha256'] for f in manifest['files']}
for p,digest in frozen.items():
    if p.startswith('code/'):
        assert sha((ROOT/'data/raw/a/official'/p).read_bytes())==digest
old_dir = ROOT/'results/a/q3-nikolastarx/attention-20260925/run'
old_cell = old_dir/'cells/082-k4-attention-rows-e0'
batch_raw=(old_dir/'batch.json').read_bytes()
batch=json.loads(batch_raw)
assert batch['solver_commit']==OLD and batch['official_sha256']==manifest['official_code_hash']
run_raw=(old_cell/'run.json').read_bytes();run=json.loads(run_raw)
old_artifacts={}
for key in ('plan','result','trace'):
    ref=run['artifacts'][key];raw=(ROOT/ref['path']).read_bytes()
    assert sha(raw)==ref['sha256']
    name={'plan':'old-plan.json','result':'old-result.json.gz','trace':'old-receipt.json'}[key]
    (OUT/name).write_bytes(raw)
    old_artifacts[key]={**ref,'local_copy':name}
(OUT/'old-run.json').write_bytes(run_raw)
(OUT/'old-batch.json').write_bytes(batch_raw)
old_plan=json.loads((OUT/'old-plan.json').read_bytes())
old_result=json.loads(gzip.decompress((OUT/'old-result.json.gz').read_bytes()))
old_receipt=json.loads((OUT/'old-receipt.json').read_bytes())
old_meta=old_receipt['candidates'][0]['metadata']
assert old_result['makespan']==old_receipt['makespan']==183595
assert old_result['problem']==3 and old_result['num_cores']==4
assert old_result['data_movement_bytes']['added_copy_bytes']==3557904
assert len(old_meta['ffn_diamonds'])==21 and sum(r['split'] for r in old_meta['ffn_diamonds'])==19
old_source_raw=git('show',OLD+':src/q3/attention_rows.py')
assert sha(old_source_raw)==batch['stages'][0]['source_input_sha256']['src/q3/attention_rows.py']
(OUT/'old-attention_rows.py').write_bytes(old_source_raw)

started=datetime.now(timezone.utc).isoformat()
t0=time.perf_counter()
sys.dont_write_bytecode=True
sys.path.insert(0,str(ROOT))
from src.q3.attention_rows import construct
from src.q3.construct import Index, derive_multicore_plan
from src.q3.pipe_bound import analyze
from evaluation_validation import read_required_settings
import_elapsed=time.perf_counter()-t0
graph_path=ROOT/'data/raw/a/official/data/case_082.json'
graph_raw=graph_path.read_bytes();graph=json.loads(graph_raw)
graph_hash=sha(graph_raw)
config_raw=(ROOT/'data/raw/a/official/data/config.txt').read_bytes()
config_hash=sha(config_raw)
assert graph_hash==frozen['data/case_082.json']==run['identity']['graph_sha256']==old_receipt['graph_sha256']
assert config_hash==frozen['data/config.txt']==run['identity']['config_sha256']==old_receipt['config_sha256']
delay=read_required_settings(ROOT/'data/raw/a/official/data/config.txt','multicore_scene_b',
                            ('cross_core_copy_delay_cycles',))['cross_core_copy_delay_cycles']
assert delay==500 and old_result['cross_core_copy_delay_cycles']==delay
t=time.perf_counter();index=Index(graph);index_elapsed=time.perf_counter()-t
t=time.perf_counter();plan,meta=construct(index,4,cross_delay=delay,pack_ffn=True);construct_elapsed=time.perf_counter()-t
t=time.perf_counter();view=derive_multicore_plan(graph,plan);validate_elapsed=time.perf_counter()-t
t=time.perf_counter();bound=analyze(graph,plan,delay);bound_elapsed=time.perf_counter()-t
plan_raw=encoded(plan)
(OUT/'new-plan.json').write_bytes(plan_raw)
dump(OUT/'new-meta.json',meta)
dump(OUT/'new-pipe-bound.json',bound)
pipeline_elapsed=time.perf_counter()-t0

def owner_of(plan):
    core_of={sg:c for c,word in enumerate(plan['core_schedules']) for sg in word}
    return {int(u):core_of[sg] for u,sg in plan['node_to_subgraph'].items()}

old_owner,new_owner=owner_of(old_plan),owner_of(plan)
assert set(new_owner)==set(index.ops) and len(set(plan['node_to_subgraph'].values()))==len(index.ops)
assert len(plan['core_schedules'])==4
scheduled=[sg for word in plan['core_schedules'] for sg in word]
assert len(scheduled)==len(set(scheduled))==len(index.ops)
assert set(scheduled)==set(plan['node_to_subgraph'].values())
ops={o['id']:o for o in graph['ops']}
tensor_by_id={t['id']:t for t in graph['tensors']}
outputs,consumers=defaultdict(set),defaultdict(set)
for edge in graph['edges']:
    u,v=edge['source'],edge['target']
    if u in ops and v in tensor_by_id: outputs[u].add(v)
    elif u in tensor_by_id and v in ops: consumers[u].add(v)

def remote_internal(nodes,owner):
    result=[]
    for u in nodes[:3]:
        for tensor in sorted(outputs[u]):
            assert consumers[tensor]<=set(nodes), 'nonterminal raw consumer outside diamond'
            dest=sorted({owner[v] for v in consumers[tensor] if owner[v]!=owner[u]})
            if dest: result.append({'tensor':tensor,'bytes':tensor_by_id[tensor]['size'],
                                    'producer_core':owner[u],'destination_cores':dest})
    return result

diamonds=[]
for old in old_meta['ffn_diamonds']:
    nodes=old['nodes']
    previous,current=remote_internal(nodes,old_owner),remote_internal(nodes,new_owner)
    assert previous==old['remote_internal_tensors']
    assert len({new_owner[u] for u in nodes})==1
    diamonds.append({'nodes':nodes,'old_cores':[old_owner[u] for u in nodes],
        'new_cores':[new_owner[u] for u in nodes],
        'old_split':len({old_owner[u] for u in nodes})>1,'new_split':False,
        'old_remote_internal_tensors':previous,'new_remote_internal_tensors':current,
        'old_internal_payload_bytes_proxy':sum(t['bytes']*len(t['destination_cores']) for t in previous),
        'new_internal_payload_bytes_proxy':sum(t['bytes']*len(t['destination_cores']) for t in current)})
assert meta['packed_ffn_count']==len(diamonds)==21
assert all(not r['split'] for r in meta['ffn_diamonds'])
assert {tuple(r['nodes']) for r in meta['ffn_diamonds']}=={tuple(r['nodes']) for r in old_meta['ffn_diamonds']}
assert sha(encoded(graph))==sha(encoded(json.loads(graph_raw)))
assert before=={p:sha((ROOT/p).read_bytes()) for p in sources}
dump(OUT/'diamond-comparison.json',diamonds)
lower=bound['with_cross_core_delay']['lower_bound_cycles']
summary={'case_id':'082','cores':4,'pack_ffn':True,'started_at':started,
    'finished_at':datetime.now(timezone.utc).isoformat(),
    'new_calls':{'solver_entrypoint':0,'E0':0,'E1':0,'E2':0,'static_construct':1},
    'input_sha256':graph_hash,'config_sha256':config_hash,'official_sha256':manifest['official_code_hash'],
    'source_before':before,'source_after':{p:sha((ROOT/p).read_bytes()) for p in sources},
    'source_commit_scope':'Current modified source is identified by SHA256; HEAD alone does not contain this optional switch yet.',
    'read_repo_head':git('rev-parse','HEAD').decode().strip(),'old_as_run_solver_commit':OLD,
    'old_source_sha256':sha(old_source_raw),'old_artifacts':old_artifacts,
    'old_run_sha256':sha(run_raw),'old_batch_sha256':sha(batch_raw),
    'original_compute_ops':len(index.ops),'new_covered_ops':len(new_owner),'all_subgraphs_singleton':True,
    'explicit_static_plan_validation':'passed; not E0 execution legality',
    'row_count':meta['row_count'],'packed_ffn_count':len(diamonds),'old_ffn_split_count':19,'new_ffn_split_count':0,
    'old_ffn_internal_remote_payload_bytes_proxy':sum(r['old_internal_payload_bytes_proxy'] for r in diamonds),
    'new_ffn_internal_remote_payload_bytes_proxy':sum(r['new_internal_payload_bytes_proxy'] for r in diamonds),
    'old_official_makespan':old_result['makespan'],'new_official_makespan':None,
    'old_official_extra_ddr_bytes':old_result['data_movement_bytes']['added_copy_bytes'],
    'new_official_extra_ddr_bytes':None,'old_spill_bytes':old_result['data_movement_bytes']['spill_added_copy_bytes'],
    'new_spill_bytes':None,'old_placement_proxy':old_meta['placement_proxy_makespan_cycles'],
    'new_placement_proxy':meta['placement_proxy_makespan_cycles'],
    'old_ready_proxy':old_meta['proxy_makespan_cycles'],'new_ready_proxy':meta['proxy_makespan_cycles'],
    'new_strict_L500':lower,'new_L0':bound['zero_delay']['lower_bound_cycles'],
    'can_rule_out_strict_improvement':lower>=old_result['makespan'],
    'old_makespan_minus_new_L500':old_result['makespan']-lower,
    'meaning':'L500 >= incumbent rules out strict Makespan improvement; L500 < incumbent is only failure to rule it out, not evidence of improvement.',
    'new_plan_sha256':sha(plan_raw),'same_plan_as_old':plan_raw==(OUT/'old-plan.json').read_bytes(),
    'static_timing_seconds':{'imports':import_elapsed,'Index':index_elapsed,'construct_including_internal_static_plan_validation':construct_elapsed,
        'additional_explicit_plan_validation':validate_elapsed,'strict_bound_including_its_Index_and_static_plan_validation':bound_elapsed,
        'pipeline_import_read_build_check_bound_plan_meta_bound_save':pipeline_elapsed},
    'timing_scope':'one local static pipeline only, excludes prior old-artifact audit and later comparison/report; not solver end-to-end or E0 wall',
    'payload_scope':'Distinct original internal tensor bytes per remote destination core; not official DDR/COPY/cache traffic; no expected quality claim'}
dump(OUT/'summary.json',summary)
(OUT/'new-attention_rows.py').write_bytes((ROOT/sources[0]).read_bytes())
print(json.dumps({k:summary[k] for k in ('old_official_makespan','packed_ffn_count','old_ffn_split_count','new_ffn_split_count',
    'old_ffn_internal_remote_payload_bytes_proxy','new_ffn_internal_remote_payload_bytes_proxy',
    'old_placement_proxy','new_placement_proxy','old_ready_proxy','new_ready_proxy','new_L0','new_strict_L500',
    'can_rule_out_strict_improvement','new_plan_sha256','static_timing_seconds')},indent=2))
