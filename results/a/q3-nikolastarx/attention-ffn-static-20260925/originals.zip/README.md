# 082 / 四核 FFN packing 静态检查（零官方评分）

新方案的严格 `L500=166910`，低于旧官方 Makespan **183595**，差16685周期。故不能用这条界排除新方案严格改善，但低下界本身**不证明新方案更优或官方可执行**。

本次仅调用一次 `construct(Index(graph),4,cross_delay=500,pack_ffn=True)`，并做显式 `derive_multicore_plan` 静态校验、严格 `pipe_bound.analyze`。没有运行solver CLI或E0/E1/E2，没有修改仓库、提交或发外部消息。

| 项目 | 80fabde1旧方案 | 新FFN packing静态方案 |
|---|---:|---:|
| 官方Makespan | 183595 | 未评分 |
| 官方额外搬运 added_copy_bytes | 3557904 B | 未评分 |
| 官方spill | 0 B | 未评分 |
| FFN diamond总数 | 21 | 21 |
| 跨核FFN数 | 19 | 0 |
| FFN内部远端payload代理 | 282624 B | 0 B |
| placement计算代理 | 183616 | 186474 |
| final ready计算代理 | 166318 | 166910 |
| 新方案严格L0 | — | 164910 |
| 新方案严格L500 | — | 166910 |

负向变化明确保留：placement代理增加2858周期，ready代理增加592周期。同核包装消除了这些diamond内部原tensor的跨核需求，但可能改变核负载与资源顺序，不能只凭payload改善认定Makespan会改善。

内部payload按每个原tensor的大小×不同远端目的核数计算，独立从原raw ports和新旧plan所有者重算；逐diamond旧值与receipt诊断一致。它不是官方DDR搬运量，**不能用3557904减282624预测新额外搬运**，也没有测量新Cache命中或spill。

## 静态覆盖与检查

- 4113/4113原计算节点恰好覆盖一次；4113个singleton子图，4个核序列，子图没有重复/遗漏。
- 42个attention row保留；21个原四算子FFN全部同核，没有克隆、算子融合或删边，原图内容未改。
- 每个diamond的非末节点原tensor消费者均在该diamond内；逐组所有者及内部payload见 `diamond-comparison.json`。末端外部消费者保持原边界。
- 静态计划校验通过。严格bound的singleton、M/V正整数时长、原tensor/direct依赖与COPY收缩一致等适用检查全部通过；保存 `new-pipe-bound.json` 的完整最长路证书。这里额外500来自同一冻结config，未把COPY服务、Cache、容量或spill代理当成已知开销。
- 下界中的 `execution_legality_proved=false` 保留：静态覆盖和顺序检查不等于官方执行验收。

## 身份和原件

原图 SHA-256：`f230fbc200ad75797f3024f84431d1d26f7747d6a284378ee83eabde77b7e70c`。config：`dcd10de54b23f8366428fb24e828812b1da9549e6eae4a3c3f38604fe5ae77b9`。冻结官方总代码：`de11a83db8d7c47ed328b15a7df71d613a833b16cd23ee9fe877999578a1ace0`。本次实际读取的10个官方源码均匹配冻结清单。

旧as-run solver commit：`80fabde1bd49faf28765d3caa8541780579d89d4`；原batch source-input指纹与该提交attention源码bytes一致。旧plan/result/receipt均按run引用SHA回读，完整副本为 `old-plan.json`、`old-result.json.gz`、`old-receipt.json`、`old-run.json`、`old-batch.json`。旧结果是实际现存官方原件；本次没有独立复跑。

新attention源码 SHA-256：`f48ad288c047cbdd61e168ba7d571431218b8115a6563088ed84a5725681682b`，Index及bound依赖哈希在summary，三者运行前后完全一致。新源码尚未由本任务提交，读取HEAD `80fabde1bd49faf28765d3caa8541780579d89d4` 不能代替修改后文件SHA身份。

新计划 SHA-256：**`2c35a3c2917c45650e1b1781bca205f92375c7df71f883c34e1c3a48f7b70a35`**；文件 `new-plan.json` 使用与现有safe_solve一致的compact JSON加末尾换行，只有两个提交字段。新meta完整保存在 `new-meta.json`，源文件快照 `new-attention_rows.py`，旧源码 `old-attention_rows.py`。

## 静态耗时

本地单次静态pipeline为 **0.208775秒**，包括模块导入、读图/配置、Index、一次构造、额外静态验证、严格bound及plan/meta/bound落盘。旧原件审计在此前、比较与报告在此后，未包含。Python启动和本次全部工具调度不在该计时内；这**不是完整solver或官方评估耗时**，不与旧端到端0.5668秒直接作速度比较。

| 分项 | 秒 |
|---|---:|
| 模块导入 | 0.027034 |
| 显式Index | 0.018902 |
| 构造（含内部静态校验） | 0.069076 |
| 额外显式静态校验 | 0.018188 |
| 严格bound（含其内部Index/静态校验） | 0.067306 |

实际脚本 `static_082.py`、输出 `run.log`、机器可读 `summary.json`、全部文件哈希 `MANIFEST.json`。本任务到此停止，没有派发正式一格评价。
