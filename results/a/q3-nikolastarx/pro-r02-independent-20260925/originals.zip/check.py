"""Independent direct DAG audit of the public Pro r02 prose. No solver or E0.

The original DAG, operation words and integer longest-path checker are written
here independently. No author attachment is imported, extracted, or executed.
"""
from collections import Counter
import hashlib
import heapq
import json
from pathlib import Path
import sys

P, G, DELTA, CORES = 524, 13, 500, 5
ADD_ORDER = [f'Q{i}' for i in range(6)] + ['U0', 'U1', 'U2', 'V', 'R']
CHILDREN = {f'Q{i}': (f'L{2*i}.4', f'L{2*i+1}.4') for i in range(6)}
CHILDREN.update(U0=('Q0', 'Q1'), U1=('Q2', 'Q3'), U2=('Q4', 'Q5'),
                V=('U0', 'U1'), R=('V', 'U2'))
DOUBLE_ADDS = ['Q0', 'Q1', 'Q2', 'Q3', 'U0', 'U1', 'V', 'Q5', 'Q4', 'U2', 'R']


def lane(j, first=1, last=4):
    return [f'L{j}.{r}' for r in range(first, last+1)]


def graph(stages):
    duration, successors = {}, {}
    for s in range(stages):
        for j in range(12):
            for r in range(1, 5):
                duration[s, f'L{j}.{r}'] = P
        for name in ADD_ORDER:
            duration[s, name] = G
    successors = {u: set() for u in duration}
    for s in range(stages):
        for j in range(12):
            if s:
                successors[s-1, 'R'].add((s, f'L{j}.1'))
            for r in range(1, 4):
                successors[s, f'L{j}.{r}'].add((s, f'L{j}.{r+1}'))
        for name, children in CHILDREN.items():
            for child in children:
                successors[s, child].add((s, name))
    assert len(duration) == 59*stages
    return duration, successors


def double_words(stages, special_first=True):
    words = [[] for _ in range(CORES)]
    for s in range(stages):
        a, b = ((0, 1) if s % 2 == 0 else (1, 0))
        stage = [[] for _ in range(CORES)]
        stage[a] = lane(2, 1, 2) + lane(0) + lane(10)
        stage[b] = lane(3) + lane(4) + lane(2, 3, 4)
        stage[2] = lane(9, 1, 2) + lane(5) + lane(8)
        stage[3] = lane(1) + lane(11) + lane(9, 3, 4)
        stage[4] = lane(6) + lane(7)
        if s == 0 and special_first:
            stage[a].append('Q5')
            stage[b].extend(n for n in DOUBLE_ADDS if n != 'Q5')
        else:
            stage[b].extend(DOUBLE_ADDS)
        for c, names in enumerate(stage):
            words[c].extend((s, name) for name in names)
    return words


def single_words(stages):
    words = [[] for _ in range(CORES)]
    stage = [lane(2, 1, 2)+lane(0)+lane(1)+['Q0'],
             lane(3)+lane(4)+lane(2, 3, 4)+['Q1'],
             lane(5)+lane(6)+lane(7)+['Q3', 'Q2', 'U0', 'U1', 'U2', 'V', 'R'],
             lane(8)+lane(9)+['Q4'], lane(10)+lane(11)+['Q5']]
    for s in range(stages):
        for c, names in enumerate(stage):
            words[c].extend((s, name) for name in names)
    return words


def a0_words(collectors):
    """Independently encode fixed lanes, then original pure/mixed ADD order."""
    lane_owner = [j*CORES//12 for j in range(12)]
    descendants = {f'L{j}.4': {j} for j in range(12)}
    for name in ADD_ORDER:
        descendants[name] = set.union(*(descendants[p] for p in CHILDREN[name]))
    words = [[] for _ in range(CORES)]
    for s, collector in enumerate(collectors):
        stage = [[] for _ in range(CORES)]
        for j in range(12):
            stage[lane_owner[j]].extend(lane(j))
        pure, mixed = [], []
        for name in ADD_ORDER:
            owners = {lane_owner[j] for j in descendants[name]}
            (pure if len(owners) == 1 else mixed).append((next(iter(owners)) if len(owners)==1 else collector, name))
        for c, name in pure + mixed:
            stage[c].append(name)
        for c, names in enumerate(stage):
            words[c].extend((s, name) for name in names)
    return words


def evaluate(stages, words, incoming_root_core=None, full_certificate=False):
    duration, original = graph(stages)
    flat = [u for word in words for u in word]
    assert len(words) == 5 and len(flat) == len(duration)
    assert len(set(flat)) == len(flat) and set(flat) == set(duration)
    owner = {u: c for c, word in enumerate(words) for u in word}
    adjacency = {u: {v: DELTA if owner[u] != owner[v] else 0 for v in vs}
                 for u, vs in original.items()}
    for word in words:
        for u, v in zip(word, word[1:]):
            adjacency[u][v] = max(adjacency[u].get(v, 0), 0)
    indegree = dict.fromkeys(duration, 0)
    for vs in adjacency.values():
        for v in vs:
            indegree[v] += 1
    starts = dict.fromkeys(duration, 0)
    if incoming_root_core is not None:
        for j in range(12):
            u = (0, f'L{j}.1')
            starts[u] = DELTA if owner[u] != incoming_root_core else 0
    ready = [u for u in duration if indegree[u] == 0]
    heapq.heapify(ready)
    finish, previous = {}, {}
    while ready:
        u = heapq.heappop(ready)
        finish[u] = starts[u] + duration[u]
        for v, lag in adjacency[u].items():
            candidate = finish[u]+lag
            if candidate > starts[v] or (candidate == starts[v] and u < previous.get(v, (10**9,''))):
                starts[v], previous[v] = candidate, u
            indegree[v] -= 1
            if indegree[v] == 0:
                heapq.heappush(ready, v)
    assert len(finish) == len(duration), 'enhanced original + full-core FIFO DAG contains cycle'
    assert finish[stages-1, 'R'] == max(finish.values())
    roots = [finish[s, 'R'] for s in range(stages)]
    increment = [roots[0]]+[roots[s]-roots[s-1] for s in range(1,stages)]
    # Validate the stronger per-position windows, not just the common-window bound.
    for s in range(stages):
        origin = roots[s-1] if s else 0
        a = owner[s-1, 'R'] if s else incoming_root_core
        b = owner[s, 'R']
        for j in range(12):
            depth = 4 if j < 8 else 3
            for r in range(1,5):
                u = (s, f'L{j}.{r}'); c = owner[u]
                assert starts[u]-origin >= (r-1)*P + (DELTA if a is not None and c != a else 0)
                assert finish[u] <= roots[s]-(4-r)*P-depth*G-(DELTA if c != b else 0)
    kinds = Counter()
    scalar_connections = set()
    for u, vs in original.items():
        for v in vs:
            if owner[u] == owner[v]:
                continue
            if u[0] != v[0]:
                kinds['broadcast_compute_edges'] += 1
                scalar_connections.add((u, owner[v]))
            elif u[1].startswith('L') and not u[1].endswith('.4'):
                kinds['vector_migration_edges'] += 1
            else:
                kinds['gather_compute_edges'] += 1
                scalar_connections.add((u, owner[v]))
    critical = [(stages-1,'R')]
    while critical[-1] in previous:
        critical.append(previous[critical[-1]])
    critical.reverse()
    result = {'stages':stages, 'operation_count':len(duration), 'coverage_exact':True,
        'original_plus_full_fifo_acyclic':True, 'all_position_windows_verified':True,
        'makespan_cycles':roots[-1], 'root_cores':[owner[s,'R'] for s in range(stages)],
        'root_finish_cycles':roots,'stage_increment_histogram':dict(sorted(Counter(increment).items())),
        'cross_dependency_counts':dict(kinds), 'distinct_scalar_source_destination_pairs':len(scalar_connections),
        'critical_path':[{'stage':s,'op':n,'core':owner[s,n],'start':starts[s,n],'end':finish[s,n]} for s,n in critical]}
    if full_certificate:
        result['per_core_words'] = words
        result['certificate'] = [{'stage':s,'op':n,'core':owner[s,n],'duration':duration[s,n],
            'start':starts[s,n],'end':finish[s,n]} for s,n in sorted(duration)]
    return result


def raw_isomorphism(repo, case, stages):
    """Known local recognizer only; no constructor or author code is invoked."""
    from src.q3.construct import Index
    from src.q3.stage_fork_join import recognize
    p = repo / f'data/raw/a/official/data/case_{case}.json'
    graph_json = json.loads(p.read_text())
    index = Index(graph_json)
    rec = recognize(index)
    assert len(rec['lane_ids']) == 12 and len(rec['stages']) == stages
    assert rec['signature'][0] == 4 and rec['signature'][1] == (524,)*4
    assert rec['signature'][-2:] == (32768,2)
    mapping = {}
    for s, st in enumerate(rec['stages']):
        for j, tid in enumerate(rec['lane_ids']):
            for r, u in enumerate(st['chains'][tid],1):
                mapping[s, f'L{j}.{r}'] = u
        for name in ADD_ORDER:
            expected = {mapping[s,p] for p in CHILDREN[name]}
            found = [u for u in st['join_order'] if index.pred[u] == expected]
            assert len(found) == 1 and index.duration(found[0]) == 13
            mapping[s,name] = found[0]
        assert mapping[s,'R'] == st['root']
    duration, successors = graph(stages)
    assert set(mapping.values()) == set(index.ops) and len(mapping) == len(index.ops)
    assert all(index.duration(mapping[u]) == duration[u] for u in duration)
    assert all(index.succ[mapping[u]] == {mapping[v] for v in successors[u]} for u in duration)
    return {'case':case, 'sha256':hashlib.sha256(p.read_bytes()).hexdigest(), 'stages':stages,
        'exact_labeled_compute_dag_isomorphism':True,'operation_count':len(mapping),
        'exact_raw_stage_guard_passed':True,'vector_bytes':32768,'scalar_bytes':2,
        'first_stage_original_aliases':{name:mapping[0,name] for _,name in duration if _==0},
        'official_evaluations':0,'solver_calls':0}


def window_capacity(T, previous_root_core=None, current_root_core=0):
    return sum(max(0, (T-3*G-(DELTA if previous_root_core is not None and c != previous_root_core else 0)
                       -(DELTA if c != current_root_core else 0)) // P) for c in range(CORES))


def main():
    repo=Path.cwd(); out=Path('/tmp/q3-pro-r02-independent')
    results={'official_evaluations':0,'solver_calls':0,'author_attachment_executions':0,
        'model':'5 cores; exact original compute DAG; indivisible V ops; per-core FIFO; remote completion-to-start lag 500',
        'lower_bound_capacities':{'first_at_5778':window_capacity(5778),
                                 'first_at_5779':window_capacity(5779),
                                 'later_same_root_at_6278':window_capacity(6278,0,0),
                                 'later_changed_root_at_6278':window_capacity(6278,0,1),
                                 'later_same_root_at_6279':window_capacity(6279,0,0),
                                 'later_changed_root_at_6279':window_capacity(6279,0,1)},'checks':[]}
    assert results['lower_bound_capacities']['first_at_5778'] == 46
    assert results['lower_bound_capacities']['later_same_root_at_6278'] == 47
    assert results['lower_bound_capacities']['later_changed_root_at_6278'] == 47
    for stages in (1,2,24,101,305):
        for name, maker, expected in (
                ('double_cut',double_words,6279*stages-500),
                ('single_cut',single_words,6379*stages),
                ('A0_alternate',lambda s:a0_words([0 if i%2==0 else 2 for i in range(s)]),6892*stages-39)):
            item=evaluate(stages,maker(stages),full_certificate=stages<=2)
            assert item['makespan_cycles']==expected, (name,stages,item['makespan_cycles'],expected)
            item.update(strategy=name,formula_expected=expected)
            results['checks'].append(item)
    alpha=[evaluate(1,a0_words([b]))['makespan_cycles'] for b in range(5)]
    matrix=[[evaluate(1,a0_words([b]),incoming_root_core=a)['makespan_cycles'] for b in range(5)] for a in range(5)]
    expected=[[7353,7353,6892,7353,7353],[7353,7379,7379,7379,7379],
        [6892,7379,7379,7379,7379],[7353,7379,7379,7379,7379],[7353,7379,7379,7379,7379]]
    assert alpha==[6853,6879,6879,6879,6879] and matrix==expected
    results['A0_first_costs']=alpha;results['A0_transition_matrix']=matrix
    results['first_double_without_special_Q5']=evaluate(1,double_words(1,special_first=False),full_certificate=True)
    assert results['first_double_without_special_Q5']['makespan_cycles']==5792
    results['isolated_later_double']=evaluate(1,double_words(1,special_first=False),incoming_root_core=0,full_certificate=True)
    assert results['isolated_later_double']['makespan_cycles']==6279
    results['raw_dag_checks']=[raw_isomorphism(repo,c,s) for c,s in (('051',24),('024',101),('016',305))]
    source_paths=['src/q3/stage_fork_join.py','src/q3/construct.py',
        'AI chats/20260924-Pro-P3-归约森林切分/完整问答-r02-20260924T165413Z.md']
    results['read_source_sha256']={p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in source_paths}
    results['checker_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    (out/'checks.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'status':'PASS','runs':len(results['checks']),'raw_cases':3,
        'values':[{k:r[k] for k in ('strategy','stages','makespan_cycles')} for r in results['checks']],
        'A0_alpha':alpha,'A0_D':matrix,'first_without_Q5_move':5792,
        'official_evaluations':0,'solver_calls':0},ensure_ascii=False,indent=2))


if __name__=='__main__':
    main()
