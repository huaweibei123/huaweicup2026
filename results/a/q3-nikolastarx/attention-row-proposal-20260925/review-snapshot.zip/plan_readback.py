from pathlib import Path
import json,hashlib,collections
root=Path('/Users/nikolastar/Projects/huaweicup2026/.worktrees/q3-core-nikolastarx');r=Path('/tmp/q3-attention-review');d=Path('/tmp/q3-attention-constructor-082');plan=json.loads((d/'plan.json').read_text());meta=json.loads((d/'meta.json').read_text());summary=json.loads((d/'summary.json').read_text());raw=json.loads((root/'data/raw/a/official/data/case_082.json').read_text());census=json.loads(Path('/tmp/q3-internal-separator-proposal/082-attention-rows.json').read_text());audit=json.loads((r/'static-evidence.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();source=root/'src/q3/attention_rows.py';assert sha(source)==summary['source_sha256'];(r/('attention_rows-'+summary['source_sha256'][:12]+'.py')).write_bytes(source.read_bytes())
ops={o['id']:o for o in raw['ops'] if o['op'] not in {'COPY_IN','COPY_OUT'}};allops={o['id'] for o in raw['ops']};tensors={t['id']:t for t in raw['tensors']};prod={};cons=collections.defaultdict(set)
for e in raw['edges']:
 if e['source'] in allops:prod[e['target']]=e['source']
 else:cons[e['source']].add(e['target'])
pred={u:set() for u in ops};succ={u:set() for u in ops}
for t,u in prod.items():
 if u in ops:
  for v in cons[t]&ops.keys():succ[u].add(v);pred[v].add(u)
assert set(plan)=={'node_to_subgraph','core_schedules'};mapping={int(k):v for k,v in plan['node_to_subgraph'].items()};assert set(mapping)==set(ops);reverse={v:u for u,v in mapping.items()};assert len(reverse)==len(ops);assert len(plan['core_schedules'])==5
owner={};seqs=[]
for c,seq in enumerate(plan['core_schedules']):
 word=[reverse[s] for s in seq];seqs.append(word)
 for u in word:assert u not in owner;owner[u]=c
 for u,v in zip(word,word[1:]):succ[u].add(v)
assert set(owner)==set(ops)
indeg={u:0 for u in ops}
for vs in succ.values():
 for v in vs:indeg[v]+=1
ready=collections.deque(u for u,d in indeg.items() if d==0);count=0
while ready:
 u=ready.popleft();count+=1
 for v in succ[u]:
  indeg[v]-=1
  if indeg[v]==0:ready.append(v)
assert count==len(ops)
for row in census['modules']:assert len({owner[u] for u in row['nodes']})==1
for block in meta['capsule_dispatch']:assert all(owner[u]==block['core'] for u in block['nodes'])
ffn=[]
for x in audit['ffn_diamonds']:
 ids=x['ops'];ns=set(ids);remote={(t,owner[u],owner[v],tensors[t]['size']) for t,u in prod.items() if u in ns for v in cons[t]&ns if owner[u]!=owner[v]};ffn.append({'ops':ids,'owners':[owner[u] for u in ids],'split':len({owner[u] for u in ids})>1,'remote_internal_tensor_bytes_proxy':sum(x[3] for x in remote)})
assert len(ffn)==len(meta['ffn_diamonds'])==21
for x,y in zip(ffn,meta['ffn_diamonds']):assert x['ops']==y['nodes'] and x['owners']==y['cores'] and x['split']==y['split'] and x['remote_internal_tensor_bytes_proxy']==y['remote_internal_tensor_bytes_proxy']
work=[{p:sum(ops[u]['cycles'] for u in owner if owner[u]==c and ops[u]['pipe']==p) for p in ['PIPE_M','PIPE_V']} for c in range(5)];assert work==meta['core_compute_work_cycles']
answer={'source_sha256':sha(source),'graph_sha256':sha(root/'data/raw/a/official/data/case_082.json'),'plan_sha256':sha(d/'plan.json'),'meta_sha256':sha(d/'meta.json'),'original_ops_covered_once':len(ops),'original_plus_full_core_orders_acyclic':True,'all_42_rows_single_owner':True,'owner_equals_placement_metadata':True,'ffn_count':len(ffn),'ffn_split_count':sum(x['split'] for x in ffn),'ffn_remote_internal_tensor_bytes_proxy':sum(x['remote_internal_tensor_bytes_proxy'] for x in ffn),'ffn':ffn,'work_by_core':work,'source_reported_static_proxy_only':{'placement':summary['placement_proxy'],'final':summary['final_proxy']},'checks_are_readback_not_reconstruction_or_evaluation':True,'new_solver_or_evaluator_runs':0}
(r/'plan-readback.json').write_text(json.dumps(answer,indent=2)+'\n');print(json.dumps({k:v for k,v in answer.items() if k!='ffn'},indent=2))
