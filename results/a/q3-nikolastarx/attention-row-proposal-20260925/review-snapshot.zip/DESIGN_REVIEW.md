# Attention-row placement review: 082, no new scoring

Status: recognizer/design review complete; production attention_rows.py review pending its author handoff. No solver, constructor or evaluator executed, no repository files modified. `static_readback.py` independently parses original tensor ports and computes graph counts only.

## What is verified

Input SHA256 `f230fbc200ad75797f3024f84431d1d26f7747d6a284378ee83eabde77b7e70c`; source Index SHA256 `942450f2751eb5b0cf4817d392acdd6e4316e751c48ea8e84b509d4ce1e97d73`.

All 42 claimed rows are disjoint, cover 3360 of 4113 original compute ops, have exact matching raw input/output tensor sets, exactly one escaping tensor produced by the final DIV, and no escaping non-final op consumer. The private Q raw consumers are inside their own row for all 42. A quotient built independently from raw producer/consumer edges has 795 vertices / 1596 edges and is acyclic; its complete edge list equals the proposal JSON. The actual 082 graph has no direct op→op edges and no original COPY bridging one compute op to another; this matters because the recognizer’s raw-port parser implicitly assumes alternating op/tensor edges.

The ADD-tree count check is sufficient for its structural intent: a binary ancestor cone with I internal nodes and L distinct leaves, I=L−1, has 2I=I+L−1 edges; connectedness then forbids reconvergent sharing inside this purported tree. The max-like REDUCE/SUB/RELU/ADD cone is only recognized structurally. Its numerical meaning is neither needed nor proved; retaining every original operation and edge avoids needing a softmax/maximum algebraic theorem.

The guard is conservative, not a general attention recognizer. The exact 12m−4 count and extra 2-byte input reject some valid motifs. That is acceptable if rejection is explicit and no failed candidate is silently treated as recognized.

## Legality: precise sufficient conditions

1. Row co-location is only an owner restriction. Any such assignment can be combined with one original-op global topological order and projected onto cores to produce a singleton plan whose **original compute plus per-core order graph** is acyclic. Every added order edge advances in the same global order. No quotient theorem is required for this existence fact.
2. If the implementation expands capsules contiguously, an acyclic quotient plus a topological internal order is sufficient to produce such a global order. Merely checking the quotient and then independently ordering each core is not sufficient.
3. Counterexample to arbitrary independent core order: original edges a→b and c→d; core0 order b,c and core1 order d,a induce a→b→c→d→a even though the original/quotient graph is a DAG and neither core violates an original same-core direct edge.
4. This is not full official legality. Frozen `stub_multicore_cut_and_schedule.py:105–110` explicitly says derive/validate does not prove execution feasibility. Official P3 additionally rebuilds COPY operations, runs Step2/Step3, enforces pipe FIFO and memory edges, and validates that expanded graph. Do not label a passed quotient or compute-only clock “official feasible.”

## P3 Task correction

Frozen `multicore_cut_evaluate_problem_3.py:69–70` states every core is merged into one Task, and lines244–280 prepare one Task for each declared core, even if its local graph is empty. Therefore a singleton op is **not** a Task, and a row submitted as one subgraph would not by itself create one Task per row. Retaining singleton IDs preserves per-operation submitted subgraph priorities; it does not preserve an old core assignment, Task contents, generated COPY sequence, spill behavior or reuse history. Avoid importing Q1 Task claims here.

The proposal’s reason to avoid row subgraph fusion is still useful: `_prioritize_task_seq` (51–67) buckets by submitted subgraph order and keeps internal Step1 order, so one row subgraph removes controllable internal priority freedom. The precise explanation should refer to priority granularity, not extra P3 Task boundaries.

## Two distinct atomicity risks

**Release barrier.** The first score MATMUL135 consumes Q114 and K115; it does not need V116, other K/V projections or final tail V134. The V projections enter weighted-value MATMUL201…207 after EXPs. Thus setting every row op release to max(all frontier arrivals) adds dependencies that do not exist. Per-op `max(pred_finish + applicable cross-core lag)` permits early score/max work before late V arrives. A single capsule-level max can be a conservative ranking feature, but should not be inserted as a common start barrier.

A minimal conceptual witness: row first M10 → V10 → final M1, plus a separate boundary needed only by the final op at time100. Per-op release permits finish101; a common release100 forces finish121. These are abstract compute times, not an E0 sample or a replacement for actual COPY arrivals.

**FIFO packing.** Even without that release barrier, committing all original ops of one row contiguously before considering another row restricts same-core M/V interleaving. A future last-M of row A can become the M FIFO head and block an otherwise ready first-M of row B during A’s V work. Separate per-pipe clocks alone do not remove this if the emitted op order is capsule-contiguous. If this is the first prototype, call it a restricted capsule-block heuristic. If “original ready scheduling” is claimed, placement should complete first and the final order should be generated by global **original-op** readiness, with M and V availability tracked separately.

The official readiness logic checks each pipe’s head (P3:441–471), not an arbitrary ready op. A compute-clock draft is a proxy, and cross-core `pred_finish+500` omits COPY_OUT/COPY_IN duration, bandwidth contention and memory-added delays. Never describe its virtual starts as actual official release times.

## Remaining FFN and projections

Outside rows are 753 ops with M313824 / V102366 cycles: **55.26% of all M work remains outside the rows**. Placing all of it on one core imposes at least313824 M cycles before COPY or waits, regardless of how well rows are split. Node coverage81.69% therefore greatly overstates work coverage.

Independent raw-port inspection finds **21 closed four-op FFN diamonds**:

- 18 full diamonds: M8240 / V1840, internal activation8192B.
- 3 tail diamonds: M2096 / V496, internal activation2048B.
- Combined M154608 / V34608. Every non-final node has no raw tensor consumer outside its diamond.

Example1289→1290→1291→1292, with the additional original1289→1291 edge; ops are MATMUL, SIGMOID, MUL, MATMUL. Keep the extra edge; it is structurally transitively implied but deleting it is unnecessary. These diamonds are useful **placement-affinity** units. Their M→V→M form admits overlap with other independent work; treating the whole diamond as one resource or forcing one compute start/end destroys that opportunity. Conversely unconstrained per-op EFT may move SIGMOID/MUL to idle cores, paying large activation transfers and fixed release lags. A static diagnostic should report how many such diamonds are split and their resulting distinct remote tensor bytes. Do not claim row placement solved this remaining half of M work.

No new FFN solver is proposed or executed here. An actionable minimum is to include the remaining ops in M/V core-load accounting, report FFN splits, and preserve a deterministic owner affinity to the diamond’s original MATMUL predecessors when there is no substantial scheduling reason to cut8192B activations.

## Guard hardening for production

- Explicitly reject or correctly parse direct op→op edges, tensor→tensor edges and unsupported pipe/duration cases. The draft parser’s generic `else` writes producer[v]=u as if v were always a tensor. This happens to be safe for082, not a generic graph guard.
- Require original raw boundary tensor identity/size and all escaping consumers to be checked; contracted adjacency alone is insufficient when COPY consumers exist.
- Keep private-Q inclusion optional and recompute closures/quotient if enabled. Moving Q can replace a2048B Q transfer with4096B normalization input plus weight demand.
- Shared K/V “all consumers in panel” is currently a **compute** condition; do not relabel it raw-port closure without checking COPY consumers. This does not invalidate the current scheme because those producers remain explicit and unreplicated.
- Reject overlaps and quotient cycles, and retain all unrecognized ops exactly once. No operation IDs or case IDs should decide membership.
- Add cheap software tests for the cycle witness and a late-V frontier witness; no official scoring is required to demonstrate these semantic properties.

## Provenance correction

REPORT.md claims read HEAD `b1dd5d7e7420f48baa37d3dee6801a04aecb15b2`; `082-attention-rows.json` actually records `1a56523b31fd2ea4d33cff538c5b2323fb35af8a`. The graph/Index hashes match actual bytes, so this is not evidence of a changed structure. Preserve the JSON’s actual read HEAD or explain the later snapshot; do not silently collapse them.

Full checked row boundary summaries, remaining op histogram, FFN memberships and sample ports are in `static-evidence.json`.
