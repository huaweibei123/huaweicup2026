from pathlib import Path
import json,hashlib,collections,heapq
repo=Path('/Users/nikolastar/Projects/huaweicup2026/.worktrees/q3-core-nikolastarx');proposal=Path('/tmp/q3-internal-separator-proposal');out=Path('/tmp/q3-attention-review')
j=json.loads((proposal/'082-attention-rows.json').read_text());g=json.loads((repo/j['graph_path']).read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(repo/j['graph_path'])==j['graph_sha256'];assert sha(proposal/'inspect_attention_rows.py')==j['script_sha256'];assert sha(repo/'src/q3/construct.py')==j['index_source_sha256']
ops={o['id']:o for o in g['ops']};compute={u:o for u,o in ops.items() if o['op'] not in {'COPY_IN','COPY_OUT'}};tensors={t['id']:t for t in g['tensors']};producers=collections.defaultdict(set);consumers=collections.defaultdict(set);inputs=collections.defaultdict(set);outputs=collections.defaultdict(set);direct=[]
for e in g['edges']:
 u,v=e['source'],e['target']
 if u in ops and v in tensors:producers[v].add(u);outputs[u].add(v)
 elif u in tensors and v in ops:consumers[u].add(v);inputs[v].add(u)
 else:direct.append((u,v))
assert not direct;assert all(len(p)<=1 for p in producers.values())
pred={u:set().union(*(producers[t] for t in inputs[u]))&compute.keys() for u in compute};succ={u:set() for u in compute}
for v,pp in pred.items():
 for u in pp:succ[u].add(v)
# The raw graph has no COPY with a compute predecessor and compute consumer; raw compute edges suffice here.
internal_copies=[]
for u in ops.keys()-compute.keys():
 pp=set().union(*(producers[t] for t in inputs[u]))&compute.keys();ss=set().union(*(consumers[t] for t in outputs[u]))&compute.keys()
 if pp and ss:internal_copies.append(u)
assert not internal_copies
rows=[];owner={}
for ri,r in enumerate(j['modules']):
 inside=set(r['nodes']);root=r['sink'];assert len(inside)==r['ops']==80;assert all(u in compute and u not in owner for u in inside);owner.update({u:('row',ri) for u in inside})
 inc={t for u in inside for t in inputs[u] if not producers[t]<=inside};outs={t for u in inside for t in outputs[u] if consumers[t]-inside};assert inc=={t['tensor'] for t in r['incoming_tensors']};assert outs=={t['tensor'] for t in r['outgoing_tensors']};assert len(outs)==1 and all(producers[t]=={root} for t in outs);assert all(succ[u]<=inside for u in inside-{root})
 assert all(consumers[t]<=inside for t in outputs[r['q']]);work={p:sum(compute[u]['cycles'] for u in inside if compute[u]['pipe']==p) for p in ('PIPE_M','PIPE_V')};assert work==r['work'];assert sum(tensors[t]['size'] for t in inc)==r['incoming_bytes']
 rows.append({'sink':root,'ops':len(inside),'raw_input_count':len(inc),'raw_output_count':len(outs),'raw_q_private':True,'work':work})
for u in compute:owner.setdefault(u,('op',u))
qsucc={a:set() for a in owner.values()};indeg={a:0 for a in owner.values()}
for u,vs in succ.items():
 for v in vs:
  a,z=owner[u],owner[v]
  if a!=z:qsucc[a].add(z)
for vs in qsucc.values():
 for z in vs:indeg[z]+=1
ready=[a for a,n in indeg.items() if not n];heapq.heapify(ready);order=[]
while ready:
 a=heapq.heappop(ready);order.append(a)
 for z in qsucc[a]:
  indeg[z]-=1
  if not indeg[z]:heapq.heappush(ready,z)
assert len(order)==len(indeg);edges=sorted((a,z) for a,vs in qsucc.items() for z in vs);assert json.loads(json.dumps(edges))==j['quotient_edges']
remaining={u for u,a in owner.items() if a[0]=='op'};diamonds=[]
for a in sorted(remaining):
 if compute[a]['op']!='MATMUL':continue
 sig=[u for u in succ[a] if compute[u]['op']=='SIGMOID' and pred[u]=={a}]
 for b in sig:
  mul=[u for u in succ[b] if compute[u]['op']=='MUL' and pred[u]=={a,b}]
  for c in mul:
   dd=[u for u in succ[c] if compute[u]['op']=='MATMUL' and pred[u]=={c}]
   for d in dd:
    capsule={a,b,c,d};inside_tensors={t for u in capsule for t in outputs[u] if consumers[t]&capsule};closed=all(not (consumers[t]-capsule) for u in capsule-{d} for t in outputs[u]);diamonds.append({'ops':[a,b,c,d],'work':{p:sum(compute[u]['cycles'] for u in capsule if compute[u]['pipe']==p) for p in ('PIPE_M','PIPE_V')},'closed_except_last':closed,'internal_tensor_bytes':sorted(set(tensors[t]['size'] for t in inside_tensors)),'all_remaining':capsule<=remaining})
summary={'graph_sha256':j['graph_sha256'],'proposal_json_sha256':sha(proposal/'082-attention-rows.json'),'proposal_script_sha256':sha(proposal/'inspect_attention_rows.py'),'report_sha256':sha(proposal/'REPORT.md'),'actual_json_code_head':j['code_head'],'index_source_sha256':j['index_source_sha256'],'rows_verified':len(rows),'row_nodes':sum(r['ops'] for r in rows),'compute_nodes':len(compute),'quotient_nodes':len(qsucc),'quotient_edges':len(edges),'quotient_acyclic':True,'rows':rows,'remaining_ops':len(remaining),'remaining_work':{p:sum(compute[u]['cycles'] for u in remaining if compute[u]['pipe']==p) for p in ('PIPE_M','PIPE_V')},'remaining_by_kind_duration':[{ 'op':k[0],'pipe':k[1],'cycles':k[2],'count':v} for k,v in sorted(collections.Counter((compute[u]['op'],compute[u]['pipe'],compute[u]['cycles']) for u in remaining).items())],'ffn_diamonds':diamonds,'ffn_work':{p:sum(d['work'][p] for d in diamonds) for p in ('PIPE_M','PIPE_V')},'ffn_pattern_counts':dict(collections.Counter(str((d['work']['PIPE_M'],d['work']['PIPE_V'],tuple(d['internal_tensor_bytes']),d['closed_except_last'])) for d in diamonds)),'sample_op_ports':{str(u):{'op':compute[u], 'pred':sorted(pred[u]),'succ':sorted(succ[u]),'input_tensors':sorted(inputs[u]),'output_tensors':sorted(outputs[u])} for u in [114,115,116,133,134,135,147,173,174,201,207,214,1289,1290,1291,1292]},'new_solver_or_evaluator_runs':0}
(out/'static-evidence.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k not in ('rows','ffn_diamonds','sample_op_ports','remaining_by_kind_duration')},indent=2))
