# Production draft review and existing-plan readback

Reviewed snapshot: `src/q3/attention_rows.py` SHA256 **fae4441e4da8ba3744033ff2ce75692e757d8054d203afcfdf6af28c14d6239a**. An exact source copy is retained in this directory. This review does not imply later edits were read. Software tests are owned by the author and have not been run by this reviewer.

**Disposition:** no blocking implementation defect found in the bounded 082 applicability/readback scope. The draft is suitable for a separately authorized small official check once author tests pass. This is not official feasibility or a score claim; this reviewer executed no solver, constructor, E0, E1 or E2.

## Fixed findings

The production raw-port guard now rejects direct edges, mixed IDs, multiple producers, non-positive/noninteger durations, unsupported pipes and COPY-contracted dependencies that differ from original direct tensor dependencies. The motif checker preserves every original operation and checks row boundaries, overlap, shared K/V consumer membership and the row/chain quotient DAG. Private Q is recorded but remains outside row placement, so lack of raw-private Q closure cannot accidentally fold an externally shared Q into the row.

The final order is now generated in `_ready_word` after fixed owner selection. It no longer emits each placement capsule contiguously. Each operation’s release comes from its own original predecessors, and M/V resources have separate clocks. This resolves both artificial all-frontier release and capsule-order restrictions in the **final word**. Placement still uses capsule-contiguous trials; the reported limitations correctly say final reordering may improve or worsen that proxy without reconsidering ownership.

For each resource r, the invariant is:

- `available[r]`: ready ops with release ≤ free[r], keyed by (-bottom,id); all have feasible start free[r].
- `future[r]`: ready ops with release > free[r], keyed by (release,-bottom,id).
- Transfer future entries with release ≤ free into available before comparing resource heads.

If available is nonempty, its head is the lexicographic minimum on that resource; otherwise the future head is. Comparing the ≤2k resource heads gives the global minimum (feasible start,-bottom,id). Free clocks only increase; each op enters each heap at most once. New ready ops are enqueued only after all original predecessors have been selected and their proxy finishes are known. Every emitted edge therefore advances in the same global original-op topological word. The per-core projections, and hence per-pipe subsets, cannot introduce an original-compute cycle.

This establishes the intended compute-only construction invariant. COPY service, fixed 500 release after actual COPY_OUT completion, bandwidth sharing, memory edges, spill and Cache remain outside these clocks, as the source explicitly documents.

## Existing 082/k5 artifact readback

Read-only inputs are `/tmp/q3-attention-constructor-082/{plan,meta,summary}.json`. No artifact was regenerated.

- Plan SHA256 `1a868ad1fcdad91ef1a84ba3a8ae297c32d9aee37117dffeb050add3c3ad3e94`.
- Metadata SHA256 `5659904a32fa47f49905544a2dc291942720c1f7c676413e7c1710a0e250a669`.
- All4113 original eligible ops appear exactly once in singleton mapping and schedules; top-level plan has only the two official keys.
- All42 recognized rows have exactly one owner each.
- Every op owner matches the existing placement capsule metadata.
- Independently reconstructing original compute edges and **all consecutive core-order edges** yields an acyclic graph. This is stronger than checking only the per-pipe projections, but still not official expanded-graph validation.
- Recounted M loads are `[114720,115032,113168,113296,111720]`; V loads `[70178,60881,68207,77206,83294]`, matching metadata.
- Author-reported static placement proxy150662 and final proxy148686 are preserved as model values, not re-scored or treated as official.

Details and checks are persisted in `plan-readback.json`.

## Remaining highest-value risk

The remaining FFN risk is real in this exact candidate: **19 of21 diamonds are split** across cores. Independent raw-tensor counting matches every author diagnostic; summed distinct internal tensor × remote destination-core payload is **331776 bytes**. This proxy does not count physical DDR or predict actual generated COPY/spill bytes. It identifies a mechanism to inspect in the already planned official sample: large8192B activation movement created because chain grouping splits a diamond into `[a]`, `[b]`, `[c,d]`.

Thus excellent M balance by itself is insufficient evidence. If official time is much larger than the compute proxy, inspect these existing FFN cuts and COPY queues first before weakening the attention-row guard or exploring many granularities. No new FFN constructor or extra scoring batch is requested by this review.

## Nonblocking documentation corrections

1. The precise selection objective for placement is minimum **capsule completion computed with per-op release**, then distinct remote boundary bytes, then core ID. “Minimum per-operation finish” can be misread as selecting original ops during ownership assignment.
2. The two-heap core algorithm is O(V log V+kV+E) if adjacency iteration is already ordered or bounded-degree. The source additionally calls `sorted(index.succ[u])`, adding Σ d(u)log d(u); an unconditional conservative statement is O((V+E)log V+kV). Similarly recognition includes set/list sorting. This is a complexity wording correction, not an observed performance failure.
3. Keep the P3 Task statement precise: one prepared Task per declared core in frozen source; singleton refers to submitted subgraph granularity, not Task count.
4. Keep proposal snapshot HEAD discrepancy explicit as described in DESIGN_REVIEW.md.

Reviewer writes are confined to `/tmp/q3-attention-review`. No production code/result/central ledger changes and no Git commit.
