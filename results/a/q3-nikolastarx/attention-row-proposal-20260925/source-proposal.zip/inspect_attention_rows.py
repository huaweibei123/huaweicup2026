#!/usr/bin/env python3
"""Read-only structural census, not a solver/evaluator. Output paths are explicit."""
from __future__ import annotations
import argparse
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import subprocess
import sys


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--case', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.repo))
    from src.q3.construct import Index, topo
    path = args.repo / 'data/raw/a/official/data' / f'case_{args.case}.json'
    original_sha = sha(path)
    graph = json.loads(path.read_text())
    ix = Index(graph)
    tensors = {t['id']: t for t in graph['tensors']}
    producer = {}
    consumers = defaultdict(set)
    inputs = defaultdict(set)
    outputs = defaultdict(set)
    for edge in graph['edges']:
        u, v = edge['source'], edge['target']
        if u in tensors:
            consumers[u].add(v)
            inputs[v].add(u)
        else:
            if v in producer and producer[v] != u:
                raise ValueError('ambiguous tensor producer')
            producer[v] = u
            outputs[u].add(v)
    def kind(u): return ix.ops[u]['op']
    def fail(condition):
        if not condition:
            raise ValueError('motif guard')
    def add_tree(root, leaf_kind):
        leaves, inside, stack = set(), set(), [root]
        while stack:
            u = stack.pop()
            if u in inside or u in leaves:
                continue
            if kind(u) == leaf_kind:
                leaves.add(u)
            else:
                fail(kind(u) == 'ADD' and len(ix.pred[u]) == 2)
                inside.add(u)
                stack.extend(ix.pred[u])
        fail(len(leaves) >= 2 and len(inside) == len(leaves) - 1)
        return leaves, inside
    def reverse_until(root, stops):
        inside, found, stack = set(), set(), [root]
        while stack:
            u = stack.pop()
            if u in stops:
                found.add(u)
            elif u not in inside:
                inside.add(u)
                stack.extend(ix.pred[u])
        return inside, found
    def boundaries(inside):
        incoming = sorted({t for u in inside for t in inputs[u]
                           if producer.get(t) not in inside})
        outgoing = sorted({t for u in inside for t in outputs[u]
                           if consumers[t] - inside})
        def desc(t):
            return {'tensor': t, 'bytes': tensors[t]['size'], 'pos': tensors[t]['pos'],
                    'producer': producer.get(t), 'consumers_in_module': sorted(consumers[t] & inside),
                    'consumers_outside_module': sorted(consumers[t] - inside)}
        return [desc(t) for t in incoming], [desc(t) for t in outgoing]
    found, rejected = [], Counter()
    for root in ix.order:
        if kind(root) != 'DIV' or len(ix.pred[root]) != 2 or any(kind(p) != 'ADD' for p in ix.pred[root]):
            continue
        match = None
        for denominator, numerator in (tuple(ix.pred[root]), tuple(reversed(tuple(ix.pred[root])))):
            try:
                reds, dadds = add_tree(denominator, 'REDUCE')
                mults, nadds = add_tree(numerator, 'MATMUL')
                fail(len(reds) == len(mults))
                exp_to_red = {}
                for r in reds:
                    fail(len(ix.pred[r]) == 1)
                    e = next(iter(ix.pred[r]))
                    fail(kind(e) == 'EXP' and e not in exp_to_red)
                    exp_to_red[e] = r
                exps = set(exp_to_red)
                exp_to_mult, v_nodes = {}, set()
                for m in mults:
                    ep = ix.pred[m] & exps
                    fail(len(ep) == 1 and len(ix.pred[m]) == 2)
                    e = next(iter(ep)); v = next(iter(ix.pred[m] - ep))
                    fail(e not in exp_to_mult and kind(v) == 'MATMUL')
                    exp_to_mult[e] = m; v_nodes.add(v)
                fail(set(exp_to_mult) == exps and len(v_nodes) == len(exps))
                subtractions, score_divs, max_roots = set(), set(), set()
                for e in exps:
                    fail(len(ix.pred[e]) == 1)
                    s = next(iter(ix.pred[e])); fail(kind(s) == 'SUB' and len(ix.pred[s]) == 2)
                    ds = {p for p in ix.pred[s] if kind(p) == 'DIV'}
                    ms = {p for p in ix.pred[s] if kind(p) == 'ADD'}
                    fail(len(ds) == len(ms) == 1)
                    subtractions.add(s); score_divs |= ds; max_roots |= ms
                fail(len(score_divs) == len(exps) and len(max_roots) == 1)
                score_mults = set()
                for d in score_divs:
                    fail(len(ix.pred[d]) == 1)
                    m = next(iter(ix.pred[d])); fail(kind(m) == 'MATMUL' and len(ix.pred[m]) == 2)
                    fail(all(kind(p) == 'MATMUL' for p in ix.pred[m]))
                    score_mults.add(m)
                fail(len(score_mults) == len(exps))
                common = set.intersection(*(ix.pred[m] for m in score_mults))
                fail(len(common) == 1)
                q = next(iter(common))
                ks = {next(iter(ix.pred[m] - {q})) for m in score_mults}
                fail(len(ks) == len(exps) and not (ks & v_nodes) and q not in v_nodes)
                maxroot = next(iter(max_roots))
                max_inside, max_scores = reverse_until(maxroot, score_divs)
                fail(max_scores == score_divs and all(kind(u) in {'REDUCE', 'SUB', 'RELU', 'ADD'} for u in max_inside))
                stops = {q} | ks | v_nodes
                inside, external = reverse_until(root, stops)
                expected = ({root} | reds | dadds | mults | nadds | exps | subtractions |
                            score_divs | score_mults | max_inside)
                fail(inside == expected and external == stops)
                fail(len(inside) == 12 * len(exps) - 4)
                fail(all(not (ix.succ[u] - inside) for u in inside - {root}))
                fail(ix.succ[q] <= inside)
                inc, out = boundaries(inside)
                compute_inc = {producer[t['tensor']] for t in inc if producer.get(t['tensor']) in ix.ops}
                fail(compute_inc == stops)
                fail(len(out) == 1 and producer[out[0]['tensor']] == root)
                incoming_kv = [t for t in inc if t['producer'] in ks | v_nodes]
                incoming_q = [t for t in inc if t['producer'] == q]
                extra = [t for t in inc if t['producer'] not in stops]
                fail(len(incoming_kv) == 2*len(exps) and len(incoming_q) == 1)
                fail(len(extra) == 1 and extra[0]['bytes'] == 2)
                work = dict(Counter())
                for u in inside:
                    pipe = ix.ops[u]['pipe']; work[pipe] = work.get(pipe, 0) + ix.duration(u)
                match = {'sink': root, 'nodes': sorted(inside), 'ops': len(inside), 'work': work,
                         'q': q, 'k': sorted(ks), 'v': sorted(v_nodes), 'max_root': maxroot,
                         'score_matmuls': sorted(score_mults), 'exp_nodes': sorted(exps),
                         'numerator_root': numerator, 'denominator_root': denominator,
                         'incoming_tensors': inc, 'outgoing_tensors': out,
                         'incoming_bytes': sum(t['bytes'] for t in inc),
                         'incoming_kv_bytes': sum(t['bytes'] for t in incoming_kv),
                         'incoming_q_bytes': sum(t['bytes'] for t in incoming_q),
                         'noncompute_extra_bytes': sum(t['bytes'] for t in extra),
                         'outgoing_bytes': sum(t['bytes'] for t in out),
                         'private_q_successors_all_inside': True,
                         'private_q_raw_tensor_consumers_all_inside': all(consumers[t] <= inside for t in outputs[q])}
                break
            except ValueError:
                pass
        if match:
            found.append(match)
        else:
            rejected['final_DIV_two_ADD_not_matching'] += 1
    owners = {}
    for i, m in enumerate(found):
        for u in m['nodes']:
            if u in owners:
                raise ValueError('overlapping row modules')
            owners[u] = i
    groups = defaultdict(list)
    for m in found:
        groups[(tuple(m['k']), tuple(m['v']))].append(m)
    panels = []
    for (ks, vs), rows in groups.items():
        row_union = {u for row in rows for u in row['nodes']}
        fail(all(not (ix.succ[u] & (row_union - set(row['nodes']))) for row in rows for u in row['nodes']))
        fail(all(ix.succ[u] <= row_union for u in list(ks)+list(vs)))
        panels.append({'shared_kv_all_compute_consumers_in_panel': True, 'sinks': [m['sink'] for m in rows], 'q_nodes': [m['q'] for m in rows],
                       'k_nodes': list(ks), 'v_nodes': list(vs), 'rows': len(rows),
                       'row_ops': sorted({m['ops'] for m in rows}),
                       'row_work_variants': sorted({tuple(sorted(m['work'].items())) for m in rows}),
                       'kv_distinct_boundary_bytes': rows[0]['incoming_kv_bytes'],
                       'normalized_input_frontier': sorted({p for u in list(ks)+list(vs)+[m['q'] for m in rows] for p in ix.pred[u]}),
                       'compute_independent_between_rows': True})
    # Quotient legality is checked, not inferred from a grouping label.
    quotient_owner = {u: ('row', owners[u]) if u in owners else ('op', u) for u in ix.ops}
    labels = set(quotient_owner.values())
    qsucc = {u: set() for u in labels}
    for u in ix.ops:
        for v in ix.succ[u]:
            if quotient_owner[u] != quotient_owner[v]:
                qsucc[quotient_owner[u]].add(quotient_owner[v])
    topo(labels, qsucc)
    payload = {'kind': 'static_structural_census_not_score', 'case': args.case,
               'graph_sha256': sha(path), 'graph_path': str(path.relative_to(args.repo)),
               'code_head': subprocess.check_output(['git','rev-parse','HEAD'], cwd=args.repo, text=True).strip(),
               'script_sha256': sha(Path(__file__)), 'index_source_sha256': sha(args.repo/'src/q3/construct.py'),
               'compute_ops': len(ix.ops), 'row_count': len(found), 'covered_ops': len(owners),
               'covered_ratio': len(owners)/len(ix.ops), 'quotient_acyclic': True,
               'total_compute_work': {p: sum(ix.duration(u) for u in ix.ops if ix.ops[u]['pipe']==p) for p in sorted({o['pipe'] for o in ix.ops.values()})},
               'covered_compute_work': {p: sum(ix.duration(u) for u in owners if ix.ops[u]['pipe']==p) for p in sorted({o['pipe'] for o in ix.ops.values()})},
               'quotient_edges': sorted((a,b) for a in qsucc for b in qsucc[a]),
               'rejected_candidates': dict(rejected), 'panels': panels, 'modules': found,
               'evaluator_calls': 0, 'raw_graph_unchanged': sha(path) == original_sha}
    args.output.write_text(json.dumps(payload, indent=2, sort_keys=True)+'\n')
    print(json.dumps({k:v for k,v in payload.items() if k not in {'modules','panels','quotient_edges'}}, indent=2))
    print(json.dumps(panels, indent=2))
if __name__ == '__main__':
    main()
