"""Two authorized graphs only; topology/tensor audit, no evaluator or plan run."""
import hashlib
import json
from collections import Counter, defaultdict, deque
from pathlib import Path
from src.q3.construct import Index


def audit(case):
    path = Path(f'data/raw/a/official/data/case_{case}.json')
    graph = json.loads(path.read_text())
    ix = Index(graph)
    tensors = {t['id']: t for t in graph['tensors']}
    all_ops = {o['id']: o for o in graph['ops']}
    inputs, outputs, producers, consumers = [defaultdict(set) for _ in range(4)]
    for e in graph['edges']:
        u, v = e['source'], e['target']
        if u in tensors and v in all_ops:
            inputs[v].add(u); consumers[u].add(v)
        elif u in all_ops and v in tensors:
            outputs[u].add(v); producers[v].add(u)
    def boundary_projection(u):
        return ix.ops[u]['op'] == 'MATMUL' and len(ix.pred[u]) == 1 and len(ix.succ[u]) >= 2
    sinks = [u for u in ix.order if ix.ops[u]['op'] == 'DIV' and len(ix.pred[u]) == 2
             and all(ix.ops[p]['op'] == 'ADD' for p in ix.pred[u])]
    modules = []
    owner = {}
    for sink in sinks:
        inner, frontier, stack = set(), set(), [sink]
        while stack:
            u = stack.pop()
            if u in inner or u in frontier:
                continue
            if boundary_projection(u):
                frontier.add(u)
            else:
                inner.add(u); stack.extend(ix.pred[u])
        external_edges = [(u,v) for u in inner for v in ix.succ[u] if v not in inner]
        assert all(u == sink for u,v in external_edges), (case,sink,external_edges)
        assert all(not (consumers[t] - inner) or u == sink for u in inner for t in outputs[u])
        assert all(u not in owner for u in inner), (case,sink,'overlapping row cones')
        for u in inner:
            owner[u] = sink
        q = [u for u in frontier if len(ix.succ[u] & inner) > 1]
        assert len(q) == 1, (case,sink,q)
        q = q[0]
        assert ix.succ[q] <= inner, (case,sink,'Q has a user outside its row')
        columns = len(ix.succ[q] & inner)
        assert len(frontier) == 2*columns+1
        assert len(inner) == 12*columns-4
        it = {t for u in inner for t in inputs[u] if not (producers[t] & inner)}
        ot = {t for u in inner for t in outputs[u] if consumers[t]-inner}
        assert len(ot) == 1
        out_tensor = next(iter(ot))
        constants = [t for t in it if not (producers[t] & frontier)]
        assert len(constants) == 1 and tensors[constants[0]]['size'] == 2
        for u in frontier:
            assert len(outputs[u]) == 1
        query_tensor = next(iter(outputs[q]))
        kv = sorted(frontier-{q})
        kv_tensors = sorted(t for u in kv for t in outputs[u])
        pipes = {p:sum(ix.duration(u) for u in inner if ix.ops[u]['pipe']==p)
                 for p in ('PIPE_M','PIPE_V')}
        modules.append({'sink':sink,'nodes':sorted(inner),'columns':columns,'operations':len(inner),
            'query_projection':q,'query_tensor':query_tensor,'query_bytes':tensors[query_tensor]['size'],
            'kv_projection_ops':kv,'kv_tensors':kv_tensors,'kv_unique_bytes':sum(tensors[t]['size'] for t in kv_tensors),
            'input_tensors':[tensors[t] for t in sorted(it)],'input_unique_bytes':sum(tensors[t]['size'] for t in it),
            'output_tensor':tensors[out_tensor],'external_edges':external_edges,'pipe_work':pipes,
            'operation_signature':dict(sorted(Counter(ix.ops[u]['op'] for u in inner).items()))})
    panels = defaultdict(list)
    for m in modules:
        panels[tuple(m['kv_projection_ops'])].append(m)
    panel_rows = []
    for kv, rows in panels.items():
        columns = rows[0]['columns']
        assert len(rows) == columns
        all_row_nodes = set(u for m in rows for u in m['nodes'])
        assert all(ix.succ[u] <= all_row_nodes and len(ix.succ[u]) == columns for u in kv)
        assert all(len(ix.succ[u] & set(m['nodes'])) == 1 for u in kv for m in rows)
        assert all(not (set(v for u in m['nodes'] for v in ix.succ[u])-set(m['nodes'])) & all_row_nodes for m in rows)
        norms = set(p for u in kv for p in ix.pred[u])
        assert len(norms) == columns
        assert all(ix.pred[m['query_projection']] <= norms for m in rows)
        panel_rows.append({'row_sinks':[m['sink'] for m in rows], 'columns':columns,
             'shared_kv_projection_ops':list(kv),'normalization_frontier':sorted(norms),
             'shared_kv_unique_bytes':rows[0]['kv_unique_bytes']})
    blocks = defaultdict(list)
    for p in panel_rows:
        blocks[tuple(p['normalization_frontier'])].append(p)
    assert all(len(ps)==2 for ps in blocks.values())
    # Contract each closed row, retain every other op as singleton; check quotient.
    label = {u:('row',owner[u]) if u in owner else ('op',u) for u in ix.ops}
    succ = {x:set() for x in label.values()}
    for u in ix.order:
        for v in ix.succ[u]:
            if label[u] != label[v]:succ[label[u]].add(label[v])
    deg = dict.fromkeys(succ,0)
    for vs in succ.values():
        for v in vs:deg[v]+=1
    ready = deque(u for u in succ if deg[u]==0); seen=0
    while ready:
        u=ready.popleft();seen+=1
        for v in succ[u]:
            deg[v]-=1
            if deg[v]==0:ready.append(v)
    assert seen==len(succ)
    summary = Counter((m['operations'],m['query_bytes'],m['output_tensor']['size'],m['input_unique_bytes'],m['pipe_work']['PIPE_M'],m['pipe_work']['PIPE_V']) for m in modules)
    return {'case':case,'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
        'original_compute_ops':len(ix.ops),'weak_components':len(ix.components),
        'rows':len(modules),'row_compute_ops':len(owner),'row_coverage_fraction':len(owner)/len(ix.ops),
        'panels':len(panel_rows),'paired_head_blocks':len(blocks),'quotient_acyclic':True,
        'closed_raw_tensor_exits_verified':True,'row_groups':[{'count':n,'operations':k[0],'query_bytes':k[1],
        'output_bytes':k[2],'input_unique_bytes':k[3],'M_cycles':k[4],'V_cycles':k[5]} for k,n in sorted(summary.items())],
        'panel_records':panel_rows,'module_records':modules}

if __name__ == '__main__':
    results={'official_evaluations':0,'scope':['075','085'],'cases':[audit(c) for c in ('075','085')]}
    dest=Path('/tmp/q3-internal-separator-proposal/child-075085.json')
    dest.write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
    for r in results['cases']:
        print(json.dumps({k:v for k,v in r.items() if k not in {'panel_records','module_records'}},ensure_ascii=False))
    print('output',dest)
