"""Extract all 100 official JSONs and verify every original raw file hash."""
import hashlib,json,zipfile
from pathlib import Path
R=Path(__file__).resolve().parent;manifest=json.loads((R/'source-manifest.json').read_text())
expected={x['path']:x for x in manifest['files']};dest=R/'official'
with zipfile.ZipFile(R/'official-cases.zip') as z:
 for name in z.namelist():
  if name not in expected or not name.startswith('data/case_') or not name.endswith('.json'):
   raise ValueError('unexpected archive member: '+name)
  b=z.read(name)
  if hashlib.sha256(b).hexdigest()!=expected[name]['sha256']:raise ValueError('case hash mismatch: '+name)
  (dest/name).parent.mkdir(parents=True,exist_ok=True);(dest/name).write_bytes(b)
for name,x in expected.items():
 b=(dest/name).read_bytes()
 if len(b)!=x['bytes'] or hashlib.sha256(b).hexdigest()!=x['sha256']:raise ValueError('official mismatch: '+name)
recipe=''.join(name+'\t'+expected[name]['sha256']+'\n' for name in sorted(expected) if name.startswith('code/'))
h=hashlib.sha256(recipe.encode()).hexdigest()
if h!=manifest['official_code_hash']:raise ValueError('code collection hash mismatch')
print(json.dumps({'verified':len(expected),'cases':sum(x.startswith('data/case_') for x in expected),'official_code_hash':h},indent=2))
