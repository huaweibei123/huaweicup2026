"""Replay one saved run in a fresh directory using the bundled, unmodified E0.
Input path strings are the only fields normalized for the full-JSON comparison.
"""
import argparse,sys,json,gzip,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'src'))
from evidence import run_e0

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('run_directory',type=Path);p.add_argument('--output',required=True,type=Path);p.add_argument('--timeout',default=120,type=float);a=p.parse_args()
 record=json.loads((a.run_directory/'run.json').read_text());oldgraph=Path(record['graph']);g=ROOT/'official/data'/oldgraph.name
 def matches(path):return path.exists() and hashlib.sha256(path.read_bytes()).hexdigest()==record['graph_hash']
 if not matches(g):
  g=next((x for x in (ROOT/'fixtures').rglob('*.json') if matches(x)),None)
 if g is None or not matches(g):raise FileNotFoundError('graph bytes not found; extract_official.py must have run')
 plan=json.loads((a.run_directory/'plan.json').read_text());r=run_e0(g,plan,record['problem'],a.output,timeout=a.timeout,official=ROOT/'official',compress=True)
 verdict={'old_status':record['status'],'new_status':r['status'],'original_environment':record['python'],'replay_environment':r['python'],'path_normalization':['input_graph','input_plan']}
 if record['status']=='ok' and r['status']=='ok':
  old=json.load(gzip.open(a.run_directory/'result.json.gz','rt'));new=json.load(gzip.open(a.output/'result.json.gz','rt'))
  for d in [old,new]:
   for key in verdict['path_normalization']:d.pop(key,None)
  verdict['full_result_equal_except_input_paths']=old==new
 elif record['status']=='timeout':verdict['note']='Timeout is a budget observation, not a semantic expected rejection.'
 else:verdict['note']='Compare saved raw error stage/type manually; path text may differ.'
 (a.output/'comparison.json').write_text(json.dumps(verdict,indent=2)+'\n');print(json.dumps(verdict,indent=2))
 return 1 if verdict.get('full_result_equal_except_input_paths') is False else 0
if __name__=='__main__':raise SystemExit(main())
