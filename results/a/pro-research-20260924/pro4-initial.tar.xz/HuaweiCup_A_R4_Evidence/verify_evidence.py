"""Verify every shipped payload SHA; generated extra files are not rejected."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parent
m=json.loads((ROOT/'MANIFEST.json').read_text())
for item in m['files']:
 p=ROOT/item['path'];raw=p.read_bytes()
 assert len(raw)==item['bytes'] and hashlib.sha256(raw).hexdigest()==item['sha256'],item['path']
print(json.dumps({'payload_files_verified':len(m['files']),'note':'Byte-integrity verification, not a new semantic benchmark'}))
