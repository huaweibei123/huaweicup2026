"""Verify the frozen official bytes, then extract the 100 case JSON files."""
from pathlib import Path
from zipfile import ZipFile
import hashlib,json,argparse
ROOT=Path(__file__).resolve().parent
def sha(raw):return hashlib.sha256(raw).hexdigest()
def main():
 p=argparse.ArgumentParser();p.add_argument('--verify-only',action='store_true');a=p.parse_args()
 m=json.loads((ROOT/'audit/source-manifest.json').read_text());archive=ROOT/'official-cases.zip'
 assert sha(archive.read_bytes())==m['case_archive']['sha256'],'archive SHA mismatch'
 assert sha((ROOT/'problem.pdf').read_bytes())==m['pdf']['sha256'],'problem PDF SHA mismatch'
 cases={x['path'] for x in m['files'] if Path(x['path']).name.startswith('case_')}
 with ZipFile(archive) as z:
  assert set(z.namelist())==cases and len(z.namelist())==len(cases),'unexpected archive entries'
  for x in m['files']:
   rel=Path(x['path']);assert not rel.is_absolute() and '..' not in rel.parts
   target=ROOT/'official'/rel;raw=z.read(x['path']) if x['path'] in cases else target.read_bytes()
   assert len(raw)==x['bytes'] and sha(raw)==x['sha256'],str(rel)
   if x['path'] in cases and not a.verify_only:
    target.parent.mkdir(parents=True,exist_ok=True)
    if target.exists():assert target.read_bytes()==raw,'refuse to replace changed '+str(target)
    else:target.write_bytes(raw)
 text=''.join(x['path']+'\t'+x['sha256']+'\n' for x in sorted(m['files'],key=lambda x:x['path']) if x['path'].startswith('code/'))
 assert sha(text.encode())==m['official_code_hash']
 print(json.dumps({'official_originals_verified':len(m['files']),'cases_verified':len(cases),'cases_extracted':not a.verify_only,'official_code_hash':m['official_code_hash']}))
if __name__=='__main__':main()
