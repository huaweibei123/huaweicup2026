from __future__ import annotations
import sys,json,time,subprocess,hashlib,argparse,traceback
from pathlib import Path
from core import *
ROOT=Path(__file__).resolve().parents[1]
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def run_e0(graph,pl,folder,q=2,timeout=30):
 folder=Path(folder);folder.mkdir(parents=True,exist_ok=True);pp=folder/'plan.json';pp.write_text(json.dumps(pl,ensure_ascii=False))
 cmd=[sys.executable,str(OFFICIAL/'code'/f'multicore_cut_evaluate_problem_{q}.py'),str(graph),str(pp),'--config',str(OFFICIAL/'data/config.txt'),'-o',str(folder/'result.json'),'--trace-output',str(folder/'trace.json'),'--log-output',str(folder/'log.txt')]
 st=time.perf_counter()
 try:
  cp=subprocess.run(cmd,capture_output=True,text=True,timeout=timeout);status='ok' if cp.returncode==0 else 'error';stdout=cp.stdout;stderr=cp.stderr;rc=cp.returncode
 except subprocess.TimeoutExpired as e:status='timeout';stdout=str(e.stdout or '');stderr=str(e.stderr or '');rc=None
 elapsed=time.perf_counter()-st;(folder/'stdout.txt').write_text(stdout);(folder/'stderr.txt').write_text(stderr)
 r={'command':cmd,'status':status,'returncode':rc,'e0_cli_seconds':elapsed,'graph_sha256':digest(graph),'plan_sha256':digest(pp),'config_sha256':digest(OFFICIAL/'data/config.txt'),'problem':q,'cores':len(pl['core_schedules'])}
 if status=='ok':
  j=json.loads((folder/'result.json').read_text());r.update(makespan=j['makespan'],movement=j['data_movement_bytes'],cache=j.get('cache_stats'),result_sha256=digest(folder/'result.json'))
 (folder/'run.json').write_text(json.dumps(r,indent=2));return r

def candidates(g,k):
 a=lpt(g,k)
 if len(g.comps)<k:a,groups=packet_assignment(g,k)
 else:groups=g.comps
 yield 'coarse',lambda:(plan(g,a,g.topo,k,groups),{})
 yield 'serial',lambda:(plan(g,a,g.topo,k),certify(g,a,k,g.topo))
 if len(g.comps)>=k:
  def wave():
   seq=waves(g,a,k,4,4);return plan(g,a,seq,k),certify(g,a,k,seq)
  yield 'wave4',wave
 for name,gate,io,pressure in [('ready0',False,0,0),('frontier0',True,0,0),('frontier1',True,1,0),('frontierp',True,1,1)]:
  def make(gate=gate,io=io,pressure=pressure):
   seq,meta=ready_order(g,a,k,gate,io,pressure,64);return plan(g,a,seq,k),meta
  yield name,make
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--cases',default='1,8,11,44,46,80');ap.add_argument('--q',type=int,default=2);ap.add_argument('--tag',default='dev');ap.add_argument('--methods',default='');ap.add_argument('--cores',type=int,default=4);args=ap.parse_args()
 rows=[];cases=[int(x) for x in args.cases.split(',')];out=ROOT/'experiments'/args.tag;out.mkdir(parents=True,exist_ok=True)
 (out/'protocol.json').write_text(json.dumps({'cases':cases,'problem':args.q,'cores':args.cores,'methods':args.methods or 'coarse,serial,wave4,ready0,frontier0,frontier1,frontierp','timeout_seconds':30,'algorithm_sha256':digest(Path(__file__).with_name('core.py'))},indent=2))
 for ci in cases:
  gp=OFFICIAL/'data'/f'case_{ci:03d}.json';st=time.perf_counter();g=Graph.load(gp);prep=time.perf_counter()-st
  for name,make in candidates(g,args.cores):
   if args.methods and name not in args.methods.split(','):continue
   folder=out/f'case_{ci:03d}'/name
   if (folder/'experiment.json').exists():
    r=json.loads((folder/'experiment.json').read_text());rows.append(r);print('resume',ci,name,r['status'],flush=True);continue
   st=time.perf_counter()
   try:pl,meta=make();cons=time.perf_counter()-st;r=run_e0(gp,pl,folder,args.q)
   except Exception as e:
    folder.mkdir(parents=True,exist_ok=True);(folder/'construction_error.txt').write_text(traceback.format_exc());r={'status':'construction_error','error':str(e)};meta={};cons=time.perf_counter()-st
   r.update(case=ci,method=name,construction_seconds=cons,graph_prepare_seconds=prep,**meta);rows.append(r)
   (folder/'experiment.json').write_text(json.dumps(r,indent=2));(out/'summary.json').write_text(json.dumps(rows,indent=2))
   print(ci,name,r['status'],r.get('makespan'),r.get('movement',{}).get('spill_added_copy_bytes'),'sec',round(cons+r.get('e0_cli_seconds',0),3),flush=True)
