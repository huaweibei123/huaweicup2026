"""Experimental router inference; scores are not official makespan estimates.
JSON checkpoint avoids loading untrusted pickle. Only CPU was tested here.
"""
from pathlib import Path
import json,argparse
import numpy as np
import torch
from torch import nn
from core import Graph
from synthetic import features

def main():
 p=argparse.ArgumentParser();p.add_argument('graph');p.add_argument('--device',choices=['cpu','cuda','mps'],default='cpu');p.add_argument('--weights',default=str(Path(__file__).resolve().parents[1]/'analysis/learning/router_seed0.json'));a=p.parse_args()
 if a.device=='cuda' and not torch.cuda.is_available():p.error('CUDA is not available in this PyTorch/runtime')
 if a.device=='mps' and not torch.backends.mps.is_available():p.error('MPS is not available in this PyTorch/runtime')
 ck=json.loads(Path(a.weights).read_text());g=Graph.load(a.graph);x=np.asarray(features(g),dtype=np.float64);x=(x-np.asarray(ck['scaler_mean'],dtype=np.float64))/np.asarray(ck['scaler_scale'],dtype=np.float64)
 net=nn.Sequential(nn.Linear(14,32),nn.GELU(),nn.Linear(32,32),nn.GELU(),nn.Linear(32,8));net.load_state_dict({k:torch.tensor(v,dtype=torch.float32) for k,v in ck['state'].items()});net.to(a.device).eval()
 with torch.no_grad():y=net(torch.tensor(x,dtype=torch.float32,device=a.device)[None])[0].cpu()
 ranking=sorted(range(4),key=lambda i:float(y[i]));print(json.dumps({'device':a.device,'ranking':[{'action':ck['actions'][i],'relative_score':float(y[i]),'spill_probability':float(torch.sigmoid(y[i+4]))} for i in ranking],'warning':'Experimental synthetic-trained advice only; select final plan only after official evaluation.'},indent=2))
if __name__=='__main__':main()
