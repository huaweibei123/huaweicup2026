"""Deadline-aware small portfolio; accepts only complete successful E0 runs.
Usage: python src/solve.py graph.json output.plan.json --cores 4 --problem 2
Each child is individually bounded, including candidate construction. Q1 uses
coarse alternatives, not singleton order refinement. This is not an E1/E2 rewrite.
"""
from __future__ import annotations
import argparse,subprocess,json,sys,time,shutil,os
from pathlib import Path
from core import OFFICIAL
from experiments import run_e0

def solve(graph,output,k=4,problem=2,budget=60,work=None):
 graph=Path(graph).resolve();output=Path(output).resolve();work=Path(work or str(output)+'.runs');work.mkdir(parents=True,exist_ok=True)
 begin=time.perf_counter();deadline=begin+budget;rows=[];best=None
 methods=['component','packet'] if problem==1 else ['component','ready_io','ready_pressure']
 for name in methods:
  folder=work/name;folder.mkdir(exist_ok=True);pp=folder/'candidate.plan.json';remaining=deadline-time.perf_counter()-0.4
  if remaining<=0:break
  cmd=[sys.executable,str(Path(__file__).with_name('core.py')),str(graph),str(pp),'--cores',str(k),'--method',name]
  st=time.perf_counter()
  try:
   z=subprocess.run(cmd,capture_output=True,text=True,timeout=remaining)
   (folder/'constructor.stdout').write_text(z.stdout);(folder/'constructor.stderr').write_text(z.stderr)
   if z.returncode!=0:rows.append({'method':name,'status':'constructor_error','seconds':time.perf_counter()-st});continue
  except subprocess.TimeoutExpired:
   rows.append({'method':name,'status':'constructor_timeout','seconds':time.perf_counter()-st});break
  cons=time.perf_counter()-st;remaining=deadline-time.perf_counter()-0.4
  if remaining<=0:rows.append({'method':name,'status':'not_evaluated_deadline','construct_seconds':cons});break
  r=run_e0(graph,json.loads(pp.read_text()),folder/'e0',problem,timeout=remaining);r.update(method=name,construct_cli_seconds=cons);rows.append(r)
  if r['status']=='ok':
   key=(r['makespan'],r['movement']['added_copy_bytes'])
   if best is None or key<best[0]:best=(key,name,folder/'e0/plan.json',folder/'e0/result.json')
  if time.perf_counter()>=deadline-.4:break
 if best is not None:
  output.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(best[2],output);shutil.copyfile(best[3],str(output)+'.result.json')
 report={'problem':problem,'cores':k,'budget_seconds':budget,'total_wall_seconds':time.perf_counter()-begin,'methods':methods,'runs':rows,'selected_method':best[1] if best else None,'selected_makespan':best[0][0] if best else None,'success':best is not None,'official_confirmed':best is not None,'note':'Includes constructor CLI, repeated parsing, official CLI and file writes; no guarantee outside measured cases.'}
 (work/'solver.json').write_text(json.dumps(report,indent=2));return report
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('graph');ap.add_argument('output');ap.add_argument('--cores',type=int,default=4);ap.add_argument('--problem',type=int,choices=[1,2,3],default=2);ap.add_argument('--budget',type=float,default=60);ap.add_argument('--work');a=ap.parse_args()
 r=solve(a.graph,a.output,a.cores,a.problem,a.budget,a.work);print(json.dumps({k:v for k,v in r.items() if k!='runs'},indent=2));sys.exit(0 if r['success'] else 2)
