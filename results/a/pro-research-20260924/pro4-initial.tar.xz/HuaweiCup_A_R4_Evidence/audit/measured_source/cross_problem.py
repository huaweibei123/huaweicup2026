from experiments import *
SOURCES={2:('holdout',{'coarse':'coarse','frontier1':'frontier1','frontierp':'frontierp'}),8:('dev_a',{'coarse':'coarse','wave4':'wave4','frontierp':'frontierp'}),44:('dev_b',{'coarse':'coarse','wave4':'wave4','frontierp':'frontierp'}),64:('holdout',{'coarse':'coarse','frontier1':'frontier1','frontierp':'frontierp'}),80:('dev_c',{'wave4':'wave4','frontier1':'frontier1','frontierp':'frontierp'})}
rows=[]
for q,cases in [(3,[2,8,44,64,80]),(1,[8,44])]:
 for ci in cases:
  tag,methods=SOURCES[ci]
  for name,src in methods.items():
   if q==1 and name=='wave4':continue
   pp=ROOT/'experiments'/tag/f'case_{ci:03d}'/src/'plan.json';pl=json.loads(pp.read_text());gp=OFFICIAL/'data'/f'case_{ci:03d}.json'
   r=run_e0(gp,pl,ROOT/'experiments/cross_problem'/f'q{q}_case_{ci:03d}'/name,q);r.update(case=ci,method=name,source_plan=str(pp.relative_to(ROOT)));rows.append(r)
   (ROOT/'experiments/cross_problem/summary.json').write_text(json.dumps(rows,indent=2));print(q,ci,name,r['status'],r.get('makespan'),flush=True)
