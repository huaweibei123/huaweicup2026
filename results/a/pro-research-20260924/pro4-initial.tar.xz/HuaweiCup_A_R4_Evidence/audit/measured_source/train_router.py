"""CPU pilot: graph-only features -> candidate costs and spill logits.
Never trains on official-case outcomes. Family 4 is held out until final scoring.
"""
import json,time,copy,random
from pathlib import Path
import numpy as np
import torch
from torch import nn
from sklearn.ensemble import RandomForestRegressor
from synthetic import ROOT,ACTIONS

def metrics(y,ix):
 regret=y[np.arange(len(y)),ix]/y.min(1)-1
 return {'mean_regret_pct':float(regret.mean()*100),'p95_regret_pct':float(np.quantile(regret,.95)*100),'max_regret_pct':float(regret.max()*100),'pool_top1_hits':int(np.sum(regret==0)),'n':len(y),'choices':[ACTIONS[i] for i in ix]}
rows=json.loads((ROOT/'experiments/synthetic/labels.json').read_text());assert len(rows)==60 and all(all(s=='ok' for s in r['statuses']) for r in rows)
fam=np.array([r['family'] for r in rows]);X=np.array([r['features'] for r in rows]);Y=np.array([r['labels'] for r in rows],dtype=float);sp=np.array([r['spill'] for r in rows])>0
tr=fam<3;va=fam==3;te=fam==4;mean=X[tr].mean(0);std=X[tr].std(0);std[std<1e-6]=1
X=(X-mean)/std;target=np.log(Y/Y.min(1,keepdims=True));torch.set_num_threads(1)
out=ROOT/'analysis/learning';out.mkdir(parents=True,exist_ok=True)
protocol={'train_graphs':int(tr.sum()),'validation_graphs':int(va.sum()),'test_graphs':int(te.sum()),'features':14,'architecture':'14-32-32-(4 cost,4 spill)','loss':'.6 pairwise logistic tau=.1 + .3 smoothL1(beta=.1) + .1 spill BCE','seeds':[0,1,2],'epochs':300,'AdamW_lr':.001,'weight_decay':.001,'selection':'minimum validation mean pool regret, then validation SmoothL1; test used only after selection','device':'cpu','warning':'pilot has just 12 graphs in one test family; no performance generalization claim'}
(out/'protocol.json').write_text(json.dumps(protocol,indent=2))
xt=torch.tensor(X,dtype=torch.float32);yt=torch.tensor(target,dtype=torch.float32);bt=torch.tensor(sp.astype(float),dtype=torch.float32)
i,j=torch.triu_indices(4,4,offset=1);report={'nonlearning':{name:metrics(Y[te],np.full(te.sum(),a)) for a,name in enumerate(ACTIONS)},'mlp':[]}
fixed=int(target[tr].mean(0).argmin());report['training_best_fixed']={'action':ACTIONS[fixed],**metrics(Y[te],np.full(te.sum(),fixed))}
for seed in protocol['seeds']:
 torch.manual_seed(seed);net=nn.Sequential(nn.Linear(14,32),nn.GELU(),nn.Linear(32,32),nn.GELU(),nn.Linear(32,8));opt=torch.optim.AdamW(net.parameters(),lr=.001,weight_decay=.001);best=None;t0=time.perf_counter()
 for epoch in range(300):
  net.train();z=net(xt[tr]);p=z[:,:4];delta=yt[tr][:,j]-yt[tr][:,i];mask=delta.abs()>1e-6
  logistic=torch.nn.functional.softplus(-delta.sign()*(p[:,j]-p[:,i])/.1)
  rank=logistic[mask].mean() if mask.any() else logistic.sum()*0
  reg=torch.nn.functional.smooth_l1_loss(p,yt[tr],beta=.1);bce=torch.nn.functional.binary_cross_entropy_with_logits(z[:,4:],bt[tr]);loss=.6*rank+.3*reg+.1*bce
  opt.zero_grad();loss.backward();opt.step();net.eval()
  with torch.no_grad():
   pv=net(xt[va])[:,:4];choice=pv.argmin(1).numpy();valreg=float(np.mean(Y[va][np.arange(va.sum()),choice]/Y[va].min(1)-1));rr=float(torch.nn.functional.smooth_l1_loss(pv,yt[va],beta=.1));key=(valreg,rr)
  if best is None or key<best[0]:best=(key,copy.deepcopy(net.state_dict()),epoch)
 train_seconds=time.perf_counter()-t0;net.load_state_dict(best[1]);net.eval()
 with torch.no_grad():
  pred=net(xt[te])[:,:4].numpy();choices=pred.argmin(1)
  for _ in range(20):net(xt[:1])
  t0=time.perf_counter()
  for _ in range(1000):net(xt[:1])
  infer=(time.perf_counter()-t0)/1000
 torch.save({'state_dict':net.state_dict(),'feature_mean':mean.tolist(),'feature_std':std.tolist(),'actions':ACTIONS},out/f'mlp_seed{seed}.pt')
 report['mlp'].append({'seed':seed,'selected_epoch':best[2],'train_seconds':train_seconds,'warm_batch1_inference_seconds':infer,**metrics(Y[te],choices)})
t0=time.perf_counter();rf=RandomForestRegressor(n_estimators=100,max_depth=3,random_state=0,n_jobs=1).fit(X[tr],target[tr]);rfsec=time.perf_counter()-t0;report['random_forest']={'train_seconds':rfsec,**metrics(Y[te],rf.predict(X[te]).argmin(1))}
report['hardware']={'torch_version':torch.__version__,'cuda_available':torch.cuda.is_available(),'mps_built':torch.backends.mps.is_built(),'mps_available':torch.backends.mps.is_available()}
(out/'result.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
