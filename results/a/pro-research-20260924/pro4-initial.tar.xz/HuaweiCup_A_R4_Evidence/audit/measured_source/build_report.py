from pathlib import Path
import json,collections
ROOT=Path(__file__).resolve().parents[1]
def load(p):return json.loads((ROOT/p).read_text())
def table(headers,rows):return '\n'.join(['| '+' | '.join(headers)+' |','| '+' | '.join(['---']*len(headers))+' |']+['| '+' | '.join(str(x) for x in row)+' |' for row in rows])
h=collections.defaultdict(dict)
for r in load('experiments/holdout/summary.json'):h[r['case']][r['method']]=r
ht=[]
for ci,ms in h.items():
 b=min((v for n,v in ms.items() if n in ['coarse','serial','wave4']),key=lambda v:v['makespan']);new=min((v for n,v in ms.items() if n in ['frontier1','frontierp']),key=lambda v:v['makespan'])
 ht.append([f'{ci:03d}',b['makespan'],new['makespan'],f"{100*(1-new['makespan']/b['makespan']):.3f}%",new['movement']['spill_added_copy_bytes']])
dead=[]
for tag in ['deadline','deadline_fast','deadline_bounded']:
 if not (ROOT/'experiments'/tag/'summary.json').exists():continue
 for r in load('experiments/'+tag+'/summary.json'):
  s=r.get('solver',{});dead.append([tag,f"{r['case']:03d}",r['budget'],f"{r['process_wall_seconds']:.3f}",s.get('selected_makespan'),', '.join(x['method']+':'+x['status'] for x in s.get('runs',[]))])
learn=load('analysis/learning/result.json');lt=[]
for name in ['coarse','wave4','frontier1','frontierp']:
 r=learn['nonlearning'][name];lt.append([name,f"{r['mean_regret_pct']:.3f}%",f"{r['p95_regret_pct']:.3f}%"])
for r in learn['mlp']:lt.append([f"MLP seed{r['seed']}",f"{r['mean_regret_pct']:.3f}%",f"{r['p95_regret_pct']:.3f}%"])
r=learn['random_forest'];lt.append(['RandomForest',f"{r['mean_regret_pct']:.3f}%",f"{r['p95_regret_pct']:.3f}%"])
text=r'''# 华为杯 A：第四路独立研究与可复现实验

日期：2026-09-23。正文中的“本轮实测”只指本证据包保存的运行，不继承前三路数字的实测身份。本文主线是容量前沿构造，不是神经网络替换官方评估器。

## 0. 结论与交付边界

目前应优先使用“粗归属 + 细粒度顺序构造 + 官方确认”的非学习组合。新增可用部件是原始张量闭区间证书、随驻留压力调整的就绪调度、整数前沿增量更新，以及对每个实例保留已确认基线的限时执行器。

正结果：case002得到62819，case044得到66901，case046得到77846 cycles。负结果同样重要：单步内存放得下不保证后续无需spill；零spill不一定更快；Q2优胜顺序移到Q1会大幅恶化；小MLP没有在测试均值上胜过最强的固定非学习策略。大图的候选构造时间仍是瓶颈，不能据小图收益宣称全域高效。

这些不是对全100例、三个问题和2–5核的完整验收，不是对团队最强求解器的公平竞赛，也不是E1/E2联合达标报告。没有使用CUDA、MPS、远程Colab或消耗队长CU。

## 1. 材料审计

底包SHA256：`b947c655aebd8a2e61a1d8be3f83dc61fe8132453fddb526f950f39a504dfdd8`。

运行了底包VERIFY_BUNDLE.py，468项payload通过；运行scripts/a_materials.py，114份官方原件、100例JSON通过。官方代码聚合哈希为`de11a83db8d7c47ed328b15a7df71d613a833b16cd23ee9fe877999578a1ace0`。固定FORM86b095f、FAST3357d7e仅作为阅读材料，本轮完整评估调用E0。

实际环境Python3.13.5/Linux x86_64，5个可见CPU；torch2.10.0+cpu，CUDA与MPS均不可用。算法与标签的Python3.12、Apple、CUDA跨环境复验尚未完成。

已读题面、官方源码/config、修订契约、前三路二轮摘要与回答原文。原文所链接的三份新研究ZIP字节仍缺，旧295份完整历史result.json仍缺。因此不把重做的基线称为原作者代码复现，也不将更新的成员分支冒充冻结底包。

对100例做了结构扫描，耗时25.662秒；通过独立tensor邻接遍历与官方COPY收缩的逐节点比较。计算操作数范围552–35705；18例只有一个计算弱连通分量，82例至少有4个；全部100例张量至多一个生产者。36例有多个分量且共享一种按拓扑排列的资源词，但“相同资源词”不等于图同构或执行等价。所有完整统计见analysis/scan100.json。

## 2. 必须服从的官方语义

方案只有node_to_subgraph与core_schedules两字段，不提交开始时间，不改图、不改cycles、不插入选手自定义算子。原COPY_IN/COPY_OUT不参与计算操作分组。所有构造固定原ID，并以原计算操作ID升序输出mapping，以免把迭代顺序变化混入比较。

Q2/Q3每核为一个Task；同核子图边界不自动产生DDR搬运。子图的优先序会稳定重排Step1序列，再影响Step2 spill与Step3固定Pipe FIFO。生成输入COPY位于最早本核消费子图，输出COPY位于生产者相关子图。故“一个计算操作一个子图”是控制排序的接口，不是自行指定硬件执行时间。

Q1每个子图都是Task，增加边界会引入DDR搬运、Task等待和缓存重置，不能照搬Q2/Q3的singleton设计。

固定配置：每核L1为524288 bytes，UB为131072 bytes；全核读写共享DDR60 bytes/cycle；Q2/Q3跨核COPY延迟500 cycles；Q3共享Cache容量1048576 bytes、Cache带宽250 bytes/cycle。Step2是先分配输出、检查瞬态容量，再执行和释放末次输入。本文不会合并或改写E0浮点带宽结算。

## 3. 一个可直接验证的结构化简化：原始张量区间证书

### 3.1 条件

原图为合法二部DAG、每张量至多一个生产者；原COPY_IN只从无生产者的DDR根张量读取，原COPY_OUT只写到无消费者的DDR叶张量；固定核心归属，每个计算操作一个子图，本核操作序拓扑合法。证书只针对Q2/Q3，且不证明Step3/跨核执行图可行。

`certify_plan.py`显式检查这些条件及官方方案入口，并支持任意合法子图编号。条件不满足时返回unsupported_or_invalid，而不是谎称方案一定spill或一定不spill。

### 3.2 公式与证明

对某核上的原始张量，取其本核计算生产者、消费者在该核顺序中的首末位置，记为first与last；没有本核生产者的输入从首个消费者处开始。原DDR位置若在官方Task中映射成UB，则按UB计数。每个张量只计一次，不因多消费者重复收费。

\[
M_{c,r}(i)=\sum_{t:\,\mathrm{pos}_{c}(t)=r}s_t\,\mathbf 1\{\mathrm{first}_{t,c}\le i\le\mathrm{last}_{t,c}\}.
\tag{附-1}
\]

这里必须是闭区间：当前操作的末次输入与新输出同时参与分配峰值。

证明要点：输入COPY只在首消费者所在singleton桶内提前分配该张量，输出COPY只在生产者桶内延后释放；它们不把生命周期端点移到另一个计算桶。当前计算操作的所有输入输出同时驻留时达到该桶最大值。因此上式给出无spill展开序列各桶的精确峰值。若所有峰值均不超容量，Step2的while-spill分支从不进入；若存在首次超限，此前尚无spill，Step2到达该峰值必进入spill分支或报不可执行。

\[
\bigl(\forall c,r,i:\ M_{c,r}(i)\le C_r\bigr)
\quad\Longleftrightarrow\quad
\text{该条件域内的Step2不产生spill。}
\tag{附-2}
\]

这不是物理并发内存峰值预测，更不是 makespan 的充分统计量。选择了较差的管线FIFO时，完全可以零spill但很慢。

本轮56个唯一singleton方案、13个正式实例：原始张量区间峰值与实际Step1/2展开序列峰值全部相等；47个通过零spill证书，9个未通过；零spill等价判断56/56一致。该审计临时绕过Step3，只检查Step1/2，不计为56次完整E0。独立的带条件检查器又逐个核对了56例，并验证子图重编号不会破坏证书。详见analysis/certificate_audit.json与guarded_certificate_audit.json。

### 3.3 增量更新，而不是每次遍历所有张量

为每个待调度操作维护其尚未引入的本核张量总字节。当前驻留量加上这些新字节，就是候选瞬态峰值；首次引入一个张量时，对它在同核的全部使用操作减去对应字节即可。

\[
A_{v,r}=\sum_{t\in\mathrm{touch}(v),\ t\notin\mathrm{seen}_{c(v)},\ \mathrm{pos}_{c(v)}(t)=r}s_t,
\qquad P_r(v)=L_{c(v),r}+A_{v,r}.
\tag{附-3}
\]

每个“tensor—本核使用操作”的关联只需在该tensor首次引入时更新一次；这一部分总更新量线性于关联数。完整状态仍须保留图、引用计数和每操作信息，不能把整个调度问题说成只有8维。

`fast_construct.py`实现整数数组前沿和向量化就绪筛选。其候选最终打分仍采用原Python表达式；不是E0优化。7个实例、2种压力权重共14组顺序与元数据逐项一致。纯构造热路径加速比约0.52–4.77倍，窄就绪集反而因数组开销变慢。该比较不含解析、核心归属、Python启动、E0或I/O，不能拿来宣称完整求解器同幅提速。全流程时长单独记录在第8节。

## 4. 构造算法：先保持数据归属，再决定下一步做什么

核心归属使用弱连通分量的双资源LPT；不足核数时，收缩唯一前驱/唯一后继串行边成包，用包含近似跨核代价的双Pipe完成时间启发式分配。收缩包用于归属，而不是永久绑定为一个执行桶。

维护拓扑ready集、每核M/V虚拟时钟、近似输入读取时钟、上述张量前沿与未完成消费者计数。这里的前沿按不发生spill计算；一旦逻辑峰值超限，它成为反事实的无spill驻留量，并非官方实际换入换出后的驻留状态。每步优先查看当前能够容纳的操作，再在有限就绪候选中比较预计开始时间、剩余关键路径和驻留压力变化。若没有内存可容纳的候选，保留最小溢出候选，最终让官方Step2决定spill，不伪造“不spill保证”。

\[
\Phi_c(L)=\sum_{r\in\{L1,UB\}}(L_{c,r}/C_r)^2,\qquad
\mathrm{priority}(v)=\bigl(\mathrm{overflow}(v),\ \widehat{s}_v+\lambda[\Phi_c(L')-\Phi_c(L)],\ -\mathrm{tail}(v),\ \mathrm{newread}(v),\ \mathrm{id}(v)\bigr).
\tag{附-4}
\]

采用字典序最小。frontier1取压力权重0，frontierp取1000 cycles；它是小规模开发后选定的启发式参数，不是推导出的通用常数。虚拟时钟没有精确模拟共享DDR、公平分配、COPY队首、Cache或Step3内存补边；它只产生排序建议，不能作为高精度E2标签。

把完成的拓扑序编译为singleton子图并投影到各核，交给未修改的E0。默认组合至多评估“粗基线、frontier1、frontierp”三个方案；保留已由官方确认的最佳方案。Q1不启用singleton候选。

## 5. 正式实例结果

### 5.1 开发集上的机制对照

case008：整分量123060；无容量意识的ready0为205662、spill8424960 bytes。初版单步容量筛选为94238、spill1695744；将容量筛选移到候选截断之前后为102140、spill774528，仍未解决后续可完成性。frontierp为64806且零spill。前三路摘要报告专用资源词63768，本轮未拿到其原始原型，故只说明当前通用方法尚未超过这一报告值，不作同条件排名。

case044：整分量124268、spill2887424；固定阶段交错wave4为68057、零spill；本轮就绪调度为66901、零spill。case046：粗基线124612、spill1722752；wave4为79860；就绪调度为77846，后两者零spill。值得注意的是这两例的无压力与有压力版本成绩相同，收益不能全归因于二次压力项。

case080：Q2粗基线111314；wave4为113802且spill229376；frontier1为107154，frontierp为107767。可见更密交错与更强压力项均非单调改善。

### 5.2 预登记的开发留出组

在开发6例之后登记7例，不再调权重；仍不是团队封存测试集，且原文可能已提到这些ID。下表前列是在同一固定归属上本轮构造的coarse/serial/wave4可用基线中的最好值；新列是两个frontier候选中的最好值。不同图的候选数不同，不把它称为等调用次数或全流程同预算排名。

__HOLDOUT_TABLE__

7例中6改善、1持平。其中case004新方法产生479232 spill bytes却更快，说明不能把证书当成硬目标筛掉所有spill方案。case013与093收益很小，应看求解时间是否值得。case002两种新候选分别为67530、62819，不可只展示一个“总是更好”的压力规则。

case002总M工作量240000，在4核上纯计算下界60000。因此62819与真正全局最优的相对差距最多4.699%；这只是有效下界证书，不是已求出最优。case008相应下界62532，64806距其3.636%。不使用可能受浮点结算影响的实数DDR推导充当零差分证明。

## 6. 反例与跨场景试验

### 6.1 前缀放得下，但已经走入必须spill的状态

微图含两条独立两段链。第一段各留64KiB UB，第二段同时读该64KiB并生成另一个64KiB。两条第一段先执行后恰好用完128KiB UB，但任何第二段再分配输出都会要求192KiB。依次完成整条链则峰值只有128KiB。

同一合法原图、同一2核方案形状（故意仅一个活动核）经完整E0：`admit_both`为4775 cycles、额外spill131072 bytes；`finish_one`为2489、零spill。这是机制微例，不是平均收益。

### 6.2 Banker式安全完成检查：已实现，但不是默认方法

以Dijkstra的安全状态判据为启发，对独立作业固定内部序，预留共享输入，并以每条作业剩余最大私有峰值检查是否存在能依次完成所有活动作业的次序。存在这样的完成排列足以保障该保守抽象中的无spill完成，而非一般最优时延。

case008得到94512、零spill，明显慢于frontierp64806；case044、080因共享输入并集预留过大被本实现拒绝。它展示了“能证明安全”和“能高效完成”之间的差距，不值得目前当主构造。

### 6.3 Q2/Q3不能共用排名，Q1不能共用细粒度

同一批原样计划分别跑Q3：case044的wave4为67724、frontierp为66554；case080的wave4为84831、frontier1为85317、frontierp为81404。case080在Q2上frontier1最好，在Q3上frontierp最好。Q3需要自身官方标签和确认，不用静态总COPY字节推测Cache收益。

同计划跑Q1：case008粗基线157796、frontierp553796；case044粗基线175649、frontierp257016。此次仅做失败边界试验，未优化Q1。粗到细映射在Q2有效的原因不能偷换成对Q1也有效。

## 7. 神经网络轻量实测

### 7.1 数据与隔离

构建60个可运行的合成图，5族各12例：同质M-V-V-M、同质M-V×6-M、共享逐层权重的残差图、宽归约图、异质资源重入图。每图保留真实ID、显式边界COPY、张量大小与位置；使用官方图入口验证。

前三族36例训练，宽归约12例验证，异质重入12例只用于最终测试。没有用100正式例的结果训练网络。4个候选每图全部用未修改evaluate_scene_b生成标签，240次API调用成功，保存完整result.json；总合成/构造/标注/落盘约7.409秒。它们不是240次CLI测试，也不替代正式大图分布。

当前合成集尚缺强连通计算结构的多核切分、接近每个容量临界点的精细扰动、L2填充/逐出/在飞重插、2/3/5核与最大规模。下一批应按机制分层覆盖这些缺口，而非仅增加同一模板随机种子。重编号会改变官方tie-break或Cache key语义时必须重新打E0标签，不能直接复用旧标签。

### 7.2 模型与损失

14维图级特征包含图规模/分量、M/V工作比、关键路径比、tensor最大/总字节、共享fanout、外部输入量及分支汇聚比例。MLP为14–32–32，输出4个候选代价和4个spill logit。候选是coarse、wave4、frontier1、frontierp。

\[
y_a=\log(T_a/\min_b T_b),\qquad
\mathcal L=0.6\mathcal L_{\rm pairwise}(\tau=0.1)+0.3\mathcal L_{\rm SmoothL1}(\beta=0.1)+0.1\mathcal L_{\rm spill\text{-}BCE}.
\tag{附-5}
\]

排名损失只用于真实代价不相等的候选对。AdamW学习率0.001、weight decay0.001、300轮、3个随机种子；按验证集平均候选池遗憾选轮次，再看测试。随机森林100树、最大深度3作为简单学习基线。

\[
R(g)=T_{\rm chosen}(g)/\min_{a\in\text{四候选池}}T_a(g)-1.
\tag{附-6}
\]

此处的最优只是四候选池最优，不是全局最优；评价也不是E2的绝对makespan误差。

__LEARNING_TABLE__

训练集选出的固定策略是frontierp。MLP优于这个训练选择和RF，但测试平均遗憾没有胜过固定frontier1；MLP的P95稍低，不能说某方全面支配。测试仅12例且属于一个新异质家族，P95是样本分位数，无稳健尾部保证。seed0在第0轮（一次参数更新后）已达到所选验证最优，也提示小验证集的不稳定。

3次训练各约0.77–1.33秒；网络本体热batch1推理约46–75微秒，未含解析、特征、候选构造、模型加载和E0。不能用这个数字宣称单实例总时间。没有证据支持为这个模型启用A100。

### 7.3 有条件的下一步

若继续学习，优先做“候选条件化”而非直接逐op自回归：异构op/tensor图输入，叠加候选的核心归属、相对顺序、每tensor生命周期、跨核端点、COPY桶角色及容量峰值。可先试3层宽64的异构消息传递并输出候选排名/代价/失败风险；仍由确定性解码器保证格式、拓扑及原ID，执行可行性和最终性能交给E0。

大图训练可借鉴TpuGraphs/GST的配置条件化与分段训练，但它们的标签是TPU布局/分块配置运行时间，不能混作本题标签。分段如果丢弃跨段输入/输出和长期共享权重，会失去本题最关键的驻留信息。

不必给硬约束都加惩罚再期待网络学会；可检查条件直接检查。未来数据中的执行失败与超时要分开：失败可用分类头；超时是删失信息，不应直接当精确代价或丢掉，以免偏向易评估样本。

## 8. 单例预算、构造效率与硬件

下表是单个独立进程的墙钟，包含解释器启动、解析、归属、候选构造、完整E0、结果/trace落盘、选优与输出。每项只重复一次，不是稳定性置信区间或E1配对基准。候选构造温热计时与这个表不得混用。

__DEADLINE_TABLE__

初版大图case014（35705计算操作）在120秒预算中只能完成粗基线确认，后续就绪构造超时，退回4541383。增量/向量化版在同内部预算下确认frontier1为4434882，时长降低2.345%，但spill字节从26378640增至81343488；它是时延与流量的Pareto取舍，不应包装成无代价胜利。增量版最后一个压力候选仍超时，且外墙120.596秒仍略超内部预算。case002完整流程由16.471秒降至10.053秒，选中相同62819；每项只跑一次，不能宣称稳定1.64倍端到端加速。外部进程实测120.826秒，说明内部预算不是进程外墙严格硬限；生产交付须由父进程守护已确认基线，并给进程启动、取消、落盘预留余量。不可把超时构造出的未确认计划当答案。

整数增量前沿避免重复tensor扫描；向量化ready筛选改善宽就绪集的常数，但不把整个算法变成线性。每步若仍查看全部ready，最坏复杂度仍可呈二次。大图应限制候选检查宽度或采用可局部更新的就绪索引；这些改变应重新做方案质量验收，而不能称“语义等价加速”。

CPU是当前E0与小模型的合适起点。CUDA或Apple MPS可承载将来批量GNN训练，但不会自动加速Python堆、字典和逐事件模拟。Apple上可以先跑纯Python/NumPy构造与官方验证；在锁定版本和浮点环境前不宣称跨平台零差分。Colab200CU不是固定A100小时数；实际分配/消耗率需在资源环境中确认，本轮未访问该账户也未消耗其额度。

## 9. 一手研究的取舍，而非名词套用

1. Jin等《New Tools for Peak Memory Scheduling》，arXiv2312.13526。其dominant schedule比较整个内存profile而不只是峰值，允许在相应条件下把孤立子图线性化。启发本轮保存张量前沿与剩余峰值；但其峰值模型不是本题双Pipe、L1/UB、异步COPY和共享DDR完整语义。不能把“存在dominant schedule”说成通用多项式构造，更不能说一条标量峰值足以描述官方执行。
2. Dijkstra EWD108/EWD623。借鉴可完成安全状态而不是当前分配量。已做Banker原型并报告其保守失败与时延劣势。
3. Paliwal等REGAL，《Reinforced Genetic Algorithm Learning for Optimizing Computation Graphs》，ICLR2020，arXiv1905.02494。网络学搜索提议分布，而非为每张新图从零训练。其模型每设备一次一个op、跨设备阻塞传输，与本题不同；借鉴学习位置，不移植评估语义。
4. TpuGraphs，NeurIPS2023，arXiv2308.13490，源码google-research-datasets/tpu_graphs。数据单位是图、编译配置、运行时间；适合学习“候选条件化”的数据组织。仓库已在2025-08-28归档，应借鉴协议而不是当现成维护中的NPU求解器。
5. Cao等GST，arXiv2305.12322，作者仓库kaidic/GST。用于大图属性预测的分段训练，是未来图模型内存方案，不是当前已验证贡献。
6. GitHub ai4co/rl4co与HuggingFace ai4co。检索到通用组合优化框架、routing/PARCO等公开资源；没有在本轮核实可直接匹配本题E0的预训练模型或标签。它们可提供训练框架，不应直接把旅行商、路径规划环境当本题调度环境。
7. Google DeepMind AlphaEvolve，arXiv2506.13131及官方技术说明。可借鉴离线演化构造函数、由独立评估器打分的研发流程。本轮没有运行该产品；不建议在每个正式实例上让LLM大量生成方案并以测试集为反馈反复搜索。

## 10. 后续可证伪试验与停止条件

第一优先：把同一候选组合交给团队锁定Python3.12环境，对未参与本轮开发的图族、2–5核、Q2/Q3做等单例预算比较。将基线确认、特征和模型加载、候选构造、E0、选优与落盘全部计时，报告超时/非法率与基线回退率。若只是多跑候选取巧，不计作构造优势。

第二优先：将整数前沿索引与少候选预算结合。把大图候选扫描宽度从固定64改成受剩余预算控制的范围，先检验收益损失与完整壁钟，再考虑复杂优先队列。尤其检查大量共享输入、近满UB、远端出口和单Pipe瓶颈。

第三优先才是GNN。先扩充独立图族与容量临界样本，固定CPU/树模型/MLP对照，再决定是否启用小额A100试验。建议将“等预算跨族收益、P95不明显退化、非法率不升、模型与特征总成本小于所节省E0时间”作为四个进入条件。未达条件时，保留模型作为分析工具而非默认路由器。

本轮的证据支持一套有用的小原型与明确的失败边界，不支持“全题已解”“全域最优”“E1/E2达标”“神经网络普遍无用”或“GPU必需”的结论。

## 11. 证据位置

`src/`：可执行源码；`analysis/`：结构扫描、证书核对、学习结果；`experiments/`：全部已保留方案、完整官方result.json/trace/log、失败和限时运行记录、60个合成原图及240份API标签。

`audit/`：材料身份、原始运行环境与源代码冻结信息。交付包提供MANIFEST.json和verify_evidence.py；bootstrap_official.py从随包的官方cases压缩包校验并提取100例。最终解答中的表格应以这些JSON为准，而不是口头摘要。
'''
text=text.replace('__HOLDOUT_TABLE__',table(['case','本轮基线最好/cycles','两frontier最好/cycles','时长降低','新方案spill字节'],ht)).replace('__LEARNING_TABLE__',table(['策略','测试平均候选池遗憾','测试P95候选池遗憾'],lt)).replace('__DEADLINE_TABLE__',table(['版本','case','内部预算/s','全进程墙钟/s','选中makespan','候选状态'],dead))
(ROOT/'REPORT_ZH.md').write_text(text)
print('wrote report bytes',len(text.encode()))
