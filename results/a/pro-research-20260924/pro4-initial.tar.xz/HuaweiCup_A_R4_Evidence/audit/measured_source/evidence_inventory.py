from pathlib import Path
import json,hashlib,collections
ROOT=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
rows=[];mismatches=[]
for p in sorted((ROOT/'experiments').rglob('run.json')):
 r=json.loads(p.read_text());item={'path':str(p.relative_to(ROOT)), 'status':r['status'],'problem':r.get('problem'),'result_present':(p.parent/'result.json').exists()}
 if r['status']=='ok':
  z=json.loads((p.parent/'result.json').read_text())
  for key,expected in [('makespan',r.get('makespan')),('data_movement_bytes',r.get('movement'))]:
   if z.get(key)!=expected:mismatches.append((str(p),key))
  if r.get('plan_sha256')!=sha(p.parent/'plan.json'):mismatches.append((str(p),'plan_sha256'))
  if r.get('result_sha256')!=sha(p.parent/'result.json'):mismatches.append((str(p),'result_sha256'))
  item['makespan']=z['makespan'];item['case']=Path(r['command'][2]).stem;item['graph_sha256']=r['graph_sha256']
 rows.append(item)
labels=json.loads((ROOT/'experiments/synthetic/labels.json').read_text());actions=['coarse','wave4','frontier1','frontierp'];api=0
for row in labels:
 for j,action in enumerate(actions):
  p=ROOT/'experiments/synthetic'/f"f{row['family']}_{row['seed']:02d}"/action/'result.json'
  z=json.loads(p.read_text());api+=1
  if z['makespan']!=row['labels'][j] or z['data_movement_bytes']['spill_added_copy_bytes']!=row['spill'][j]:mismatches.append((str(p),'synthetic_label'))
x={'cli_runs':len(rows),'cli_status':dict(collections.Counter(r['status'] for r in rows)),'cli_by_problem':dict(collections.Counter(r['problem'] for r in rows)),'official_graph_ids':sorted(set(r['case'] for r in rows if r.get('case','').startswith('case_'))),'synthetic_graphs':len(labels),'synthetic_unmodified_E0_API_runs':api,'step12_diagnostic_plans':56,'full_result_metric_or_hash_mismatches':mismatches,'records':rows}
(ROOT/'analysis/evidence_inventory.json').write_text(json.dumps(x,indent=2));print(json.dumps({k:v for k,v in x.items() if k!='records'},indent=2));assert not mismatches
