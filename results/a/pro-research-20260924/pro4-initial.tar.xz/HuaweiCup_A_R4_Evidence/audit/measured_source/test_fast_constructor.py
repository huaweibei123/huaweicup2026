"""Paired warm constructor comparison only; parsing/assignment/E0 excluded."""
from core import *
from fast_construct import ready_order_fast
from experiments import ROOT
import time,json
rows=[]
for ci in [2,8,13,44,64,78,80]:
 g=Graph.load(OFFICIAL/'data'/f'case_{ci:03d}.json');k=4;a=lpt(g,k)
 if len(g.comps)<k:a,_=packet_assignment(g,k)
 for pressure in [0,1]:
  t=time.perf_counter();s,m=ready_order(g,a,k,True,1,pressure,64);old=time.perf_counter()-t
  t=time.perf_counter();ss,mm=ready_order_fast(g,a,k,True,1,pressure,64);new=time.perf_counter()-t
  same=s==ss and all(m[key]==mm[key] for key in m)
  rows.append({'case':ci,'pressure':pressure,'order_and_metadata_equal':same,'old_constructor_seconds':old,'new_constructor_seconds':new,'ratio':old/new})
  assert same,(ci,pressure,next(((i,x,y) for i,(x,y) in enumerate(zip(s,ss)) if x!=y),None))
  (ROOT/'analysis/fast_constructor_checks.json').write_text(json.dumps(rows,indent=2));print(ci,pressure,same,round(old/new,3),flush=True)
