"""Small original-graph constructive prototype. E0 remains unmodified.
Graph parsing supports public bipartite graphs. All original IDs are retained.
"""
from __future__ import annotations
import json,heapq,math,sys,os
from pathlib import Path
from collections import defaultdict,Counter
OFFICIAL=Path(os.environ.get('HUAWEI_OFFICIAL','/mnt/data/r4_bundle/data/raw/a/official'))
sys.path.insert(0,str(OFFICIAL/'code'))
from stub_multicore_cut_and_schedule import _build_op_adjacency,_contract_excluded_copy_nodes
CAP={'L1':524288,'UB':131072}

class Graph:
 def __init__(self,d):
  self.data=d; self.ops={o['id']:o for o in d['ops']}; self.ts={t['id']:t for t in d['tensors']}
  self.ids=sorted(v for v,o in self.ops.items() if o['op'] not in {'COPY_IN','COPY_OUT'});self.eligible=set(self.ids)
  self.ins={v:set() for v in self.ops};self.outs={v:set() for v in self.ops}
  self.prod={t:set() for t in self.ts};self.cons={t:set() for t in self.ts}
  for e in d['edges']:
   a,b=e['source'],e['target']
   if a in self.ops and b in self.ts:self.outs[a].add(b);self.prod[b].add(a)
   elif a in self.ts and b in self.ops:self.ins[b].add(a);self.cons[a].add(b)
   else:raise ValueError('Prototype requires public bipartite edges')
  _,s=_build_op_adjacency(d);self.pred,self.succ=_contract_excluded_copy_nodes(self.ids,s)
  self.topo=self.sort();self.rank={v:i for i,v in enumerate(self.topo)};self.tail={};self.depth={}
  for v in reversed(self.topo):self.tail[v]=self.cy(v)+max((self.tail[u] for u in self.succ[v]),default=0)
  for v in self.topo:self.depth[v]=max((self.depth[u]+1 for u in self.pred[v]),default=0)
  self.comps=[];unseen=set(self.ids)
  while unseen:
   v=min(unseen);unseen.remove(v);stack=[v];cc=[]
   while stack:
    v=stack.pop();cc.append(v)
    for u in sorted((self.pred[v]|self.succ[v])&unseen):unseen.remove(u);stack.append(u)
   self.comps.append(sorted(cc,key=self.rank.__getitem__))
  self.job={v:j for j,cc in enumerate(self.comps) for v in cc}
 @classmethod
 def load(cls,p):return cls(json.loads(Path(p).read_text()))
 def cy(self,v):return max(1,self.ops[v]['cycles'])
 def pipe(self,v):return self.ops[v]['pipe']
 def sort(self,key=None):
  key=key or (lambda v:v);d={v:len(self.pred[v]) for v in self.ids};q=[(key(v),v) for v in self.ids if not d[v]];heapq.heapify(q);out=[]
  while q:
   _,v=heapq.heappop(q);out.append(v)
   for u in sorted(self.succ[v]):
    d[u]-=1
    if not d[u]:heapq.heappush(q,(key(u),u))
  if len(out)!=len(self.ids):raise ValueError('compute cycle')
  return out
 def stats(self):
  pw=Counter();words=Counter()
  for v in self.ids:pw[self.pipe(v)]+=self.cy(v)
  for cc in self.comps:words[tuple((self.pipe(v),self.cy(v)) for v in cc)]+=1
  return {'ops':len(self.ids),'tensors':len(self.ts),'components':len(self.comps),'max_component':max(map(len,self.comps),default=0),'component_sizes':dict(Counter(map(len,self.comps))),'work':dict(pw),'critical_path':max(self.tail.values(),default=0),'word_types':len(words),'max_producers':max(map(len,self.prod.values()),default=0)}

def lpt(g,k,groups=None):
 groups=g.comps if groups is None else groups;load=[defaultdict(int) for _ in range(k)];a={}
 for cc in sorted(groups,key=lambda x:(-sum(g.cy(v) for v in x),min(x))):
  w=Counter()
  for v in cc:w[g.pipe(v)]+=g.cy(v)
  c=min(range(k),key=lambda c:(max(load[c][p]+w[p] for p in ('PIPE_M','PIPE_V')),sum(load[c].values()),c))
  for v in cc:a[v]=c
  for p,val in w.items():load[c][p]+=val
 return a

def plan(g,a,order,k,groups=None):
 if groups is None:groups=[[v] for v in order]
 mp={};cs=[[] for _ in range(k)]
 for j,cc in enumerate(groups):
  c=a[cc[0]]
  assert all(a[v]==c for v in cc)
  cs[c].append(j)
  for v in cc:mp[v]=j
 return {'node_to_subgraph':{str(v):mp[v] for v in g.ids},'core_schedules':cs}

def chain_groups(g):
 gs=[];which={}
 for v in g.topo:
  p=next(iter(g.pred[v])) if len(g.pred[v])==1 else None
  if p is not None and len(g.succ[p])==1:j=which[p]
  else:j=len(gs);gs.append([])
  gs[j].append(v);which[v]=j
 return gs,which

def packet_assignment(g,k):
 """List placement of serial packets with a two-pipe virtual clock and COPY costs."""
 gs,w=chain_groups(g);pp={j:set() for j in range(len(gs))};ss={j:set() for j in pp}
 for v in g.ids:
  for u in g.succ[v]:
   if w[v]!=w[u]:pp[w[u]].add(w[v]);ss[w[v]].add(w[u])
 tail={j:max(g.tail[v] for v in cc) for j,cc in enumerate(gs)};dd={j:len(pp[j]) for j in pp};q=[(-tail[j],j) for j in pp if not dd[j]];heapq.heapify(q)
 clock=[defaultdict(int) for _ in range(k)];a={};end={};ordered=[]
 while q:
  _,j=heapq.heappop(q);cc=gs[j];best=None
  for c in range(k):
   cl=clock[c].copy();en={}
   for v in cc:
    r=0
    for p in g.pred[v]:r=max(r,en[p] if p in en else end[p]+(0 if a[p]==c else 500))
    for t in g.ins[v]:
     for p in g.prod[t]&g.eligible:
      if p in a and a[p]!=c:r=max(r,end[p]+500+2*math.ceil(g.ts[t]['size']/60))
    en[v]=max(r,cl[g.pipe(v)])+g.cy(v);cl[g.pipe(v)]=en[v]
   key=(max(cl.values()),sum(cl.values()),c)
   if best is None or key<best[0]:best=(key,c,cl,en)
  _,c,cl,en=best;clock[c]=cl;end.update(en);a.update({v:c for v in cc});ordered.append(cc)
  for u in sorted(ss[j]):
   dd[u]-=1
   if not dd[u]:heapq.heappush(q,(-tail[u],u))
 return a,ordered

def waves(g,a,k,width=4,step=4):
 """Fixed-operation slices across at most width independent components per core."""
 out=[]
 for c in range(k):
  cs=[cc for cc in g.comps if a[cc[0]]==c]
  for z in range(0,len(cs),width):
   batch=cs[z:z+width]
   for i in range(0,max(map(len,batch),default=0),step):
    for cc in batch:out.extend(cc[i:i+step])
 return out

class Frontier:
 """Serial no-spill liveness of singleton buckets; not physical concurrent usage."""
 def __init__(self,g,a,k):
  self.g=g;self.a=a;self.rem=Counter();self.seen=[set() for _ in range(k)]
  self.live=[dict(L1=0,UB=0) for _ in range(k)];self.peak=[dict(L1=0,UB=0) for _ in range(k)]
  self.touch={v:g.ins[v]|g.outs[v] for v in g.ids}
  self.pos={t:('UB' if d['pos']=='DDR' else d['pos']) for t,d in g.ts.items()}
  for v,ts in self.touch.items():
   for t in ts:self.rem[(a[v],t)]+=1
 def measure(self,v):
  c=self.a[v];new=self.touch[v]-self.seen[c];pk=self.live[c].copy();release=dict(L1=0,UB=0)
  for t in new:pk[self.pos[t]]+=self.g.ts[t]['size']
  for t in self.touch[v]:
   if self.rem[c,t]==1:release[self.pos[t]]+=self.g.ts[t]['size']
  return new,pk,release
 def put(self,v,meas=None):
  c=self.a[v];new,pk,rel=meas or self.measure(v);self.seen[c].update(new)
  for p in CAP:self.peak[c][p]=max(self.peak[c][p],pk[p]);self.live[c][p]=pk[p]-rel[p]
  for t in self.touch[v]:self.rem[c,t]-=1
 def result(self):
  return {'static_peak_by_core':self.peak,'no_spill_certificate':all(z[p]<=CAP[p] for z in self.peak for p in CAP)}

def certify(g,a,k,order):
 f=Frontier(g,a,k)
 for v in order:f.put(v)
 return f.result()

def ready_order(g,a,k,gate=True,io_scale=1.0,pressure=0.0,limit=0):
 """Earliest virtual start, memory admission, longest-tail tie break.
 No shared-pool timing accuracy is claimed. 'limit' caps candidate consideration
 by earliest compute-only release; zero means full ready-set scan.
 """
 f=Frontier(g,a,k);degree={v:len(g.pred[v]) for v in g.ids};ready={v for v in g.ids if not degree[v]}
 clock=[defaultdict(float) for _ in range(k)];fill=[0.0]*k;done={};out=[];overflow_steps=0
 while ready:
  pool=ready
  if limit and len(ready)>limit:
   pool=heapq.nsmallest(limit,ready,key=lambda v:(max(clock[a[v]][g.pipe(v)],max((done[p] for p in g.pred[v]),default=0)),-g.tail[v],v))
  best=None
  for v in pool:
   c=a[v];meas=f.measure(v);new,pk,rel=meas
   of=sum(max(0,pk[p]-CAP[p])/CAP[p] for p in CAP)
   dep=max((done[p]+(500 if a[p]!=c else 0) for p in g.pred[v]),default=0)
   cp=fill[c];newbytes=0
   if io_scale:
    for t in sorted(new & g.ins[v]):
     localprod=[p for p in g.prod[t]&g.eligible if a[p]==c]
     if not localprod:
      src=max((done[p]+500+math.ceil(g.ts[t]['size']/60) for p in g.prod[t]&g.eligible),default=0)
      cp=max(cp,src)+max(1,math.ceil(g.ts[t]['size']/60))*io_scale;newbytes+=g.ts[t]['size']
   st=max(clock[c][g.pipe(v)],dep,cp if io_scale else 0)
   # Optional normalized convex pressure change, expressed in heuristic cycles.
   ph=sum(((pk[p]-rel[p])/CAP[p])**2-(f.live[c][p]/CAP[p])**2 for p in CAP)
   key=(of if gate else 0,st+pressure*ph*1000,-g.tail[v],newbytes,v)
   if best is None or key<best[0]:best=(key,v,meas,st,cp,of)
  _,v,meas,st,cp,of=best;c=a[v];ready.remove(v);out.append(v)
  done[v]=st+g.cy(v);clock[c][g.pipe(v)]=done[v];fill[c]=cp;f.put(v,meas)
  overflow_steps+=int(of>0)
  for u in g.succ[v]:
   degree[u]-=1
   if not degree[u]:ready.add(u)
 d=f.result();d.update(virtual_makespan=max(done.values(),default=0),overflow_steps=overflow_steps,ready_limit=limit)
 return out,d

if __name__=='__main__':
 import argparse,time
 p=argparse.ArgumentParser();p.add_argument('graph');p.add_argument('output');p.add_argument('--cores',type=int,default=4);p.add_argument('--method',choices=['component','packet','ready','ready_io','ready_pressure','wave'],default='ready_io');args=p.parse_args()
 st=time.perf_counter();g=Graph.load(args.graph);k=args.cores;a=lpt(g,k)
 if len(g.comps)<k:a,gs=packet_assignment(g,k)
 else:gs=g.comps
 meta={}
 if args.method=='component':result=plan(g,a,g.topo,k,gs)
 elif args.method=='packet':a,gs=packet_assignment(g,k);result=plan(g,a,g.topo,k,gs)
 elif args.method=='wave' and len(g.comps)>=k:seq=waves(g,a,k);result=plan(g,a,seq,k);meta=certify(g,a,k,seq)
 else:
  seq,meta=ready_order(g,a,k,gate=True,io_scale=0 if args.method=='ready' else 1,pressure=1 if args.method=='ready_pressure' else 0,limit=64)
  result=plan(g,a,seq,k)
 Path(args.output).write_text(json.dumps(result));meta['construction_seconds']=time.perf_counter()-st
 Path(str(args.output)+'.meta.json').write_text(json.dumps(meta,indent=2));print(json.dumps(meta))
