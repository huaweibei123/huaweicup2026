"""Guarded original-tensor interval certificate for Q2/Q3 singleton plans.
This is not an evaluator and does not certify Step3/global execution feasibility.
It rejects unsupported COPY topologies and coarse subgraphs, rather than claiming
that an unsupported plan spills. Counts allocate-before-free closed intervals.
"""
from __future__ import annotations
import json,argparse
from collections import defaultdict
from core import Graph,CAP
from stub_multicore_cut_and_schedule import derive_multicore_plan

def check_scope(g:Graph):
 if any(len(p)>1 for p in g.prod.values()):raise ValueError('unsupported: multi-producer tensor')
 for v,op in g.ops.items():
  if op['op']=='COPY_IN':
   if not g.ins[v] or any(g.ts[t]['pos']!='DDR' or g.prod[t] for t in g.ins[v]):
    raise ValueError('unsupported: COPY_IN is not sourced only by original root DDR tensors')
   if any(g.ts[t]['pos']=='DDR' for t in g.outs[v]):raise ValueError('unsupported COPY_IN output')
  if op['op']=='COPY_OUT':
   if any(g.ts[t]['pos']=='DDR' for t in g.ins[v]):raise ValueError('unsupported COPY_OUT input')
   if not g.outs[v] or any(g.ts[t]['pos']!='DDR' or g.cons[t] for t in g.outs[v]):
    raise ValueError('unsupported: COPY_OUT does not terminate in DDR sinks')

def certificate(g:Graph,pl:dict):
 check_scope(g);view=derive_multicore_plan(g.data,pl)
 if len(set(view['mapping'].values()))!=len(g.ids):raise ValueError('unsupported: requires one original compute op per subgraph')
 v_by_sg={sg:v for v,sg in view['mapping'].items()};k=len(pl['core_schedules']);peaks=[]
 for c,sgs in enumerate(pl['core_schedules']):
  vs=[v_by_sg[s] for s in sgs];bounds={}
  for i,v in enumerate(vs):
   for t in g.ins[v]|g.outs[v]:
    if t in bounds:bounds[t][1]=i
    else:bounds[t]=[i,i]
  delta={p:[0]*(len(vs)+1) for p in CAP}
  for t,(first,last) in bounds.items():
   pos='UB' if g.ts[t]['pos']=='DDR' else g.ts[t]['pos'];size=g.ts[t]['size']
   delta[pos][first]+=size;delta[pos][last+1]-=size
  peak={}
  for p,ds in delta.items():
   cur=mx=0
   for d in ds:cur+=d;mx=max(mx,cur)
   assert cur==0;peak[p]=mx
  peaks.append(peak)
 return {'scope_checked':True,'singleton_closed_interval_peak':peaks,'no_spill_certificate':all(p[r]<=CAP[r] for p in peaks for r in CAP),'capacity':CAP,'meaning':'Exact pre-spill serial bucket peak under checked assumptions. Does NOT certify Step3 or global execution, makespan, or Q1.'}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('graph');p.add_argument('plan');p.add_argument('-o','--output');a=p.parse_args()
 try:r=certificate(Graph.load(a.graph),json.load(open(a.plan)));code=0
 except Exception as e:r={'scope_checked':False,'status':'unsupported_or_invalid','reason':str(e)};code=2
 text=json.dumps(r,indent=2);print(text)
 if a.output:open(a.output,'w').write(text)
 raise SystemExit(code)
