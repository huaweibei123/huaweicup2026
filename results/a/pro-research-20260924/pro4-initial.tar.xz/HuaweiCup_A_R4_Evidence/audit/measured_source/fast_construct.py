"""Incremental integer frontier + vectorized ready shortlist; E0 untouched.

At the first local use of tensor t, subtract its size once from 'new bytes' of
all its local users. Each tensor incidence is updated once. Heap-like shortlist
keys are computed from cached predecessor finish maxima. Float scoring of the
selected shortlist is deliberately the same Python expression as core.py.
This is a constructor optimization, not an exact evaluator rewrite.
"""
from core import *
import numpy as np

def ready_order_fast(g,a,k,gate=True,io_scale=1.0,pressure=0.0,limit=64):
 f=Frontier(g,a,k);n=len(g.ids);ids=np.array(g.ids,dtype=np.int64);index={v:i for i,v in enumerate(g.ids)}
 ci=np.array([a[v] for v in g.ids],dtype=np.int64);pi=np.array([0 if g.pipe(v)=='PIPE_M' else 1 for v in g.ids],dtype=np.int64)
 if any(g.pipe(v) not in {'PIPE_M','PIPE_V'} for v in g.ids):raise ValueError('fast constructor supports M/V compute pipes only')
 if max((g.ts[t]['size'] for t in g.ts),default=0)*(len(g.ts)+1)>=2**62:raise ValueError('fast integer range unsupported')
 cap=np.array([CAP['L1'],CAP['UB']],dtype=np.int64);rindex={'L1':0,'UB':1};need=np.zeros((n,2),dtype=np.int64);users=defaultdict(list)
 for i,v in enumerate(g.ids):
  for t in f.touch[v]:need[i,rindex[f.pos[t]]]+=g.ts[t]['size'];users[a[v],t].append(i)
 users={key:np.array(ix,dtype=np.int64) for key,ix in users.items()}
 deg=np.array([len(g.pred[v]) for v in g.ids],dtype=np.int64);ready=(deg==0);dependency=np.zeros(n,dtype=np.float64)
 tail=np.array([g.tail[v] for v in g.ids],dtype=np.int64)
 clock=[defaultdict(float) for _ in range(k)];fill=[0.0]*k;done={};out=[];overflow_steps=0
 while np.any(ready):
  ix=np.flatnonzero(ready);live=np.array([[f.live[c]['L1'],f.live[c]['UB']] for c in range(k)],dtype=np.int64)
  if gate:
   fits=np.all(live[ci[ix]]+need[ix]<=cap,axis=1)
   if np.any(fits):ix=ix[fits]
  if limit and len(ix)>limit:
   cl=np.array([[clock[c]['PIPE_M'],clock[c]['PIPE_V']] for c in range(k)],dtype=np.float64)
   release=np.maximum(cl[ci[ix],pi[ix]],dependency[ix]);q=np.lexsort((ids[ix],-tail[ix],release));ix=ix[q[:limit]]
  best=None
  for ii in ix:
   v=int(ids[ii]);c=a[v];meas=f.measure(v);new,pk,rel=meas
   of=sum(max(0,pk[p]-CAP[p])/CAP[p] for p in CAP)
   dep=max((done[p]+(500 if a[p]!=c else 0) for p in g.pred[v]),default=0)
   cp=fill[c];newbytes=0
   if io_scale:
    for t in sorted(new & g.ins[v]):
     localprod=[p for p in g.prod[t]&g.eligible if a[p]==c]
     if not localprod:
      src=max((done[p]+500+math.ceil(g.ts[t]['size']/60) for p in g.prod[t]&g.eligible),default=0)
      cp=max(cp,src)+max(1,math.ceil(g.ts[t]['size']/60))*io_scale;newbytes+=g.ts[t]['size']
   st=max(clock[c][g.pipe(v)],dep,cp if io_scale else 0)
   ph=sum(((pk[p]-rel[p])/CAP[p])**2-(f.live[c][p]/CAP[p])**2 for p in CAP)
   key=(of if gate else 0,st+pressure*ph*1000,-g.tail[v],newbytes,v)
   if best is None or key<best[0]:best=(key,v,meas,st,cp,of)
  _,v,meas,st,cp,of=best;c=a[v];ii=index[v];ready[ii]=False;out.append(v)
  done[v]=st+g.cy(v);clock[c][g.pipe(v)]=done[v];fill[c]=cp
  for t in meas[0]:need[users[c,t],rindex[f.pos[t]]]-=g.ts[t]['size']
  f.put(v,meas);overflow_steps+=int(of>0)
  for u in g.succ[v]:
   jj=index[u];deg[jj]-=1;dependency[jj]=max(dependency[jj],done[v])
   if not deg[jj]:ready[jj]=True
 d=f.result();d.update(virtual_makespan=max(done.values(),default=0),overflow_steps=overflow_steps,ready_limit=limit,implementation='incremental_integer_numpy')
 return out,d

if __name__=='__main__':
 import argparse,time
 p=argparse.ArgumentParser();p.add_argument('graph');p.add_argument('output');p.add_argument('--cores',type=int,default=4);p.add_argument('--method',choices=['component','packet','ready','ready_io','ready_pressure','wave'],default='ready_io');args=p.parse_args()
 st=time.perf_counter();g=Graph.load(args.graph);k=args.cores;a=lpt(g,k)
 if len(g.comps)<k:a,gs=packet_assignment(g,k)
 else:gs=g.comps
 meta={}
 if args.method=='component':result=plan(g,a,g.topo,k,gs)
 elif args.method=='packet':a,gs=packet_assignment(g,k);result=plan(g,a,g.topo,k,gs)
 elif args.method=='wave' and len(g.comps)>=k:seq=waves(g,a,k);result=plan(g,a,seq,k);meta=certify(g,a,k,seq)
 else:
  seq,meta=ready_order_fast(g,a,k,True,0 if args.method=='ready' else 1,1 if args.method=='ready_pressure' else 0,64);result=plan(g,a,seq,k)
 Path(args.output).write_text(json.dumps(result));meta['construction_seconds']=time.perf_counter()-st;Path(str(args.output)+'.meta.json').write_text(json.dumps(meta,indent=2));print(json.dumps(meta))
