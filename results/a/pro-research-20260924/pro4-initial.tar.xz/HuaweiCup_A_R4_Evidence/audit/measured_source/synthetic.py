"""Motif-based training pilot, not substitutes for the 100 official graphs.
All graphs have explicit original DDR COPY boundaries and original tensor IDs.
Labels call the unmodified E0 Python function (not a fast proxy).
"""
from core import *
from experiments import ROOT,digest
import random,time,traceback
from multicore_cut_evaluate_problem_2 import evaluate_scene_b
from evaluation_validation import validate_graph
class Builder:
 def __init__(self):self.ops=[];self.ts=[];self.edges=[];self.oid=1;self.tid=1000000000
 def tensor(self,size,pos):
  t=self.tid;self.tid+=1;self.ts.append({'id':t,'size':int(size),'pos':pos});return t
 def op(self,kind,pipe,cycles,inputs,size,pos):
  v=self.oid;self.oid+=1;self.ops.append({'id':v,'op':kind,'pipe':pipe,'cycles':max(1,int(cycles))});t=self.tensor(size,pos)
  self.edges.extend({'source':x,'target':v} for x in inputs);self.edges.append({'source':v,'target':t});return t
 def inp(self,size,pos):
  d=self.tensor(size,'DDR');return self.op('COPY_IN','PIPE_MTE2',math.ceil(size/60),[d],size,pos)
 def output(self,t):
  size=next(x['size'] for x in self.ts if x['id']==t);self.op('COPY_OUT','PIPE_MTE3',math.ceil(size/60),[t],size,'DDR')
 def graph(self):return {'ops':self.ops,'tensors':self.ts,'edges':self.edges}

def generate(family,seed):
 rng=random.Random(9000+family*100+seed);b=Builder();n=rng.choice([8,12,16,24]);size=rng.choice([1024,4096,12288,24576]);mc=rng.choice([50,200,800,1800]);vc=rng.choice([20,100,400,1200])
 if family in (0,1,4):
  common=b.inp(rng.choice([2,192,4096]),'UB')
  for j in range(n):
   sz=size if family!=4 else rng.choice([1024,4096,12288,24576]);m=mc if family!=4 else int(mc*rng.choice([.25,.5,1,2,4]));v=vc if family!=4 else int(vc*rng.choice([.25,.5,1,2]))
   x=b.inp(sz,'UB');t=b.op('MATMUL','PIPE_M',m,[x],sz,'L1')
   for z in range(2 if family==0 else (6 if family==1 else rng.choice([1,3,6]))):t=b.op('RELU','PIPE_V',v,[t,common],sz,'UB')
   t=b.op('MATMUL','PIPE_M',m,[t,x],sz,'L1');b.output(t)
 elif family==2:
  # Residual stacks with stage-specific weights reused by multiple jobs.
  layers=rng.choice([3,5,8]);weights=[b.inp(rng.choice([4096,16384,65536]),'L1') for _ in range(layers)]
  for j in range(n):
   x=b.inp(size,'L1');t=x
   for z in range(layers):
    skip=t;t=b.op('CONV','PIPE_M',mc,[t,weights[z]],size,'L1');t=b.op('RELU','PIPE_V',vc,[t],size,'L1');t=b.op('ADD','PIPE_V',max(1,vc//2),[t,skip],size,'L1')
   b.output(t)
 elif family==3:
  # Wide reduction, held out for validation.
  width=rng.choice([3,5,9]);ws=[b.inp(size,'L1') for _ in range(width)]
  for j in range(n):
   ins=[b.inp(size,'L1') for _ in range(width)]
   roots=[b.op('MATMUL','PIPE_M',mc,[ins[z],ws[z]],size,'L1') for z in range(width)]
   t=roots[0]
   for x in roots[1:]:t=b.op('ADD','PIPE_V',vc,[t,x],size,'L1')
   b.output(t)
 else:raise ValueError(family)
 g=b.graph();validate_graph(g);return g

ACTIONS=['coarse','wave4','frontier1','frontierp']
def features(g):
 n=len(g.ids);wm=sum(g.cy(v) for v in g.ids if g.pipe(v)=='PIPE_M');wv=sum(g.cy(v) for v in g.ids if g.pipe(v)=='PIPE_V');work=wm+wv
 fans=[len(g.cons[t]&g.eligible) for t in g.ts];sizes=[x['size'] for x in g.ts.values() if x['pos']!='DDR'];ext=[t for t in g.ts if g.cons[t]&g.eligible and not g.prod[t]&g.eligible]
 return [math.log1p(n),math.log1p(len(g.comps)),max(map(len,g.comps))/n,wm/max(1,work),math.log1p(work),max(g.tail.values())/max(1,work),math.log1p(max(fans)),sum(z>1 for z in fans)/len(fans),math.log1p(max(sizes)),math.log1p(sum(sizes)),math.log1p(sum(g.ts[t]['size'] for t in ext)),sum(g.ts[t]['pos']=='UB' for t in ext)/max(1,len(ext)),sum(len(g.pred[v])>1 for v in g.ids)/n,sum(len(g.succ[v])>1 for v in g.ids)/n]

if __name__=='__main__':
 out=ROOT/'experiments/synthetic';out.mkdir(parents=True,exist_ok=True)
 protocol={'families':{0:'homogeneous_MVV_M',1:'homogeneous_MV6_M',2:'residual_shared_weight',3:'reduction_validation',4:'heterogeneous_reentry_test'},'graphs_per_family':12,'split':{'train':[0,1,2],'validation':[3],'test':[4]},'actions':ACTIONS,'cores':4,'problem':2,'labels':'unmodified evaluate_scene_b API; complete result.json retained','generator_sha256':digest(__file__),'WARNING':'small pilot, does not reproduce every official graph family or large-graph/cache regime'}
 (out/'protocol.json').write_text(json.dumps(protocol,indent=2));rows=[];t0=time.perf_counter()
 for fam in range(5):
  for seed in range(12):
   d=generate(fam,seed);g=Graph(d);a=lpt(g,4);folder=out/f'f{fam}_{seed:02d}';folder.mkdir(exist_ok=True);(folder/'graph.json').write_text(json.dumps(d));row={'family':fam,'seed':seed,'features':features(g),'labels':[],'construct_seconds':[],'eval_seconds':[],'spill':[],'statuses':[]}
   for name in ACTIONS:
    target=folder/name;target.mkdir(exist_ok=True);st=time.perf_counter()
    if name=='coarse':pl=plan(g,a,g.topo,4,g.comps)
    elif name=='wave4':pl=plan(g,a,waves(g,a,4),4)
    else:seq,meta=ready_order(g,a,4,True,1,1 if name=='frontierp' else 0,64);pl=plan(g,a,seq,4)
    row['construct_seconds'].append(time.perf_counter()-st);(target/'plan.json').write_text(json.dumps(pl));st=time.perf_counter()
    try:
     result=evaluate_scene_b(d,pl,bandwidth=60,capacity=CAP,cross_core_copy_delay=500);(target/'result.json').write_text(json.dumps(result));row['labels'].append(result['makespan']);row['spill'].append(result['data_movement_bytes']['spill_added_copy_bytes']);row['statuses'].append('ok')
    except Exception as e:
     (target/'error.txt').write_text(traceback.format_exc());row['labels'].append(None);row['spill'].append(None);row['statuses'].append('error')
    row['eval_seconds'].append(time.perf_counter()-st)
   rows.append(row);(out/'labels.json').write_text(json.dumps(rows,indent=2));print(fam,seed,row['labels'],flush=True)
 (out/'total_seconds.json').write_text(json.dumps({'seconds':time.perf_counter()-t0}))
