from core import *
import time
st=time.perf_counter();rows=[]
for p in sorted((OFFICIAL/'data').glob('case_*.json')):
 g=Graph.load(p);d=g.stats();d['case']=p.stem
 # Independent tensor-path contraction, checked against official helper output.
 adj={v:set() for v in g.ops}
 for t in g.ts:
  for a in g.prod[t]:adj[a].update(g.cons[t])
 for v in g.ids:
  stack=list(adj[v]);out=set();seen=set()
  while stack:
   u=stack.pop()
   if u in g.eligible:out.add(u)
   elif u not in seen:seen.add(u);stack.extend(adj[u])
  assert out==g.succ[v],(p.name,v)
 rows.append(d)
Path('/mnt/data/r4_research/analysis/scan100.json').write_text(json.dumps({'seconds':time.perf_counter()-st,'rows':rows},indent=2))
print('100 graphs read and contracted-adjacency checked; seconds',time.perf_counter()-st)
print('single producer count',sum(x['max_producers']==1 for x in rows))
