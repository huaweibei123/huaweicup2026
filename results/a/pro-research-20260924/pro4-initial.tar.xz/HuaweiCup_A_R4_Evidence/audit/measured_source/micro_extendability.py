"""Legal two-core boundary-COPY graph: fitting prefix need not be extendable
without spilling. One core is deliberately left empty; this is a mechanism test.
"""
from pathlib import Path
import json,time
from core import Graph,plan,certify
from synthetic import Builder
from experiments import ROOT,run_e0

def main():
 b=Builder();ids=[]
 for j in range(2):
  x=b.inp(128,'L1');aa=b.oid;y=b.op('MATMUL','PIPE_M',100,[x],65536,'UB')
  bb=b.oid;z=b.op('RELU','PIPE_V',100,[y],65536,'UB');b.output(z);ids.append((aa,bb))
 g=Graph(b.graph());a={v:0 for v in g.ids};out=ROOT/'experiments/micro_extendability';out.mkdir(parents=True,exist_ok=True);gp=out/'graph.json';gp.write_text(json.dumps(g.data))
 rows=[]
 for name,seq in [('admit_both',[ids[0][0],ids[1][0],ids[0][1],ids[1][1]]),('finish_one',[*ids[0],*ids[1]])]:
  pl=plan(g,a,seq,2);r=run_e0(gp,pl,out/name,2,30);r.update(name=name,order=seq,certificate=certify(g,a,2,seq));rows.append(r)
 (out/'summary.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows,indent=2))
if __name__=='__main__':main()
