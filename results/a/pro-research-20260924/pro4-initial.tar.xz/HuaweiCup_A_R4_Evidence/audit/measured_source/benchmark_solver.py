"""Isolated sequential process-level timings, including Python startup/imports."""
import json,subprocess,sys,time,hashlib
from pathlib import Path
from core import OFFICIAL
ROOT=Path(__file__).resolve().parents[1]
protocol={'cases':[2,44,78,14],'budget_seconds':[60,60,60,120],'problem':2,'cores':4,'repetitions':1,'scope':'Prototype deadline smoke test, not paired throughput benchmark','source_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (Path(__file__).with_name('core.py'),Path(__file__).with_name('solve.py'),Path(__file__).with_name('experiments.py'))}}
out=ROOT/'experiments/deadline';out.mkdir(parents=True,exist_ok=True);(out/'protocol.json').write_text(json.dumps(protocol,indent=2));rows=[]
for ci,budget in zip(protocol['cases'],protocol['budget_seconds']):
    d=out/f'case_{ci:03d}';d.mkdir(exist_ok=True)
    cmd=[sys.executable,str(Path(__file__).with_name('solve.py')),str(OFFICIAL/'data'/f'case_{ci:03d}.json'),str(d/'selected.plan.json'),'--cores','4','--problem','2','--budget',str(budget),'--work',str(d/'work')]
    st=time.perf_counter()
    try:
        z=subprocess.run(cmd,capture_output=True,text=True,timeout=budget+12)
        r={'case':ci,'budget':budget,'process_wall_seconds':time.perf_counter()-st,'returncode':z.returncode,'cmd':cmd}
        (d/'stdout.txt').write_text(z.stdout);(d/'stderr.txt').write_text(z.stderr)
        if (d/'work/solver.json').exists():r['solver']=json.loads((d/'work/solver.json').read_text())
    except subprocess.TimeoutExpired:
        r={'case':ci,'budget':budget,'process_wall_seconds':time.perf_counter()-st,'status':'outer_timeout'}
    rows.append(r);(out/'summary.json').write_text(json.dumps(rows,indent=2));print(ci,r['process_wall_seconds'],r.get('solver',{}).get('selected_makespan'),flush=True)
