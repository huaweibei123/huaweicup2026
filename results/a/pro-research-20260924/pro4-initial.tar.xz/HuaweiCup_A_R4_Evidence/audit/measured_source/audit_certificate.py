"""Diagnostic only: original Step1/Step2, bypass Step3 (not an E0 score).
Compares original-graph singleton interval peaks to the generated COPY graph.
No official source file is modified.
"""
from core import *
from experiments import ROOT,digest
import multicore_cut_evaluate_problem_2 as e2
import time,random,argparse

def expanded_peak(graph,seq):
 where={v:i for i,v in enumerate(seq)};use=defaultdict(list)
 for e in graph['edges']:
  a,b=e['source'],e['target']
  if a in where and b not in where:use[b].append(where[a])
  elif b in where and a not in where:use[a].append(where[b])
 delta={p:[0]*(len(seq)+1) for p in CAP}
 for t in graph['tensors']:
  if t['pos']=='DDR' or t['id'] not in use:continue
  ls=use[t['id']];delta[t['pos']][min(ls)]+=t['size'];delta[t['pos']][max(ls)+1]-=t['size']
 peak={}
 for p,x in delta.items():
  live=0;mx=0
  for z in x:live+=z;mx=max(mx,live)
  peak[p]=mx
 return peak

def check(g,pl):
 sgc={sg:c for c,ss in enumerate(pl['core_schedules']) for sg in ss};mp={int(v):s for v,s in pl['node_to_subgraph'].items()};a={v:sgc[s] for v,s in mp.items()};k=len(pl['core_schedules'])
 assert len(set(mp.values()))==len(g.ids),'certificate scope is singleton only'
 order=sorted(g.ids,key=mp.__getitem__);st=time.perf_counter();cert=certify(g,a,k,order);t_cert=time.perf_counter()-st
 records=[];original_s2=e2.step2_spill_insertion;original_s3=e2.prepare_step3_execution
 def wrapped(graph,seq,capacity):
  core=a[next(v for v in seq if v in a)];peak=expanded_peak(graph,seq)
  r=original_s2(graph,seq,capacity=capacity)
  records.append({'core':core,'expanded_peak':peak,'spill_records':len(r['spill_records'])});return r
 try:
  e2.step2_spill_insertion=wrapped;e2.prepare_step3_execution=lambda *args,**kwargs:{}
  st=time.perf_counter();e2._build_scene_b_tasks(g.data,pl,60,CAP);t_build=time.perf_counter()-st
 finally:e2.step2_spill_insertion=original_s2;e2.prepare_step3_execution=original_s3
 equal=all(z['expanded_peak']==cert['static_peak_by_core'][z['core']] for z in records)
 zero=all(z['spill_records']==0 for z in records)
 return dict(cert,generated_step12=records,peaks_equal=equal,zero_spill_equivalent=(cert['no_spill_certificate']==zero),interval_seconds=t_cert,official_step12_seconds=t_build)

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--paths',default='dev_a,dev_b,dev_c,admission_fix,holdout,banker');ap.add_argument('--limit',type=int,default=1000);args=ap.parse_args()
 ps=[]
 for tag in args.paths.split(','):ps.extend(sorted((ROOT/'experiments'/tag).glob('**/plan.json')))
 rows=[];cache={};seen=set()
 for pp in ps:
  try:ci=int(next(x for x in pp.parts if x.startswith('case_')).split('_')[1])
  except (ValueError,StopIteration):continue
  pl=json.loads(pp.read_text());mp=pl['node_to_subgraph']
  if len(set(mp.values()))!=len(mp):continue
  key=(ci,digest(pp))
  if key in seen:continue
  seen.add(key)
  if ci not in cache:cache[ci]=Graph.load(OFFICIAL/'data'/f'case_{ci:03d}.json')
  try:r=check(cache[ci],pl);r.update(case=ci,plan=str(pp.relative_to(ROOT)),plan_sha256=key[1])
  except Exception as e:r={'case':ci,'plan':str(pp.relative_to(ROOT)),'diagnostic_error':repr(e)}
  rows.append(r)
  (ROOT/'analysis/certificate_audit.json').write_text(json.dumps(rows,indent=2))
  print(ci,pp.parent.name,r.get('peaks_equal'),r.get('zero_spill_equivalent'),r.get('diagnostic_error'),flush=True)
  if len(rows)>=args.limit:break
