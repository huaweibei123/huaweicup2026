"""Completion-safe interleaving for independent jobs.
Private tensors follow fixed per-job topological orders. Shared tensors are
conservatively reserved for the entire run. Refuses unsupported reserve profiles.
This is a constructive safe-state filter, not an official timing simulator.
"""
from core import *

def banker_order(g,a,k,io_scale=1.0,pressure=0.0):
 jobs=g.comps; jc=[a[cc[0]] for cc in jobs]
 if any(a[v]!=jc[j] for j,cc in enumerate(jobs) for v in cc):raise ValueError('job split across cores')
 touch={v:g.ins[v]|g.outs[v] for v in g.ids}; tj={t:set() for t in g.ts}
 for v in g.ids:
  for t in touch[v]:tj[t].add(g.job[v])
 pos={t:('UB' if z['pos']=='DDR' else z['pos']) for t,z in g.ts.items()};ri={'L1':0,'UB':1};cap=(CAP['L1'],CAP['UB'])
 shared={t for t,js in tj.items() if len(js)>1};reserve=[[0,0] for _ in range(k)]
 for t in shared:
  for c in {jc[j] for j in tj[t]}:reserve[c][ri[pos[t]]]+=g.ts[t]['size']
 peaks=[];posts=[];needs=[]
 for j,cc in enumerate(jobs):
  rem=Counter(t for v in cc for t in touch[v] if t not in shared);seen=set();live=[0,0];pks=[];pts=[[0,0]]
  for v in cc:
   own=touch[v]-shared;pk=live.copy()
   for t in own-seen:pk[ri[pos[t]]]+=g.ts[t]['size']
   live=pk.copy();seen.update(own)
   for t in own:
    rem[t]-=1
    if not rem[t]:live[ri[pos[t]]]-=g.ts[t]['size']
   pks.append(pk);pts.append(live.copy())
  suffix=[[0,0] for _ in range(len(cc)+1)]
  for i in range(len(cc)-1,-1,-1):suffix[i]=[max(pks[i][r],suffix[i+1][r]) for r in range(2)]
  need=[[max(0,suffix[i][r]-pts[i][r]) for r in range(2)] for i in range(len(cc)+1)]
  if any(suffix[0][r]+reserve[jc[j]][r]>cap[r] for r in range(2)):
   raise ValueError('conservative shared reserve plus one job exceeds capacity')
  peaks.append(pks);posts.append(pts);needs.append(need)
 idx=[0]*len(jobs);total=[[0,0] for _ in range(k)];corejobs=[[j for j,c in enumerate(jc) if c==cc] for cc in range(k)]
 def safe(j):
  c=jc[j];ni=idx[j]+1;alloc=total[c].copy()
  for r in range(2):
   if total[c][r]-posts[j][idx[j]][r]+peaks[j][idx[j]][r]+reserve[c][r]>cap[r]:return False
   alloc[r]+=posts[j][ni][r]-posts[j][idx[j]][r]
  avail=[cap[r]-reserve[c][r]-alloc[r] for r in range(2)]
  # Unstarted jobs can execute sequentially after all active allocations return.
  active=[x for x in corejobs[c] if 0<(ni if x==j else idx[x])<len(jobs[x])]
  while active:
   found=None
   for x in active:
    at=ni if x==j else idx[x]
    if all(needs[x][at][r]<=avail[r] for r in range(2)):found=x;break
   if found is None:return False
   at=ni if found==j else idx[found]
   for r in range(2):avail[r]+=posts[found][at][r]
   active.remove(found)
  return True
 f=Frontier(g,a,k);clock=[defaultdict(float) for _ in range(k)];fill=[0.0]*k;done={};out=[];denied=0;max_active=0
 unfinished=set(range(len(jobs)))
 while unfinished:
  best=None
  for j in sorted(unfinished):
   v=jobs[j][idx[j]];c=jc[j]
   if not safe(j):denied+=1;continue
   m=f.measure(v);new,pk,rel=m;cp=fill[c]
   if io_scale:
    for t in sorted(new&g.ins[v]):
     if not(g.prod[t]&g.eligible):cp+=max(1,math.ceil(g.ts[t]['size']/60))*io_scale
   st=max(clock[c][g.pipe(v)],max((done[p] for p in g.pred[v]),default=0),cp if io_scale else 0)
   ph=sum(((pk[p]-rel[p])/CAP[p])**2-(f.live[c][p]/CAP[p])**2 for p in CAP)
   key=(st+pressure*1000*ph,-g.tail[v],v)
   if best is None or key<best[0]:best=(key,j,v,st,cp,m)
  if best is None:raise AssertionError('safe-state invariant violated')
  _,j,v,st,cp,m=best;c=jc[j]
  for r in range(2):total[c][r]+=posts[j][idx[j]+1][r]-posts[j][idx[j]][r]
  idx[j]+=1
  if idx[j]==len(jobs[j]):unfinished.remove(j)
  done[v]=st+g.cy(v);clock[c][g.pipe(v)]=done[v];fill[c]=cp;f.put(v,m);out.append(v)
  max_active=max(max_active,sum(0<idx[x]<len(jobs[x]) for x in range(len(jobs))))
 meta=f.result();assert meta['no_spill_certificate'];meta.update(banker_shared_reserve=reserve,denied_trials=denied,max_active_across_cores=max_active)
 return out,meta

if __name__=='__main__':
 import argparse,time
 from experiments import run_e0,ROOT
 ap=argparse.ArgumentParser();ap.add_argument('--cases',default='8,44,80');ap.add_argument('--q',type=int,default=2);ap.add_argument('--tag',default='banker');ap.add_argument('--pressure',type=float,default=0);args=ap.parse_args();rows=[]
 for ci in map(int,args.cases.split(',')):
  gp=OFFICIAL/'data'/f'case_{ci:03d}.json';g=Graph.load(gp);a=lpt(g,4);st=time.perf_counter()
  try:
   seq,meta=banker_order(g,a,4,pressure=args.pressure);cons=time.perf_counter()-st;pl=plan(g,a,seq,4);r=run_e0(gp,pl,ROOT/'experiments'/args.tag/f'case_{ci:03d}',args.q);r.update(meta,case=ci,construction_seconds=cons)
  except ValueError as e:r={'case':ci,'status':'unsupported_profile','reason':str(e)}
  rows.append(r);print(ci,r['status'],r.get('makespan'),r.get('construction_seconds'),r.get('reason'),flush=True)
  p=ROOT/'experiments'/args.tag;p.mkdir(exist_ok=True,parents=True);(p/'summary.json').write_text(json.dumps(rows,indent=2))
