"""Exact INTEGER compute+500 model only. No official evaluator imports/calls."""
import collections,heapq,json
from pathlib import Path
p=524;g=13;delay=500
# These symbolic edges are read from the original case_051 first-stage structure.
record=json.loads(Path(__file__).with_name('first_stage_structure.json').read_text())
actual_lane={ch[-1]:j for j,tid,ch in record['lanes']}
actual_join_to_name={u:f'J{i}' for i,(u,pr,sh) in enumerate(record['joins'])}
chain=lambda j:[f'L{j}.{q}' for q in range(1,5)]
P={u:[] for j in range(12) for u in chain(j)}
for j in range(12):
 for q in range(2,5):P[f'L{j}.{q}']=[f'L{j}.{q-1}']
for u,pr,sh in record['joins']:
 P[actual_join_to_name[u]]=[f'L{actual_lane[x]}.4' if x in actual_lane else actual_join_to_name[x] for x in pr]
W={u:p if u.startswith('L') else g for u in P}
ROOT=actual_join_to_name[record['joins'][-1][0]]

def run(seq,source=None,d=delay):
 owner={u:c for c,s in enumerate(seq) for u in s}
 assert len(owner)==sum(map(len,seq))==len(P) and set(owner)==set(P)
 pred={u:{a:(d if owner[a]!=owner[u] else 0) for a in pr} for u,pr in P.items()}
 for s in seq:
  for a,b in zip(s,s[1:]):pred[b][a]=max(pred[b].get(a,0),0)
 succ={u:[] for u in P}
 for u,pr in pred.items():
  for a in pr:succ[a].append(u)
 deg={u:len(pr) for u,pr in pred.items()};q=sorted(u for u in P if deg[u]==0);heapq.heapify(q)
 start={};end={};previous={}
 while q:
  u=heapq.heappop(q)
  r=(d if source is not None and u.endswith('.1') and owner[u]!=source else 0)
  if pred[u]:
   a=max(pred[u],key=lambda a:(end[a]+pred[u][a],a))
   if end[a]+pred[u][a]>=r:r=end[a]+pred[u][a];previous[u]=a
  start[u]=r;end[u]=r+W[u]
  for v in succ[u]:
   deg[v]-=1
   if deg[v]==0:heapq.heappush(q,v)
 assert len(end)==len(P),'cycle'
 path=[ROOT]
 while path[-1] in previous:path.append(previous[path[-1]])
 path.reverse()
 return dict(makespan=end[ROOT],owner=owner,start=start,end=end,path=path,sequences=seq)

def Aseq(b):
 own={f'L{j}.{q}':j*5//12 for j in range(12) for q in range(1,5)}
 desc={f'L{j}.4':{j} for j in range(12)}
 pure=[];mixed=[]
 for u in P:
  if u.startswith('J'):
   desc[u]=set.union(*(desc[a] for a in P[u]))
   cs={j*5//12 for j in desc[u]}
   own[u]=next(iter(cs)) if len(cs)==1 else b
   (pure if len(cs)==1 else mixed).append(u)
 seq=[[]for _ in range(5)]
 order=[u for j in range(12) for u in chain(j)]+pure+mixed
 for u in order:seq[own[u]].append(u)
 return seq

# Names J0..J10 correspond to original 61..71: 01,23,45,67,89,10-11,0-3,4-7,8-11,0-7,root.
ADD_WORD=['J0','J1','J2','J3','J6','J7','J9','J5','J4','J8','J10']

def Bsteady(a=0,b=1):
 # Roles a,b,c,d,e; a and b alternate between physical cores 0 and 1.
 assert {a,b}=={0,1}
 seq=[[]for _ in range(5)]
 seq[a]=chain(2)[:2]+chain(0)+chain(10)
 seq[b]=chain(3)+chain(4)+chain(2)[2:]+ADD_WORD
 seq[2]=chain(9)[:2]+chain(5)+chain(8)
 seq[3]=chain(1)+chain(11)+chain(9)[2:]
 seq[4]=chain(6)+chain(7)
 return seq

def Bfirst():
 seq=Bsteady(0,1)
 seq[1].remove('J5')
 seq[0].append('J5')
 return seq

def Bone():
 own={f'L{j}.{q}':j*5//12 for j in range(12) for q in range(1,5)}
 own['L2.3']=own['L2.4']=1
 seq=[chain(2)[:2]+chain(0)+chain(1),chain(3)+chain(4)+chain(2)[2:],chain(5)+chain(6)+chain(7),chain(8)+chain(9),chain(10)+chain(11)]
 desc={f'L{j}.4':{own[f'L{j}.4']} for j in range(12)}
 pure=[];mixed=[]
 for u in P:
  if u.startswith('J'):
   desc[u]=set.union(*(desc[x]for x in P[u]))
   own[u]=next(iter(desc[u])) if len(desc[u])==1 else 2
   (pure if len(desc[u])==1 else mixed).append(u)
 for u in pure+mixed:seq[own[u]].append(u)
 return seq

if __name__=='__main__':
 first=[run(Aseq(b))['makespan']for b in range(5)]
 matrix=[[run(Aseq(b),a)['makespan'] for b in range(5)]for a in range(5)]
 print('A first',first);print('A matrix');print(*matrix,sep='\n')
 D=first[:];arg=[[]for _ in range(5)]
 for s in range(2,306):
  D=[min(D[a]+matrix[a][b]for a in range(5))for b in range(5)]
  if s in[24,101,305]:print('A finite',s,min(D))
 results={'source_sha256':record['source_sha256'],'model':'original compute + same-core V FIFO + 500 cross-compute dependency only; no official evaluation','A_first':first,'A_transitions':matrix}
 for name,seq,source in [('B_first',Bfirst(),None),('B_steady_0_to_1',Bsteady(0,1),0),('B_steady_1_to_0',Bsteady(1,0),1),('B_one_migration_first',Bone(),None),('B_one_migration_steady',Bone(),2)]:
  r=run(seq,source)
  results[name]=r
  print(name,r['makespan'],'lastvector',[(c,max(r['end'][u]for u in s if u.startswith('L')))for c,s in enumerate(seq)])
  print('ADD times',[(u,r['start'][u],r['end'][u])for u in ADD_WORD]);print('path',r['path'])
 Path(__file__).with_name('abstract_certificates.json').write_text(json.dumps(results,indent=2)+'\n')
