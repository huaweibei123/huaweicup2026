"""Independent static checks on original graph bytes; NO official scoring."""
from __future__ import annotations
from pathlib import Path
import argparse,collections,hashlib,heapq,json,sys,types
import stage_migration

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('graph',type=Path)
parser.add_argument('--official-code',type=Path,help='Optional directory containing frozen static validation modules')
parser.add_argument('--output-dir',type=Path,default=Path('.'))
args=parser.parse_args()
D=args.output_dir;D.mkdir(parents=True,exist_ok=True)
graph_bytes=args.graph.read_bytes()
G=json.loads(graph_bytes)
all_ops={o['id']:o for o in G['ops']}
ops={u:o for u,o in all_ops.items() if o['op'] not in {'COPY_IN','COPY_OUT'}}
tensors={t['id']:t for t in G['tensors']}
prod=collections.defaultdict(set);cons=collections.defaultdict(set);inputs=collections.defaultdict(list)
for e in G['edges']:
 a,b=e['source'],e['target']
 if a in all_ops and b in tensors:prod[b].add(a)
 if a in tensors and b in all_ops:cons[a].add(b);inputs[b].append(a)
pred={u:set() for u in ops};succ={u:set() for u in ops}
for t in tensors:
 for u in prod[t]&ops.keys():
  for v in cons[t]&ops.keys():pred[v].add(u);succ[u].add(v)

def topo(succ):
 deg=dict.fromkeys(succ,0)
 for vs in succ.values():
  for v in vs:deg[v]+=1
 ready=[u for u in succ if not deg[u]];heapq.heapify(ready);out=[]
 while ready:
  u=heapq.heappop(ready);out.append(u)
  for v in succ[u]:
   deg[v]-=1
   if deg[v]==0:heapq.heappush(ready,v)
 assert len(out)==len(succ),'cycle'
 return out
order=topo(succ);pos={u:i for i,u in enumerate(order)}
heads=[u for u in ops if not pred[u]];stages=[];lane_ids=None;covered=set();prev=None
while heads:
 chains={};leaflane={}
 assert len(heads)==12
 for head in heads:
  assert pred[head]==(set() if prev is None else {prev})
  const=[t for t in inputs[head] if not (prod[t]&ops.keys())]
  assert len(const)==1 and tensors[const[0]]['pos']=='L1'
  ch=[head]
  while len(succ[ch[-1]])==1:
   v=next(iter(succ[ch[-1]]))
   if pred[v]!={ch[-1]}:break
   ch.append(v)
  assert len(ch)==4 and all(ops[u]['pipe']=='PIPE_V' and ops[u]['cycles']==524 for u in ch)
  assert ops[ch[-1]]['op']=='REDUCE'
  chains[const[0]]=ch;leaflane[ch[-1]]=const[0]
 if lane_ids is None:lane_ids=sorted(chains)
 assert sorted(chains)==lane_ids
 joins=set();roots=set()
 for leaf in leaflane:
  u=next(iter(succ[leaf]))
  while True:
   assert ops[u]['op']=='ADD' and ops[u]['cycles']==13 and len(pred[u])==2
   joins.add(u)
   if len(succ[u])!=1:roots.add(u);break
   u=next(iter(succ[u]))
 assert len(roots)==1 and len(joins)==11
 root=next(iter(roots));jo=sorted(joins,key=pos.__getitem__)
 desc={u:{l}for u,l in leaflane.items()}
 for u in jo:desc[u]=set.union(*(desc[v]for v in pred[u]))
 stages.append({'root':root,'chains':chains,'join_order':jo,'descendants':desc})
 nodes=joins|{u for ch in chains.values()for u in ch};assert not covered&nodes;covered|=nodes
 prev=root;heads=sorted(succ[root])
assert covered==set(ops)
index=types.SimpleNamespace(graph=G,ops=ops,order=order,duration=lambda u:max(1,ops[u]['cycles']))
rec={'lane_ids':lane_ids,'stages':stages}

# Optional official static validation; no evaluator/Step2/Step3 calls.
derive_multicore_plan=None
if args.official_code is not None:
 sys.path.insert(0,str(args.official_code.resolve()))
 from stub_multicore_cut_and_schedule import derive_multicore_plan

results={'source':str(args.graph),
         'source_sha256':hashlib.sha256(graph_bytes).hexdigest(),
         'stages':len(stages),'original_compute_ops':len(ops),
         'official_e0_e1_e2_calls':0,
         'scope':'static official derive validation + independently implemented compute/FIFO/500 longest path only'}
for variant in ['single_cut','two_cut_optimal']:
 plan,meta=stage_migration._build(index,rec,variant)
 if derive_multicore_plan is not None:derive_multicore_plan(G,plan)
 inverse={sg:int(u)for u,sg in plan['node_to_subgraph'].items()}
 seq=[[inverse[sg]for sg in word]for word in plan['core_schedules']]
 owner={u:c for c,word in enumerate(seq)for u in word}
 adj={u:{v:(500 if owner[u]!=owner[v] else 0)for v in succ[u]}for u in ops}
 for word in seq:
  for u,v in zip(word,word[1:]):adj[u][v]=max(adj[u].get(v,0),0)
 augorder=topo(adj);start=dict.fromkeys(ops,0)
 for u in augorder:
  for v,lag in adj[u].items():start[v]=max(start[v],start[u]+ops[u]['cycles']+lag)
 ends=[start[s['root']]+13 for s in stages]
 expected=[6379*(i+1) if variant=='single_cut' else 6279*(i+1)-500 for i in range(len(stages))]
 assert ends==expected
 assert max(start[u]+ops[u]['cycles']for u in ops)==expected[-1]
 moved=[];traffic=0;initialcopies=0;scalarconnections=0
 for t,td in tensors.items():
  pc={owner[u]for u in prod[t] if u in owner};cc={owner[u]for u in cons[t]if u in owner}
  if cc and not pc:initialcopies+=len(cc)*td['size']
  for a in pc:
   for b in cc:
    if a!=b:
     traffic+=2*td['size'];moved.append([t,a,b,td['size']])
     if td['size']==2:scalarconnections+=1
 original_input_bytes=sum(tensors[t]['size']for t in tensors if cons[t]&ops.keys() and not(prod[t]&ops.keys()))
 # This graph has exactly one original input tensor per lane, and one unchanged final output.
 added=traffic+initialcopies-original_input_bytes
 if variant=='single_cut':assert added==65572*len(stages)-16
 report={'official_static_derive_passed':derive_multicore_plan is not None,'compute_dag_acyclic':True,'L500':expected[-1],
  'stage_root_ends':ends,'large_vector_migration_count':meta['large_vector_migrations'],
  'scalar_cross_tensor_connections':scalarconnections,
  'pre_spill_structural_added_copy_bytes':added,
  'not_official_execution_result':True}
 results[variant]=report
 (D/f'{args.graph.stem}_{variant}_singleton_plan.json').write_text(json.dumps(plan,separators=(',',':'))+'\n')
 (D/f'{variant}_metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
 print(variant,report)
(D/'raw_static_verification.json').write_text(json.dumps(results,indent=2)+'\n')
