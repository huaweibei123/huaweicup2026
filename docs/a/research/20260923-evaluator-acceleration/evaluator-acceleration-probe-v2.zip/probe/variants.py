"""P1-only retention/cache ablation; official full result stays unchanged."""
from prototype import build, Step3Cache


def compact_local(module):
    globals_ = module._runtime.prepare_step3_execution.__globals__
    original = globals_['step3_simulation']
    def compact(*args, **kwargs):
        result = original(*args, **kwargs)
        # Frozen prepare_step3_execution + P1 global simulator use exactly these.
        return {key: result[key] for key in (
            'execution_graph', 'pipe_orders', 'makespan', 'memory_peak', 'memory_dependencies')}
    globals_['step3_simulation'] = compact
    return module


def make_engine(mode):
    module = build('state' if mode in ('lean', 'compact_cache') else mode)
    if mode in ('lean', 'compact_cache'):
        compact_local(module)
    cache = Step3Cache(module) if mode == 'compact_cache' else None
    return module, cache
