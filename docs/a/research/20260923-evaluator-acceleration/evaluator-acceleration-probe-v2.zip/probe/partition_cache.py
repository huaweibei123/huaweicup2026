"""P1-only compiled-partition reuse, guarded by exact ordered input bytes.

Reuses local compilation, NOT global schedule results. All plans are validated
on every call; core assignment/order, waits and all DDR events run afresh.
"""
from collections import OrderedDict
import pickle


class PartitionCache:
    def __init__(self, module, limit=16 * 1024 * 1024):
        self.runtime = module._runtime
        self.original = self.runtime._build_scene_a_tasks
        self.runtime._build_scene_a_tasks = self
        self.entries = OrderedDict()
        self.limit = limit
        self.payload = self.hits = self.misses = self.evictions = 0

    def __call__(self, graph_json, plan, bandwidth, capacity):
        # Same official validity checks, including core order, on EVERY request.
        view = self.runtime.derive_multicore_plan(graph_json, plan)
        self.runtime.validate_task_order(view)
        key = pickle.dumps((graph_json, plan['node_to_subgraph'], bandwidth, capacity), protocol=5)
        if key in self.entries:
            self.hits += 1
            value = self.entries.pop(key)
            self.entries[key] = value
            tasks, cross_traffic, traffic = pickle.loads(value)
            for tid, task in tasks.items():
                task['core_id'] = view['core_by_subgraph'][tid]
                task['pred_tasks'] = view['subgraph_preds'][tid]
                # Preserve official set insertion/iteration construction exactly;
                # never rely on pickle retaining a set's hash-table arrangement.
                graph = task['graph']
                inputs, outputs, preds, succs = self.runtime._build_graph_views(graph['ops'], graph['edges'])
                task.update(in_tids=inputs, out_tids=outputs, op_preds=preds, op_succs=succs)
            return tasks, cross_traffic, traffic, view
        self.misses += 1
        tasks, cross_traffic, traffic, view = self.original(graph_json, plan, bandwidth, capacity)
        value = pickle.dumps((tasks, cross_traffic, traffic), protocol=5)
        size = len(key) + len(value)
        if size <= self.limit:
            while self.payload + size > self.limit:
                old_key, old_value = self.entries.popitem(last=False)
                self.payload -= len(old_key) + len(old_value)
                self.evictions += 1
            self.entries[key] = value
            self.payload += size
        return tasks, cross_traffic, traffic, view

    def stats(self):
        return {key: getattr(self, key) for key in ('limit', 'payload', 'hits', 'misses', 'evictions')}
