"""Research-only measurements. Run from project root, Python 3.12 locked env."""
import argparse
import csv
import gc
import gzip
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import random
import resource
import statistics
import subprocess
import time

from prototype import ROOT, build, Step3Cache
from src.eval_exact._official import load_problem1_bundle, OFFICIAL_CODE_HASH
from src.eval_exact.benchmark import _first_difference

OUT = Path(__file__).resolve().parent
DATA = ROOT / 'data/raw/a/official/data'
POOL = ROOT / 'results/a/proxy/r20260923-e2-dev64-gzip'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def setup():
    oracle, support = load_problem1_bundle('_assessment_probe_oracle')
    config = str(DATA / 'config.txt')
    settings = support['evaluation_validation'].read_evaluation_config(config)
    scene = oracle.read_scene_a_config(config)
    arguments = dict(bandwidth=settings['bandwidth'], capacity=settings['capacity'],
        cross_core_wait=scene['task_cross_core_wait_cycles'],
        same_core_wait=scene['task_same_core_wait_cycles'])
    return oracle, support, arguments


def assert_full(expected, actual, label):
    difference = _first_difference(expected, actual)
    if difference:
        raise AssertionError((label, difference))


def metadata():
    return dict(head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
        python=platform.python_version(), platform=platform.platform(),
        cpu_count=os.cpu_count(), official_code_hash=OFFICIAL_CODE_HASH,
        config_sha256=sha(DATA / 'config.txt'),
        prototype_sha256=sha(OUT / 'prototype.py'), harness_sha256=sha(__file__),
        hash_seed=os.environ.get('PYTHONHASHSEED'), timestamp=time.time())


def save(name, value):
    path = OUT / name
    if path.exists():
        raise FileExistsError(path)
    path.write_text(json.dumps(value, indent=2) + '\n')


def matrix():
    oracle, support, kwargs = setup()
    engines = {'e0': oracle.evaluate_scene_a}
    engines.update({mode: build(mode).evaluate_scene_a for mode in ('e1', 'global', 'state')})
    records = []
    for case in ('001', '003', '025', '080'):
        graph = json.loads((DATA / f'case_{case}.json').read_text())
        plan = support['stub_multicore_cut_and_schedule'].generate_multicore_plan(
            graph, num_cores=4, seed=2026, min_subgraph_size=50, max_subgraph_size=100)
        save(f'case_{case}.plan.json', plan)
        expected = oracle.evaluate_scene_a(graph, plan, **kwargs)
        for name, function in engines.items():
            assert_full(expected, function(graph, plan, **kwargs), ('warm', case, name))
        samples = []
        names = list(engines)
        for repeat in range(3):
            times = {}
            for name in names[repeat:] + names[:repeat]:
                gc.collect()
                begin = time.perf_counter()
                result = engines[name](graph, plan, **kwargs)
                times[name] = time.perf_counter() - begin
                assert_full(expected, result, (case, repeat, name))
                del result
            samples.append(times)
        summary = {name: statistics.median(row[name] for row in samples) for name in names}
        paired = {name: math.exp(statistics.mean(math.log(row['e0'] / row[name]) for row in samples)) for name in names}
        record = dict(case=case, graph_sha256=sha(DATA / f'case_{case}.json'),
            ops=len(graph['ops']), tasks=len(set(plan['node_to_subgraph'].values())),
            plan_sha256=sha(OUT / f'case_{case}.plan.json'), makespan=expected['makespan'],
            spill=expected['data_movement_bytes']['spill_added_copy_bytes'],
            samples=samples, median_seconds=summary, paired_speedup_e0=paired, full_equal=True)
        records.append(record)
        print(json.dumps(record), flush=True)
    save('matrix.json', dict(metadata=metadata(), warmup=1, repeats=3,
        scope='P1 parsed input to full object; compare outside timed region; rotated order', records=records))


def pool():
    oracle, support, kwargs = setup()
    graph = json.loads((DATA / 'case_001.json').read_text())
    candidate = build('state')
    cached = build('cache')
    cache = Step3Cache(cached)
    rows = list(csv.DictReader((POOL / 'candidates.csv').open()))
    timing = {'e1': 0.0, 'state': 0.0, 'cache': 0.0}
    engines = dict(e1=build('e1').evaluate_scene_a, state=candidate.evaluate_scene_a,
        cache=cached.evaluate_scene_a)
    for row in rows:
        plan_path = POOL / row['plan_path']
        assert sha(plan_path) == row['plan_sha256']
        plan = json.loads(plan_path.read_text())
        expected = json.loads(gzip.decompress((POOL / row['e0_output_path']).read_bytes()))
        for name, function in engines.items():
            begin = time.perf_counter()
            result = function(graph, plan, **kwargs)
            timing[name] += time.perf_counter() - begin
            assert_full(expected, json.loads(json.dumps(result)), row['candidate_id'])
    data = dict(metadata=metadata(), count=len(rows), full_equal=True,
        scope='single pass 64 distinct development plans; saved official truth; cold local cache',
        seconds=timing, cache=cache.stats())
    print(json.dumps(data), flush=True)
    save('pool.json', data)


def cache_probe():
    oracle, support, kwargs = setup()
    graph = json.loads((DATA / 'case_003.json').read_text())
    reference = json.loads((OUT / 'case_003.plan.json').read_text())
    view = support['stub_multicore_cut_and_schedule'].derive_multicore_plan(graph, reference)
    plans = []
    rng = random.Random(20260923)
    for _ in range(12):
        pending = {tid: set(preds) for tid, preds in view['subgraph_preds'].items()}
        schedules = [[] for _ in range(4)]
        while pending:
            ready = sorted(tid for tid, deps in pending.items() if not deps)
            tid = rng.choice(ready)
            del pending[tid]
            schedules[rng.randrange(4)].append(tid)
            for deps in pending.values():
                deps.discard(tid)
        plans.append(dict(node_to_subgraph=reference['node_to_subgraph'], core_schedules=schedules))
    save('reschedule-plans.json', plans)
    state = build('state')
    cached = build('cache')
    cache = Step3Cache(cached)
    times = {'state': [], 'cache': []}
    checks = []
    # No global answers are cached, and first candidate includes cold-cache cost.
    for index, plan in enumerate(plans):
        baseline = None
        for name, engine in [('state', state), ('cache', cached)]:
            begin = time.perf_counter()
            result = engine.evaluate_scene_a(graph, plan, **kwargs)
            times[name].append(time.perf_counter() - begin)
            if baseline is None:
                baseline = result
            else:
                assert_full(baseline, result, ('cache', index))
        # Independently recompute official output for every plan, outside timing.
        assert_full(oracle.evaluate_scene_a(graph, plan, **kwargs), baseline, ('e0', index))
        checks.append(baseline['makespan'])
        print(json.dumps(dict(candidate=index, state=times['state'][-1], cache=times['cache'][-1], stats=cache.stats())), flush=True)
    save('cache.json', dict(metadata=metadata(), scope='P1 same partition, 12 distinct legal reschedules; full output; includes cold miss',
        plan_file_sha256=sha(OUT / 'reschedule-plans.json'), seconds=times, cache=cache.stats(),
        makespans=checks, full_equal=True, single_pass=True))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('mode', choices=['matrix', 'pool', 'cache'])
    args = parser.parse_args()
    {'matrix': matrix, 'pool': pool, 'cache': cache_probe}[args.mode]()
