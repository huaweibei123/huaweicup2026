图5-3首轮实质验收：退回原图修订，不是新派单。固定e5b785c96f3c589cf3029c62f76fea67dcd7a90c，提交4f0eff7bd72744c8ba770d9c7d4e625a，目录figures/a/p123-fig-5-3-lyx-20260926/。接收与通信排障见本Issue评论5846198072：11件真实Git blob已经收到，不必重复推相同版本；下面是收件后的集中审查结果。

已核正确部分：500个唯一坐标、各核100例；makespan与固定per_case.json的P2逐格相同；现有表在它自己所选分母下的比值及算术均值计算一致。已实际看PNG，坐标、单位、图例完整。没有虚构缺测F1散点，这一原则保持；但只读取单一feed并不意味着任务要求的其他已发布算法没有数据。没有运行上传脚本、没有新增实验。

必须修改清单（本轮一次完成）：

| 编号/性质 | 文件定位与实际证据 | 执行步骤 | 完成判据与验证 |
|---|---|---|---|
| F53-R01 科学/来源：缺指定方法 | make_fig53()只生成q2-adaptive-budget一条曲线；图中缺表5-2的tensor、gap、c665主方法及F1五核点。它的5核3.629259也不是c665的4.549757。任务书v5已要求完整固定方法比较，不能用单一feed的覆盖边界缩减本图。 | 用下列固定已有CSV和completed-summary，分别建立三个完整方法+F1的长表；记录每个方法的算法、结果commit。c665明确标“结构初解+gap+hypergap”；F1只k5独立点。q2-adaptive-budget若保留，只作另列明确版本的额外对照，不能替代主方法，也不能与其他版本拼赢家。 | tensor/gap/c665各500唯一坐标、每核100；F1只有5核100点汇成一个独立点，不能连到另5个k3样本。附方法×核数n/均值，按下方复算参考核对。 |
| F53-R02 科学/分母：用了优化后的单核结果 | plot_figures.py make_fig53的base_by_case取同方法cores==1的makespan；在86个用例、430格中不同于固定官方A场景基线。002用了240813而官方原件为261945 cycles；本轮再次取002原始result.json.gz并校SHA，100分母其余复用0859已核记录。 | 所有方法使用同一case→官方A单核基线B_i；下述成员per-cell.csv的baseline_cycles已经有该固定分母，三份CSV逐例一致，并与既有100份基线证据逐项相等。不要从优化k1反推基线。speedup保存真实B_i/M_i；只在主曲线汇总展示k1=1，另列优化k1观测均值。 | 每case所有method/core的baseline相同；逐格独立B/M、再平均。当前budget若保留，用正确分母复算k2..5=2.0504834568791193/2.8156652591507116/3.476781241903971/4.0140941745651695；真实k1观测均值1.1085967079439594，主曲线仍显示1。这仅纠正该额外对照，不是c665成绩。 |
| F53-R03 交付：规范列缺失 | per_case_speedup.csv列baseline_cycles/makespan_cycles/observed_speedup，机检要求baseline/makespan/speedup。 | 从上述正确数据生成规范派生CSV，至少含case,cores,method,baseline,makespan,speedup；可以保留原附加列。summary至少method,cores,n,mean_speedup，k1按规定展示1，另列mean_observed_speedup。audit.tables指向实际附件。 | 周期整数、无NaN/缺测补零，真实speedup不强改为1；规范CSV的method字段须精确为F1，便于现有机检识别其仅k5覆盖；图例可另用中文全称；正式提交后data-speed须通过。 |
| F53-R04 交付：已写命令无法在固定提交复现 | audit/README命令指向src/analysis/p123_figures_lyx/plot_all.py，固定e5b785c的完整Git tree无此文件（contents亦404）。包中已有plot_figures.py，其当前深度下ROOT=parents[3]可定位仓库根，可作为修正命令入口；问题是声明命令的目标未发布。 | 将真正生成本图的源码提交到声明路径，或把包内源码改成从明确参数/正确仓库根定位输入；同步README、audit.command、manifest真实命令。确保在没有本机gitignored inputs/P2.json的干净检出也能用已发布固定输入生成本图；不要执行整套make_all，限定--figure 5-3，0新增solver/E0。 | 从固定提交可找到命令每个脚本和输入；记录实际命令/退出码/输出路径。绘图源、输入与本次图一致，无需提供未执行的桌面检查声明。 |
| F53-R05 交付：Git字节哈希失配 | audit的SVG、caption、self-check、两张CSV、README、manifest共7项与远端实际SHA256不符；独立验证7项声明均等于CRLF工作副本，Git原件为LF。这一项是换行身份错误，不另归为数据造假。 | 源/输入/图/图注/自查先全部定稿；manifest.outputs按最终Git字节计算，然后audit.files记录manifest及其他附件的实际Git字节。audit不自哈希；不要生成manifest之后再改其中已登记文件。 | 发布后逐件远端读取，audit每项与实取字节SHA256相同；不能只核工作区文本。全包重新提交，SVG/PDF/PNG必须由同次最终绘图导出。 |

直接可用的固定输入（我方已下载真实字节、核覆盖及复算均值，不需要新增实验）：

1. 算法对照结果固定178a3673bd238b20772211427b8134b6db35f5af，目录results/a/q2-yuanzhifang/feedback-20260924/full-coverage/：
   - [tensor完整表](https://github.com/huaweibei123/huaweicup2026/blob/178a3673bd238b20772211427b8134b6db35f5af/results/a/q2-yuanzhifang/feedback-20260924/full-coverage/all500/per-cell.csv)
   - [gap完整表](https://github.com/huaweibei123/huaweicup2026/blob/178a3673bd238b20772211427b8134b6db35f5af/results/a/q2-yuanzhifang/feedback-20260924/full-coverage/gap-full500/per-cell.csv)
   - [F1五核完整表](https://github.com/huaweibei123/huaweicup2026/blob/178a3673bd238b20772211427b8134b6db35f5af/results/a/q2-yuanzhifang/feedback-20260924/full-coverage/frontier-k5-100/per-cell.csv)
2. [c665完整结果completed-summary](https://github.com/huaweibei123/huaweicup2026/blob/1c00079aadbd071de62db17686d5ba3fed1da0f2/results/a/q2-nikolastarx/hypergap-full500-audit-20260925/completed-summary.json)：rows用case/cores配对，Makespan读取official.makespan。注意其中row.baseline是前版优化算法2794ce，**不是官方A单核分母**；仍使用前述CSV共同B_i。已核顶层completed、500 accepted及solver_commit=c665。
3. [冻结章节与证据入口](https://github.com/huaweibei123/huaweicup2026/blob/615b1a5f7913a97fff8924cfec9936d3d303c6fc/paper/sections/a-q2-evidence.md)的S6/S7；同提交paper-draft-20260925/build_snapshot.py可读取作为字段映射参考，不要求重新执行其环境依赖。

独立复算参考（显示6位，CSV保留完整精度）：

| 方法 | 主曲线k1 | k2 | k3 | k4 | k5 | 优化k1另列 |
|---|---:|---:|---:|---:|---:|---:|
| tensor | 1 | 1.938126 | 2.673480 | 3.330228 | 3.896037 | 1.056973 |
| gap | 1 | 2.200110 | 2.939676 | 3.440056 | 3.676575 | 1.167562 |
| c665 | 1 | 2.316727 | 3.235566 | 3.971149 | 4.549757 | 1.206139 |
| F1 | 缺测 | 缺测 | 缺测 | 缺测 | 3.888209 | 缺测 |

任务书v5优先于旧章节关于优化单核展示的文字：真实观测存表，主曲线k1设1；不能为匹配显示去改原始观测。不同固定版本比较不叫单模块消融。

视觉建议（不增加硬门槛）：现有k2的1.85标值被理想虚线穿过；在数据重绘时移动标值，或移开参考线标签。按最终正文宽度核对新的多系列线型/图例/F1点，长底注可移入caption。当前没有因字号或色彩偏好单独退回。

审查边界：已完整核当前500表与固定feed、均值、来源原字节和实际PNG；另读指定方法的三张CSV及c665完整收据汇总，复算上表，但没有重审1500份官方原始结果、没有重跑实验。现图不是来源缺失，而是取错任务方法及分母。SVG标准跨行DOCTYPE仍被我方在线v1.1误报，是审查方兼容待处理；不要求你删除标准声明或为该误报重画。

一次性交付顺序：固定上述方法/来源→正确分母与完整长表→只绘本图→实际正文尺寸看图→更新caption/README/自查/真实命令→最终Git字节定稿→manifest→audit哈希→独立交付分支推送并逐件远端回读→原Issue15逐项F53-R01..R05报告修改位置、验证结果、证据路径/哈希及完整commit。缺项给具体材料，不回“已全部修复”代替证据。同一图仍占在途名额；该退回不派新图，也不授权新solver/E0预算。

